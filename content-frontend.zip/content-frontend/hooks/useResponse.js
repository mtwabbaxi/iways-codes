import { useToast } from "@/context/toastContext";

export default function useResponse() {
  const { addToast } = useToast();

  const showMessage = (data, onSuccess = () => {}, onError = () => {}) => {
    const {
      result: { body },
    } = res;
    if (body.responseCode === 200) {
      addToast(body.responseMessage);
      if (!isEditMode) {
        dispatch(fetchAllContentModels());
        onClose();
      }
    } else {
      addToast(body?.responseMessage || "An unknown error occured!", {
        type: "error",
      });
    }
  };
  return { showMessage };
}
