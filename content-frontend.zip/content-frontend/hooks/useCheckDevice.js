import { useEffect, useState } from "react";

const SCREEN_SIZES = {
  SM: 480,
  MD: 768,
  DESKTOP: 1024,
};

const useCheckDevice = () => {
  const [deviceCheck, setDeviceCheck] = useState({
    mobileDevice:
      window?.innerWidth < SCREEN_SIZES.DESKTOP ||
      window?.innerWidth < SCREEN_SIZES.SM,
    tabletDevice:
      window?.innerWidth > SCREEN_SIZES.MD - 1 &&
      window?.innerWidth < SCREEN_SIZES.DESKTOP,
    desktopDevice: window?.innerWidth > SCREEN_SIZES.DESKTOP - 1,
  });

  const handleWindowSizeChange = () => {
    if (
      window?.innerWidth < SCREEN_SIZES.MD ||
      window?.innerWidth < SCREEN_SIZES.SM
    ) {
      if (deviceCheck.mobileDevice === false) {
        setDeviceCheck({
          mobileDevice: true,
          tabletDevice: false,
          desktopDevice: false,
        });
      }
    }
    if (
      window?.innerWidth > SCREEN_SIZES.MD - 1 &&
      window?.innerWidth < SCREEN_SIZES.DESKTOP
    ) {
      if (deviceCheck.tabletDevice === false) {
        setDeviceCheck({
          mobileDevice: false,
          tabletDevice: true,
          desktopDevice: false,
        });
      }
    }
    if (window?.innerWidth > SCREEN_SIZES.DESKTOP - 1) {
      if (deviceCheck.desktopDevice === false) {
        setDeviceCheck({
          mobileDevice: false,
          tabletDevice: false,
          desktopDevice: true,
        });
      }
    }
  };

  useEffect(() => {
    window.addEventListener("resize", handleWindowSizeChange);
    return () => {
      window.removeEventListener("resize", handleWindowSizeChange);
    };
  }, [handleWindowSizeChange]);

  return deviceCheck;
};

export default useCheckDevice;
