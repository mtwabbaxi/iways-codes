"use client";

import React, { createContext, useContext, useState } from "react";
import { v4 as uuidv4 } from "uuid";
import { AiOutlineClose } from "react-icons/ai";

const ToastContext = createContext();

export function useToast() {
  return useContext(ToastContext);
}

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);

  const addToast = (message, options = {}) => {
    const type = options.type || "success";
    // Generate a unique ID for the toast using uuid
    const id = uuidv4();

    // Add a new toast to the existing list of toasts with the generated ID
    setToasts((prevToasts) => [...prevToasts, { id, message, type }]);

    // Automatically remove the toast after 2 seconds (2000 milliseconds)
    setTimeout(() => {
      removeToast(id);
    }, 1500);
  };

  const removeToast = (idToRemove) => {
    // Add the slide-out animation to the toast being removed
    setToasts((prevToasts) =>
      prevToasts.map((toast) =>
        toast.id === idToRemove ? { ...toast, isRemoving: true } : toast
      )
    );
    // Remove the toast after the animation completes (500ms)
    setTimeout(() => {
      setToasts((prevToasts) =>
        prevToasts.filter((toast) => toast.id !== idToRemove)
      );
    }, 500);
  };

  return (
    <ToastContext.Provider value={{ addToast, removeToast }}>
      {children}
      <div className="toast-container">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`toast toast-${toast.type} ${
              toast.isRemoving ? "toast-removing" : ""
            }`}
          >
            {toast.message}
            <button onClick={() => removeToast(toast.id)}>
              <AiOutlineClose size="0.7em" />
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}
