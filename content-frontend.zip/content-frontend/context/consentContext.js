"use client";

import React, { createContext, useContext, useState } from "react";
import Modal from "@/components/shared/modal";

const ConsentContext = createContext();

export function useConsent() {
  return useContext(ConsentContext);
}

export function ConsentProvider({ children }) {
  const [consent, setConsent] = useState([]);
  const [open, setOpen] = useState(false);

  const takeConsent = (options = { heading: "", message: "" }) => {
    setConsent(options);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <ConsentContext.Provider value={{ takeConsent, closeConsent: handleClose }}>
      {children}
      {open && (
        <Modal heading={consent.heading} onClose={handleClose}>
          <div>{consent.message}</div>
        </Modal>
      )}
    </ConsentContext.Provider>
  );
}
