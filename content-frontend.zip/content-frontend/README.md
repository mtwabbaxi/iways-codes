This is a [Next.js](https://nextjs.org/) project bootstrapped with [`create-next-app`](https://github.com/vercel/next.js/tree/canary/packages/create-next-app).

## Development Guide

- camelCase is used for folders and files names.
- kebab-case is used for css classes.
- NextJS default app router is used. Must read this if you are not familiar with app router. https://nextjs.org/docs/app
- a utils directory is created for utilities.
- whole app urls will be specified in the constants file created inside the utils directory.
- absolute paths are configured in the project so there is no need to go back like ../../ to import anything in any component.
- Just use @ just like `import { APP_URLS } from "@/utils/constants"``;

## Development

After clone, checkout to dev branch and take pull if needed.
Use the node version 18.17.1

Install the packages with npm install

Run the development server:

```bash
npm run dev
# or
yarn dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.js`. The page auto-updates as you edit the file.

This project uses [`next/font`](https://nextjs.org/docs/basic-features/font-optimization) to automatically optimize and load Inter, a custom Google Font.

## Build

To build the project, run the following command:

Use the node version 18.17.1

```bash
npm run build
# or
yarn build
```

## Docs

This project is using classnames package to conditionally join the classnames.
https://www.npmjs.com/package/classnames

- app router is enabled on this project.
- absolute paths are configured on this project with @ keyword.
- styles/\_colors.scss contains all the colors variables.
- all the colors variables are automatically shared to all the style files in whole project with sassOptions in next.config.js.

## Authentication Pages

For authentication and protecting routes middleware has been created. If you created a new file and you want to protect it add inside the middleware's config matcher.
