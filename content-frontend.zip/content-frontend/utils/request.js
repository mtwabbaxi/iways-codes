import axios from "axios";

import { HOST_API_KEY } from "../config-global";
import { PATH_AUTH } from "src/routes/paths";
import { setSession, setUser, setRole } from "src/auth/utils";
// ----------------------------------------------------------------------

const axiosInstance = axios.create({ baseURL: HOST_API_KEY });
axiosInstance.interceptors.response.use(
    (response) => response,
    (error) =>
        Promise.reject(
            (error.response && error.response.data) || "Something went wrong"
        )
);

const instance = axios.create({
    baseURL: "https://64878703beba62972790c65f.mockapi.io",
});

instance.interceptors.response.use(
    (response) => response,
    (error) =>
        Promise.reject(
            (error.response && error.response.data) || "Something went wrong"
        )
);
instance.interceptors.request.use((config) => {
    const accessToken = localStorage.getItem("accessToken");
    const key = localStorage.getItem("key");
    config.headers["x-api-token"] = accessToken;
    config.headers["x-api-key"] = key;
    return config;
});

instance.interceptors.response.use(
    (response) => {
        if (
            response?.data?.response?.message ===
            "Login has expired. Please login again"
        ) {
            setSession(null);
            setUser(null);
            setRole(null);
            window.location.href = PATH_AUTH.login;
        }
        return response;
    },
    (error) =>
        Promise.reject(
            (error.response && error.response.data) || "Something went wrong"
        )
);

export { instance };
export default axiosInstance;