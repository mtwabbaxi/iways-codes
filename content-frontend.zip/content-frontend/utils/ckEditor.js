const transformDataToJSON = (data) => {
  // Initialize an empty JSON structure
  const jsonContent = {
    type: "document",
    content: [],
  };

  // Create a DOM parser to parse the CKEditor HTML content
  const parser = new DOMParser();
  const doc = parser.parseFromString(data, "text/html");

  // Define a helper function to parse an HTML node and return its JSON representation
  const parseNode = (node) => {
    if (node.nodeType === Node.TEXT_NODE) {
      // Handle text nodes
      return { type: "text", text: node.textContent };
    } else if (node.nodeType === Node.ELEMENT_NODE) {
      const jsonNode = {
        type: node.tagName.toLowerCase(),
        content: [],
      };

      if (node.tagName.toLowerCase() === "a" && node.getAttribute("href")) {
        // Handle anchor (link) elements
        jsonNode.attrs = { href: node.getAttribute("href") };
      }

      node.childNodes.forEach((childNode) => {
        const childJsonNode = parseNode(childNode);
        if (childJsonNode) {
          jsonNode.content.push(childJsonNode);
        }
      });

      return jsonNode;
    }

    return null;
  };

  // Iterate through the CKEditor content nodes
  doc.body.childNodes.forEach((node) => {
    const jsonNode = parseNode(node);
    if (jsonNode) {
      jsonContent.content.push(jsonNode);
    }
  });

  return jsonContent;
};

const parseNode = (node) => {
  if (node.nodeType === Node.TEXT_NODE) {
    // Text nodes
    return {
      type: "text",
      text: node.textContent,
      marks: [],
    };
  }

  if (node.nodeType === Node.ELEMENT_NODE) {
    // Element nodes
    const jsonNode = {
      type: "element",
      content: [],
      marks: [],
      attrs: {},
    };

    jsonNode.type = node.tagName.toLowerCase();

    // Extract attributes of the element
    for (let i = 0; i < node.attributes.length; i++) {
      const attr = node.attributes[i];
      jsonNode.attrs[attr.name] = attr.value;
    }

    // Recursively process child nodes
    node.childNodes.forEach((childNode) => {
      const childJsonNode = parseNode(childNode);
      if (childJsonNode) {
        jsonNode.content.push(childJsonNode);
      }
    });

    return jsonNode;
  }

  return null;
};

const convertJsonToHtml = (jsonContent) => {
  if (!jsonContent || !Array.isArray(jsonContent)) {
    return ""; // Handle empty or invalid data
  }
  let html = "";

  jsonContent.forEach((item) => {
    if (item.type) {
      if (item.type === "a" && item.attrs && item.attrs.href) {
        // Handle anchor (link) elements
        html += `<a href="${item.attrs.href}">`;
        if (item.content) {
          html += convertJsonToHtml(item.content);
        } else if (item.text) {
          html += item.text;
        }
        html += `</a>`;
      } else {
        html += `<${item.type}>`;
        if (item.content) {
          html += convertJsonToHtml(item.content);
        } else if (item.text) {
          html += item.text;
        }
        html += `</${item.type}>`;
      }
    }
  });

  return html;
};

export { transformDataToJSON, convertJsonToHtml };
