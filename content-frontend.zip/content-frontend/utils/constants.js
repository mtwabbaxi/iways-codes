export const APP_URLS = {
  CONTENT: {
    LIST: "/spaces/:spaceId/environment/:spaceEnvironmentId/content",
    CREATE:
      "/spaces/:spaceId/environment/:spaceEnvironmentId/content-entry/:contentModelId",
    UPDATE:
      "/spaces/:spaceId/environment/:spaceEnvironmentId/content-entry/:contentModelId/:contentEntryId",
  },
  HOME: "/spaces/:spaceId/environment/:spaceEnvironmentId",
  CONTENT_MODELS: {
    CREATE:
      "/spaces/:spaceId/environment/:spaceEnvironmentId/content-models/create/:apiIdentifier",
    LIST: "/spaces/:spaceId/environment/:spaceEnvironmentId/content-models",
    UPDATE:
      "/spaces/:spaceId/environment/:spaceEnvironmentId/content-models/content-fields/update-model",
    UPDATE_MODEL:
      "/spaces/:spaceId/environment/:spaceEnvironmentId/content-models/:contentModelId/update-model",
    JSON_PREVIEW:
      "/spaces/:spaceId/environment/:spaceEnvironmentId/content-models/:contentModelId/JSON-preview",
    CONTENT_FIELDS: {
      LIST: "/spaces/:spaceId/environment/:spaceEnvironmentId/content-models/:contentModelId",
    },
  },
  CONTENT_ENTRY: {
    DETAIL: ({ spaceId, spaceEnvironmentId, contentEntryId, contentModelId }) =>
      `/spaces/${spaceId}/environment/${spaceEnvironmentId}/content-entry/${contentModelId}/${contentEntryId}`,
  },
  MEDIA: {
    LIST: "/spaces/:spaceId/environment/:spaceEnvironmentId/media",
    CREATE: "/spaces/:spaceId/environment/:spaceEnvironmentId/media/create",
    UPDATE: "/spaces/:spaceId/environment/:spaceEnvironmentId/media/:assetId",
  },
  THEME: {
    BUTTONS: "/theme/buttons",
    TABS: "/theme/tabs",
    ALERTS: "/theme/alerts",
    FORM_INPUTS: "/theme/form-inputs",
    DATA_TABLES: "/theme/data-tables",
    MENUS: "/theme/menus",
    LABELS: "/theme/labels",
  },
  SETTINGS: {
    ENVIRONMENTS: {
      LIST: "/spaces/:spaceId/environment/:spaceEnvironmentId/settings/environments",
    },
    LOCALES: {
      LIST: "/spaces/:spaceId/environment/:spaceEnvironmentId/settings/locales",
      CREATE:
        "/spaces/:spaceId/environment/:spaceEnvironmentId/settings/locales/create",
      UPDATE:
        "/spaces/:spaceId/environment/:spaceEnvironmentId/settings/locales/:localeId",
    },
  },
  LOGIN: "/login",
  SIGNUP: "/signup",
  API_KEYS: "/spaces/:spaceId/environment/:spaceEnvironmentId/api/keys",
  API_KEY_DETAILS:
    "/spaces/:spaceId/environment/:spaceEnvironmentId/api/keys/:apiKeyId",
  ORGANIZATION: {
    SPACES:
      "/spaces/:spaceId/environment/:spaceEnvironmentId/organization/spaces",
    SUBSCRIPTION:
      "/spaces/:spaceId/environment/:spaceEnvironmentId/organization/subscription",
  },
};

// Function to replace placeholders in a URL with actual values
export const replaceUrlParams = (url, params) => {
  let replacedUrl = url;

  for (const key in params) {
    if (params.hasOwnProperty(key)) {
      const placeholder = `:${key}`;
      replacedUrl = replacedUrl.replace(placeholder, params[key]);
    }
  }

  return replacedUrl;
};

export const timeZoneOptions = [
  { value: "", label: "Select an Option" },
  { value: "-12:00", label: "UTC-12:00" },
  { value: "-11:00", label: "UTC-11:00" },
  { value: "-10:00", label: "UTC-10:00" },
  { value: "-09:30", label: "UTC-09:30" },
  { value: "-09:00", label: "UTC-09:00" },
  { value: "-08:00", label: "UTC-08:00" },
  { value: "-07:00", label: "UTC-07:00" },
  { value: "-06:00", label: "UTC-06:00" },
  { value: "-05:00", label: "UTC-05:00" },
  { value: "-04:30", label: "UTC-04:30" },
  { value: "-04:00", label: "UTC-04:00" },
  { value: "-03:30", label: "UTC-03:30" },
  { value: "-03:00", label: "UTC-03:00" },
  { value: "-02:00", label: "UTC-02:00" },
  { value: "-01:00", label: "UTC-01:00" },
  { value: "+00:00", label: "UTC+00:00" },
  { value: "+01:00", label: "UTC+01:00" },
  { value: "+02:00", label: "UTC+02:00" },
  { value: "+03:00", label: "UTC+03:00" },
  { value: "+03:30", label: "UTC+03:30" },
  { value: "+04:00", label: "UTC+04:00" },
  { value: "+04:30", label: "UTC+04:30" },
  { value: "+05:00", label: "UTC+05:00" },
  { value: "+05:30", label: "UTC+05:30" },
  { value: "+05:45", label: "UTC+05:45" },
  { value: "+06:00", label: "UTC+06:00" },
  { value: "+06:30", label: "UTC+06:30" },
  { value: "+07:00", label: "UTC+07:00" },
  { value: "+08:00", label: "UTC+08:00" },
  { value: "+08:45", label: "UTC+08:45" },
  { value: "+09:00", label: "UTC+09:00" },
  { value: "+09:30", label: "UTC+09:30" },
  { value: "+10:00", label: "UTC+10:00" },
  { value: "+10:30", label: "UTC+10:30" },
  { value: "+11:00", label: "UTC+11:00" },
  { value: "+11:30", label: "UTC+11:30" },
  { value: "+12:00", label: "UTC+12:00" },
  { value: "+12:45", label: "UTC+12:45" },
  { value: "+13:00", label: "UTC+13:00" },
  { value: "+14:00", label: "UTC+14:00" },
];
export const SELETE_LOCALE = [
  {
    id: 1,
    children: [
      { id: 1, title: "Select a locale", value: "" },
      { id: 2, title: "Afrikaans (af)", value: "af" },
      { id: 3, title: "Arabic (ar)", value: "ar" },
      { id: 4, title: "Chinese (zh)", value: "zh" },
      {
        id: 5,
        title: "English (United States) (en-US)",
        value: "en-US",
      },
      { id: 6, title: "French (fr)", value: "fr" },
      { id: 7, title: "German (de)", value: "de" },
    ],
  },
];

export const getLocaleByCode = (code) => {
  if (!code) return "English (United States) (en-US)";
  const selectedLocale = SELETE_LOCALE[0]?.children?.filter(
    (lang) => lang?.value === code
  );
  return selectedLocale?.[0]?.title || "";
};

export const timeModeOptions = [
  {
    id: "0",
    name: "Select an option",
    value: "",
  },
  {
    id: "1",
    name: "AM/PM",
    value: "AM/PM",
  },
  {
    id: "2",
    name: "24 Hour",
    value: "24 Hour",
  },
];

export const timeOptions = [
  { value: "00:00:00", label: "" },
  { value: "00:00:00", label: "12:00 AM" },
  { value: "00:30:00", label: "12:30 AM" },
  { value: "01:00:00", label: "1:00 AM" },
  { value: "01:30:00", label: "1:30 AM" },
  { value: "02:00:00", label: "2:00 AM" },
  { value: "02:30:00", label: "2:30 AM" },
  { value: "03:00:00", label: "3:00 AM" },
  { value: "03:30:00", label: "3:30 AM" },
  { value: "04:00:00", label: "4:00 AM" },
  { value: "04:30:00", label: "4:30 AM" },
  { value: "05:00:00", label: "5:00 AM" },
  { value: "05:30:00", label: "5:30 AM" },
  { value: "06:00:00", label: "6:00 AM" },
  { value: "06:30:00", label: "6:30 AM" },
  { value: "07:00:00", label: "7:00 AM" },
  { value: "07:30:00", label: "7:30 AM" },
  { value: "08:00:00", label: "8:00 AM" },
  { value: "08:30:00", label: "8:30 AM" },
  { value: "09:00:00", label: "9:00 AM" },
  { value: "09:30:00", label: "9:30 AM" },
  { value: "10:00:00", label: "10:00 AM" },
  { value: "10:30:00", label: "10:30 AM" },
  { value: "11:00:00", label: "11:00 AM" },
  { value: "11:30:00", label: "11:30 AM" },
  { value: "12:00:00", label: "12:00 PM" },
  { value: "12:30:00", label: "12:30 PM" },
  { value: "13:00:00", label: "1:00 PM" },
  { value: "13:30:00", label: "1:30 PM" },
  { value: "14:00:00", label: "2:00 PM" },
  { value: "14:30:00", label: "2:30 PM" },
  { value: "15:00:00", label: "3:00 PM" },
  { value: "15:30:00", label: "3:30 PM" },
  { value: "16:00:00", label: "4:00 PM" },
  { value: "16:30:00", label: "4:30 PM" },
  { value: "17:00:00", label: "5:00 PM" },
  { value: "17:30:00", label: "5:30 PM" },
  { value: "18:00:00", label: "6:00 PM" },
  { value: "18:30:00", label: "6:30 PM" },
  { value: "19:00:00", label: "7:00 PM" },
  { value: "19:30:00", label: "7:30 PM" },
  { value: "20:00:00", label: "8:00 PM" },
  { value: "20:30:00", label: "8:30 PM" },
  { value: "21:00:00", label: "9:00 PM" },
  { value: "21:30:00", label: "9:30 PM" },
  { value: "22:00:00", label: "10:00 PM" },
  { value: "22:30:00", label: "10:30 PM" },
  { value: "23:00:00", label: "11:00 PM" },
  { value: "23:30:00", label: "11:30 PM" },
];

export const formatOptions = [
  {
    id: "0",
    name: "Select an option",
    value: "",
  },
  {
    id: "1",
    name: "Date only",
    value: "Date only",
  },
  {
    id: "2",
    name: "Date and time without zone",
    value: "Date and time without zone",
  },
  {
    id: "3",
    name: "Date and time zone",
    value: "Date and time zone",
  },
];
