"use client";

import "./globals.scss";
import SecondaryNav from "@/components/layout/secondaryNav";
import TopNav from "@/components/layout/topNav";
import { ToastProvider } from "@/context/toastContext";
import { Provider } from "react-redux";
import store from "@/store/store";
import { ConsentProvider } from "@/context/consentContext";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";

export default function RootLayout({ children }) {
  const pathname = usePathname();
  const [hideSecondaryNav, setHideSecondaryNav] = useState(false);

  useEffect(() => {
    if (pathname === "/login" || pathname === "/signup") {
      setHideSecondaryNav(true);
    } else {
      setHideSecondaryNav(false);
    }
  }, [pathname]);

  return (
    <html lang="en">
      <body>
        <main>
          <Provider store={store}>
            <ConsentProvider>
              <ToastProvider>
                {!hideSecondaryNav && <TopNav />}
                {!hideSecondaryNav && <SecondaryNav />}
                {children}
              </ToastProvider>
            </ConsentProvider>
          </Provider>
        </main>
      </body>
    </html>
  );
}
