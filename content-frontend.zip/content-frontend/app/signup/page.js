import SignupForm from "@/components/signup/signupForm"
import React from "react"
import styles from "./signup.module.scss"

export default function Signup() {
	return (
		<div className={styles.container}>
			<SignupForm />
		</div>
	)
}
