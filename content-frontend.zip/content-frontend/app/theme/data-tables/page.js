"use client";

import { DataTable } from "@/components/theme/datatable";

const DATA = [
  {
    id: 1,
    date: "20.09.2023",
    product: {
      name: "Product A",
    },
    quantity: 5,
    name: "DIL",
    title:
      "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using",
  },
  {
    id: 2,
    date: "21.09.2023",
    product: {
      name: "Product B",
    },
    quantity: 14,
    name: "DIL",
    title: "ttile",
  },
  {
    id: 4,
    date: "25.09.2023",
    product: {
      name: "Product A",
    },
    quantity: 1,
    name: "DIL",
    title: "ttile",
  },
];

const DataTablesPage = () => {
  const columns = [
    {
      title: "Date",
      key: "date",
      dataIndex: "date",
    },
    {
      title: "Product",
      key: "product.name",
      dataIndex: "product.name",
      styles: {
        minWidth: "7rem",
      },
    },
    {
      title: "Quantity",
      key: "quantity",
      dataIndex: "quantity",
    },
    {
      title: "Name",
      key: "name",
      dataIndex: "name",
    },
    {
      title: "Title",
      key: "title",
      dataIndex: "title",
    },
  ];

  return (
    <div className="p-7">
      <DataTable columns={columns} dataSource={DATA} />
    </div>
  );
};

export default DataTablesPage;
