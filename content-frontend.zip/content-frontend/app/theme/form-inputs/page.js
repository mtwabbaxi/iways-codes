import {
  TextField,
  Radio,
  Checkbox,
  TextArea,
} from "@/components/theme/form-inputs";
import cn from "classnames";
import styles from "./page.module.scss";

const FormInputsPage = () => {
  return (
    <div className={cn(styles.container, "p-7")}>
      <TextField
        placeholder="Search for a content type"
        size="sm"
        label="Name"
      />
      <TextField
        placeholder="Search for a content type"
        label="Name"
        required
        hint="Appears in the entry editor"
        error="Name is required"
        maxLength={50}
      />
      <TextField
        placeholder="Search for a content type"
        size="lg"
        label="Name"
      />

      <TextField placeholder="0.00" type="number" size="lg" />

      <TextArea
        placeholder="Search for a content type"
        label="Name"
        required
        hint="Appears in the entry editor"
        error="Name is required"
        maxLength={50}
      />

      <Radio label="Apple" name="fruit" id="apple" hint="Apple is a fruit." />
      <Radio
        label="Mango"
        name="fruit"
        id="mango"
        hint="Mango is another fruit."
      />
      <Radio
        label="Banana"
        name="fruit"
        id="Banana"
        hint="Banana is good for health."
      />

      <div className="mt-5">
        <Checkbox
          label="Onion"
          name="veg"
          id="Onion"
          hint="Oninn is a vegetable."
        />
      </div>
    </div>
  );
};

export default FormInputsPage;
