import { Tabs } from "@/components/theme/tabs";
import styles from "./page.module.scss";
import cn from "classnames";

const TABS = [
  {
    title: "Home",
  },
  {
    title: "Fields",
  },
  {
    title: "Settings",
  },
];

const TabsPage = () => {
  return (
    <div className="p-8">
      <div>
        <Tabs size="sm" tabs={TABS} />
      </div>
      <div className="mt-5">
        <Tabs size="md" tabs={TABS} />
      </div>
      <div className="mt-5">
        <Tabs size="lg" tabs={TABS} />
      </div>
      <div className={cn("mt-5", styles["vertical-container"])}>
        <Tabs size="sm" tabs={TABS} direction="vertical" />
        <Tabs size="md" tabs={TABS} direction="vertical" />
        <Tabs size="lg" tabs={TABS} direction="vertical" />
      </div>

      <div className={cn("mt-5", styles["vertical-container"])}>
        <Tabs size="sm" variant="default" tabs={TABS} direction="vertical" />
        <Tabs size="md" variant="default" tabs={TABS} direction="vertical" />
        <Tabs size="lg" variant="default" tabs={TABS} direction="vertical" />
      </div>

      <div className={cn("mt-5", styles["vertical-container"])}>
        <Tabs size="sm" variant="secondary" tabs={TABS} direction="vertical" />
        <Tabs size="md" variant="secondary" tabs={TABS} direction="vertical" />
        <Tabs size="lg" variant="secondary" tabs={TABS} direction="vertical" />
      </div>
    </div>
  );
};

export default TabsPage;
