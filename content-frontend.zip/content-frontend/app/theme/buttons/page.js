"use client";

import { Button, IconButton } from "@/components/theme/buttons";
import styles from "./page.module.scss";
import cn from "classnames";
import { FaEllipsis } from "react-icons/fa6";
import { AiOutlinePlus, AiOutlineArrowRight } from "react-icons/ai";
import { useToast } from "@/context/toastContext";
import { useConsent } from "@/context/consentContext";
import { Alert } from "@/components/theme/alerts";

const ButtonsPage = () => {
  const { addToast } = useToast();
  const { takeConsent, closeConsent } = useConsent();

  return (
    <div className="p-7">
      <div className={styles.container}>
        <Button
          text="Show Toast"
          onClick={() => {
            addToast(
              "It is a long established fact that a reader will be distracted."
            );
          }}
          variant="default"
          startIcon={AiOutlinePlus}
          endIcon={AiOutlineArrowRight}
        />
        <IconButton icon={FaEllipsis} variant="default" />
        <Button
          text="Button size:md variant:default"
          variant="default"
          size="md"
          startIcon={AiOutlinePlus}
          endIcon={AiOutlineArrowRight}
          onClick={() => {
            addToast(
              "It is a long established fact that a reader will be distracted.",
              { type: "error" }
            );
          }}
        />

        <Button
          text="Button size:lg variant:default"
          variant="default"
          size="lg"
          disabled
          startIcon={AiOutlinePlus}
          endIcon={AiOutlineArrowRight}
        />
      </div>
      <div className={cn(styles.container, "mt-5")}>
        <Button
          text="Button size:sm variant:primary"
          variant="primary"
          onClick={() => {
            addToast(
              "It is a long established fact that a reader will be distracted.",
              { type: "warning" }
            );
          }}
        />
        <Button
          text="Button size:md variant:primary"
          variant="primary"
          size="md"
          startIcon={AiOutlinePlus}
          endIcon={AiOutlineArrowRight}
          onClick={() => {
            addToast(
              "It is a long established fact that a reader will be distracted.",
              { type: "info" }
            );
          }}
        />
        <Button
          text="Button size:lg variant:primary"
          variant="primary"
          size="lg"
          disabled
        />
      </div>
      <div className={cn(styles.container, "mt-5")}>
        <Button
          text="Click for consent"
          variant="secondary"
          onClick={() => {
            takeConsent({
              message: (
                <div className="text-body2">
                  <div className="mb-5">
                    We've found 1 entries which use the content type About Info
                    Module. Content types that are currently used by entries
                    can't be deleted. Why?
                  </div>
                  <Alert
                    text={
                      <div>
                        Delete all{" "}
                        <span className="font-weight-semi-bold">
                          entries and archived entries
                        </span>{" "}
                        which use this content type before deleting it.
                      </div>
                    }
                  />
                  <div className="my-5">
                    Use the status filter "Archived" in the content page to be
                    able to see the archived entries.
                  </div>
                  <div>
                    <Button
                      text="Okay, got it"
                      className="ml-auto"
                      onClick={closeConsent}
                    />
                  </div>
                </div>
              ),
              heading: "This content type can't be deleted right now.",
            });
          }}
        />
        <Button
          text="Button size:md variant:secondary"
          variant="secondary"
          size="md"
        />
        <Button
          text="Button size:lg variant:secondary"
          variant="secondary"
          size="lg"
          disabled
          startIcon={AiOutlinePlus}
          endIcon={AiOutlineArrowRight}
        />
      </div>
    </div>
  );
};

export default ButtonsPage;
