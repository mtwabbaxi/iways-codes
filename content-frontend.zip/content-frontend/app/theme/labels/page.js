import { Label } from "@/components/theme/labels";
import styles from "./page.module.scss";
import cn from "classnames";

const LabelsPage = () => {
  return (
    <div className={cn("p-7", styles.container)}>
      <Label text="Entry title" />
      <Label text="Entry title" variant="primary" />
      <Label text="Entry title" variant="secondary" />
      <Label text="Entry title" variant="warning" />
      <Label text="Entry title" variant="error" />
    </div>
  );
};

export default LabelsPage;
