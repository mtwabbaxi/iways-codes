import { ContextMenu } from "@/components/theme/menus";

const MenusPage = () => {
  const menuOptions = [{ id: 1, title: "Delete" }];

  return (
    <div>
      <ContextMenu options={menuOptions} />
    </div>
  );
};

export default MenusPage;
