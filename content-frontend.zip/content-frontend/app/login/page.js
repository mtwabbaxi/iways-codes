import LoginForm from "@/components/login/loginForm"
import React from "react"
import styles from "./login.module.scss"
import Link from "next/link"
import {APP_URLS, replaceUrlParams} from "@/utils/constants"

export default function Login() {
	return (
		<div className={styles.container}>
			<div className={styles.header}>
				<p>
					New to Contentful?{" "}
					<Link href={replaceUrlParams(APP_URLS.SIGNUP)}>Sign up</Link>
				</p>
			</div>
			<LoginForm />
		</div>
	)
}
