import KeyDetails from "@/components/apiKeyDetails/keyDetails";
import React from "react";
export default function ApiKeyDetails() {
  return (
    <>
      <KeyDetails />
    </>
  );
}
