import Header from "@/components/apiKeys/Header";
import KeysTableAndSidebar from "@/components/apiKeys/keysTableAndSidebar";
import React from "react";

export default function API_KEYS() {
  return (
    <>
      <Header />
      <KeysTableAndSidebar />
    </>
  );
}
