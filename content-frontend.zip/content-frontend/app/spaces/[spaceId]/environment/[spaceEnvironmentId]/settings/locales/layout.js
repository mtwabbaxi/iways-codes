"use client"

import styles from "./layout.module.scss"
import {useParams, usePathname} from "next/navigation"
import {useSelector, useDispatch} from "react-redux"
import {useLayoutEffect} from "react"
import cn from "classnames"
import Header from "@/components/locales/header"
import Sidebar_Right from "@/components/locales/sidebar_right"

const Layout = ({children}) => {
	const dispatch = useDispatch()
	const params = useParams()
	const pathname = usePathname()
	const {localeId} = params

	if (pathname.includes("create") || localeId) {
		return (
			<>
				<div className={styles["header-container"]}>
					<Header page="create" />
				</div>
				<div className={cn(styles["create-container"], styles["with-data"])}>
					<div className={styles.content}>{children}</div>
				</div>
			</>
		)
	}

	return (
		<>
			<div className={styles["header-container"]}>
				<Header />
			</div>
			<div className={cn(styles["grid-container"], styles["with-data"])}>
				<div className={styles.content}>{children}</div>
				<div className={styles.env_sidebar_wrapper}>
					<Sidebar_Right />
				</div>
			</div>
		</>
	)
}

export default Layout
