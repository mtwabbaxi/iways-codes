import dynamic from "next/dynamic"
import Loader from "@/components/shared/skeletonLoading"
const TableEnvironments = dynamic(
	() => import("@/components/environments/tableEnvironments"),
	{
		loading: () => <Loader count={10} />, // Optional loading component
		ssr: false, // Set to false to disable server-side rendering
	}
)
export default function ContentModels() {
	return <TableEnvironments />
}
