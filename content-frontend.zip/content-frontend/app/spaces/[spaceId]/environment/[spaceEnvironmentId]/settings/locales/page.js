import dynamic from "next/dynamic"
import Loader from "@/components/shared/skeletonLoading"
const LocalsList = dynamic(() => import("@/components/locales/localesList"), {
	loading: () => <Loader count={10} />,
	ssr: false,
})
export default function LocalesPage() {
	return <LocalsList />
}
