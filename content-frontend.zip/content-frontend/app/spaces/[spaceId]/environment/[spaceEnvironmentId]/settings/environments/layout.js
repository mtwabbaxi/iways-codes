"use client"

import styles from "./layout.module.scss"
import Sidebar from "@/components/contentModel/sidebar"
import {useParams} from "next/navigation"
import {useSelector, useDispatch} from "react-redux"
import {useLayoutEffect} from "react"
import {getContentModelById} from "@/store/actions/contentModel"
import cn from "classnames"
import Header from "@/components/environments/header"
import Sidebar_Right from "@/components/environments/sidebar_right"

const Layout = ({children}) => {
	const dispatch = useDispatch()
	const params = useParams()
	const {selectedContentModel, loading, deleting} = useSelector(
		(state) => state.contentModel
	)
	const {contentModelId} = params

	useLayoutEffect(() => {
		dispatch(getContentModelById(contentModelId))
	}, [contentModelId])

	return (
		<>
			<div className={styles["header-container"]}>
				<Header />
			</div>
			<div className={cn(styles["grid-container"], styles["with-data"])}>
				<div className={styles.content}>{children}</div>
				<div className={styles.env_sidebar_wrapper}>
					<Sidebar_Right />
				</div>
			</div>
		</>
	)
}

export default Layout
