import LocalesCreateForm from "@/components/locales/localesCreateForm/localesCreateForm"

export default function MediaCreate({}) {
	return <LocalesCreateForm />
}
