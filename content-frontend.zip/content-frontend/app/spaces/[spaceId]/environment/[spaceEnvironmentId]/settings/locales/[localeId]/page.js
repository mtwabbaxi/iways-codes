"use client"
import LocalesCreateForm from "@/components/locales/localesCreateForm/localesCreateForm"

export default function LocalesUpdate() {
	return <LocalesCreateForm isEditMode />
}
