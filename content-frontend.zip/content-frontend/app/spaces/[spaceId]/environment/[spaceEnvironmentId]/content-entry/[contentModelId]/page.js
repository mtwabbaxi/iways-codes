"use client";
import dynamic from "next/dynamic";
import Loader from "@/components/shared/skeletonLoading";
const ContentForm = dynamic(
  () => import("@/components/content/contentForm/contentForm"),
  {
    loading: () => <Loader count={10} />, // Optional loading component
    ssr: false, // Set to false to disable server-side rendering
  },
);
export default function CreateContentForm() {
  return <ContentForm />;
}
