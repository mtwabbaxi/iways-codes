"use client";
import dynamic from "next/dynamic";
const ContentForm = dynamic(
  () => import("@/components/content/contentForm/contentForm"),
);
export default function ContentEntryUpdate() {
  return <ContentForm isEditMode page="content" />;
}
