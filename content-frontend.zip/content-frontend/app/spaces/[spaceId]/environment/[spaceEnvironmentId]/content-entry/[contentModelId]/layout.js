"use client"

import styles from "./layout.module.scss"
import Sidebar from "@/components/contentModel/sidebar"
import Sidebar_Right from "@/components/media/sidebar_right"
import {useParams} from "next/navigation"
import {useSelector, useDispatch} from "react-redux"
import {useLayoutEffect} from "react"
import {getContentModelById} from "@/store/actions/contentModel"
import cn from "classnames"
import Header from "@/components/contentModel/header"
import Link from "next/link"
import {APP_URLS, replaceUrlParams} from "@/utils/constants"
import {BsArrowLeft} from "react-icons/bs"

const Layout = ({children}) => {
	const dispatch = useDispatch()
	const params = useParams()
	const {selectedContentModel, loading, deleting} = useSelector(
		(state) => state.contentModel
	)
	const {contentEntryValues, contentCurrTitle} = useSelector(
		(state) => state.contentEntries
	)
	const {spaceId, spaceEnvironmentId} = params

	// useLayoutEffect(() => {
	//   dispatch(getContentModelById(contentModelId));
	// }, [contentModelId]);

	return (
		<>
			<div className={styles["header-container"]}>
				<header className={styles.header}>
					<Link
						href={replaceUrlParams(APP_URLS.CONTENT.LIST, {
							spaceId: spaceId,
							spaceEnvironmentId: spaceEnvironmentId,
						})}
					>
						<div className={styles.back}>
							<BsArrowLeft />
						</div>
					</Link>
					<p className="m-0 color-gray-500 text-body1">/</p>
					<div className={styles.contentTypeTitle}>
						<h5 className="m-0 text-caption leading-4">
							{selectedContentModel && selectedContentModel.name}
						</h5>
						<h3 className="m-0">
							{loading
								? "Please wait..."
								: contentCurrTitle.length > 0
								  ? contentCurrTitle
								  : contentEntryValues
								    ? contentEntryValues.name
								    : "Untitled"}
						</h3>
					</div>
				</header>
			</div>
			<div
				className={cn(
					styles["grid-container"],
					styles["with-data"],
					styles["create-page"]
				)}
			>
				<div className={styles.content}>{children}</div>
				<div className={styles.create_sidebar_wrapper}>
					<Sidebar_Right />
				</div>
			</div>
		</>
	)
}

export default Layout
