import dynamic from "next/dynamic";
import Loader from "@/components/shared/skeletonLoading";
const TableContent = dynamic(() => import("@/components/media/tableContent"), {
  loading: () => <Loader count={10} />, // Optional loading component
  ssr: false, // Set to false to disable server-side rendering
});
export default function Media() {
  return <TableContent />;
}
