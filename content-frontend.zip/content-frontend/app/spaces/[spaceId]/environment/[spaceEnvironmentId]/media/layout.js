"use client";

import styles from "./layout.module.scss";
import Sidebar from "@/components/contentModel/sidebar";
import Sidebar_Right from "@/components/media/sidebar_right";
import { useParams, useRouter } from "next/navigation";
import { useSelector, useDispatch } from "react-redux";
import { useEffect, useLayoutEffect } from "react";
import { getContentModelById } from "@/store/actions/contentModel";
import { setCreateMediaOpen } from "@/store/actions/media";
import cn from "classnames";
import Header from "@/components/contentModel/header";
import Link from "next/link";
import { APP_URLS, replaceUrlParams } from "@/utils/constants";
import { BsArrowLeft } from "react-icons/bs";
import ToolTip from "@/components/theme/toolTip";
import { ContextMenu } from "@/components/theme/menus";
import { usePathname } from "next/navigation";
import Modal from "@/components/shared/modal";
import MediaCreate from "./create/page";
import { useState } from "react";
import ConfirmPopup from "@/components/content/confirmPopup/confirmPopup";
import MediaConfirmPopup from "@/components/media/mediaConfirmPopup/mediaConfirmPopup";
import { deleteAsset, fetchAllMediaAsset } from "@/store/actions/media";
import { useToast } from "@/context/toastContext";

const Layout = ({ children }) => {
  const params = useParams();
  const { assetId, spaceId, spaceEnvironmentId } = params;
  const pathname = usePathname();
  const dispatch = useDispatch();
  const { addToast } = useToast();
  const router = useRouter();
  const { selectedContentModel, loading, deleting } = useSelector(
    (state) => state.contentModel
  );
  const { assetValues, createMediaCurrTitle } = useSelector(
    (state) => state.media
  );
  const [isMediaDeletePopupOpen, setIsMediaDeletePopupOpen] = useState(false);
  const [isDeleteConfirmed, setisDeleteConfirmed] = useState(false);
  const [isExistingTitle, setIsExistingTitle] = useState("");

  const handleDeleteConfirmPopup = async () => {
    setIsMediaDeletePopupOpen(true);
  };

  const handleDelete = async () => {
    try {
      let res = null;
      res = await dispatch(
        deleteAsset(assetValues.assetId, spaceId, spaceEnvironmentId)
      );
      const {
        result: { body },
      } = res;
      console.log(body);
      if (body.responseCode === 200) {
        addToast(body.responseMessage);
        dispatch(fetchAllMediaAsset(spaceId, spaceEnvironmentId));
        router.push(
          replaceUrlParams(APP_URLS.MEDIA.LIST, {
            spaceId: spaceId,
            spaceEnvironmentId: spaceEnvironmentId,
          })
        );
      } else {
        addToast(body?.responseMessage || "An unknown error occured!", {
          type: "error",
        });
      }
    } catch (err) {
      console.log("error: ", err);
    } finally {
      setIsMediaDeletePopupOpen(false);
      setisDeleteConfirmed(false);
    }
  };

  useLayoutEffect(() => {
    if (isDeleteConfirmed) {
      if (assetValues?.assetId) {
        handleDelete();
      } else {
        router.back();
      }
    } else {
      setIsMediaDeletePopupOpen(false);
    }
  }, [isDeleteConfirmed]);

  useLayoutEffect(() => {
    if (pathname.includes("create")) {
      setIsExistingTitle("");
    } else {
      setIsExistingTitle(assetValues?.title);
    }
  }, []);

  if (pathname.includes("create") || assetId) {
    return (
      <>
        <div className={styles["header-container-create"]}>
          <header className={styles.header}>
            <Link
              href={replaceUrlParams(APP_URLS.MEDIA.LIST, {
                spaceId: spaceId,
                spaceEnvironmentId: spaceEnvironmentId,
              })}
            >
              <div className={styles.back}>
                <BsArrowLeft />
              </div>
            </Link>
            <p className="m-0 color-gray-500 text-body1">/</p>
            <div className={styles.assetTitle}>
              <h5 className="m-0 text-caption leading-4">
                {loading ? "Please wait..." : "Asset"}
              </h5>
              <h3 className="m-0">
                {createMediaCurrTitle.length > 0
                  ? createMediaCurrTitle
                  : isExistingTitle
                    ? isExistingTitle
                    : "Untitled"}
              </h3>
            </div>
          </header>
          <div className={styles.actions}>
            {deleting ? (
              <Button text="Deleting ..." variant="default" />
            ) : (
              <button
                className={styles.deletePopup}
                onClick={() => handleDeleteConfirmPopup()}
              >
                Delete
              </button>
            )}
          </div>
          {isMediaDeletePopupOpen && (
            <MediaConfirmPopup
              setIsContentDeletePopupOpen={setIsMediaDeletePopupOpen}
              setisDeleteConfirmed={setisDeleteConfirmed}
              message="Are you sure you want to delete this media?"
              assetValues={assetValues}
            />
          )}
        </div>
        <div
          className={cn(
            styles["grid-container"],
            styles["with-data"],
            styles["create-page"]
          )}
        >
          <div className={styles.content}>{children}</div>
          <div className={styles.create_sidebar_wrapper}>
            <Sidebar_Right media />
          </div>
        </div>
      </>
    );
  }

  // useLayoutEffect(() => {
  //   dispatch(getContentModelById(contentModelId));
  // }, [contentModelId]);

  // useEffect(() => {
  // 	dispatch(setCreateMediaOpen(createNewMedia))
  // }, [createNewMedia])

  return (
    <>
      <div className={styles["header-container"]}>
        <Header pageType="media" />
      </div>
      <div className={cn(styles["grid-container"], styles["with-data"])}>
        <Sidebar
          fieldCount={selectedContentModel?.fields?.length}
          // contentModelId={contentModelId}
          pageType="media"
        />
        <div className={styles.content}>{children}</div>
      </div>
    </>
  );
};

export default Layout;
