"use client";
import ContentForm from "@/components/content/contentForm/contentForm";
import CreateForm from "@/components/media/createForm/createForm";

export default function ContentEntryUpdate() {
  return <CreateForm isEditMode />;
}
