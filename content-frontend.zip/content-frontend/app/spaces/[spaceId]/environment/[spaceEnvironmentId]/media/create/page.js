import CreateForm from "@/components/media/createForm/createForm"

export default function MediaCreate() {
	return <CreateForm />
}
