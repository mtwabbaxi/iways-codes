import styles from "./page.module.scss";
import cn from "classnames";
import Card from "@/components/shared/card";

// icons
import { FcCollaboration, FcDocument } from "react-icons/fc";

const CARDS = [
  {
    id: 1,
    title: "Invite teammates",
    linkText: "Invite teammates",
    description: "Collaborate with your team members.",
    icon: FcCollaboration,
  },
  {
    id: 1,
    title: "Documentation",
    linkText: "Open docs",
    description: "Discover and search through our docs",
    icon: FcDocument,
  },
];

export default function Home() {

  return (
    <main className={cn(styles.main, "bg-gray-300")}>
      <div className={styles["cards-container"]}>
        {CARDS.map((m) => (
          <Card key={m.id} data={m} />
        ))}
      </div>
      
    </main>
  );
}
