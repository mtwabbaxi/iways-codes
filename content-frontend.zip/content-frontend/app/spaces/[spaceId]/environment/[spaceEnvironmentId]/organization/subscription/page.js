import Header from "@/components/organization/subscription/header";
import Details from "@/components/organization/subscription/details";
import React from "react";

export default function Subscription() {
  return (
    <>
      <Header />
      <Details />
    </>
  );
}
