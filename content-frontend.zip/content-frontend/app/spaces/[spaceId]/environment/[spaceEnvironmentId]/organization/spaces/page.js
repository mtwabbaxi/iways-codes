import Details from "@/components/organization/spaces/details";
import Header from "@/components/organization/spaces/header";
import React from "react";

export default function OrganizationSpaces() {
  return (
    <>
      <Header />
      <Details />
    </>
  );
}
