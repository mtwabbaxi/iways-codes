"use client";

import styles from "./layout.module.scss";
import Sidebar from "@/components/contentModel/sidebar";
import { useParams } from "next/navigation";
import { useSelector, useDispatch } from "react-redux";
import { useLayoutEffect } from "react";
import { getContentModelById } from "@/store/actions/contentModel";
import cn from "classnames";
import Header from "@/components/contentModel/header";

const Layout = ({ children }) => {
  const dispatch = useDispatch();
  const params = useParams();
  const { selectedContentModel, loading, deleting } = useSelector(
    (state) => state.contentModel,
  );
  const { contentModelId } = params;

  useLayoutEffect(() => {
    dispatch(getContentModelById(contentModelId));
  }, [contentModelId]);

  return (
    <>
      <div className={styles["header-container"]}>
        <Header pageType="content" />
      </div>
      <div className={cn(styles["grid-container"], styles["with-data"])}>
        <Sidebar
          fieldCount={selectedContentModel?.fields?.length}
          contentModelId={contentModelId}
          isSideBar
          pageType="content"
        />
        <div className={styles.content}>{children}</div>
      </div>
    </>
  );
};

export default Layout;
