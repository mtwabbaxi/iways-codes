"use client";

import styles from "./layout.module.scss";
import Sidebar from "@/components/contentModel/sidebar";
import Link from "next/link";
import { ContextMenu } from "@/components/theme/menus";
import { Button } from "@/components/theme/buttons";
import { BsArrowLeft } from "react-icons/bs";
import {APP_URLS, replaceUrlParams} from "@/utils/constants";
import { useConsent } from "@/context/consentContext";
import { useParams, usePathname } from "next/navigation";
import { useSelector, useDispatch } from "react-redux";
import {
  useLayoutEffect,
  useCallback,
  useState,
  useMemo,
  useEffect,
} from "react";
import { useRouter } from "next/navigation";
import {
  getContentModelById,
  deleteContentModel,
} from "@/store/actions/contentModel";
import { useToast } from "@/context/toastContext";
import cn from "classnames";
import { Alert } from "@/components/theme/alerts";
import { MdOutlineContentCopy } from "react-icons/md";
import ToolTip from "@/components/theme/toolTip";

const Layout = ({ children }) => {
  const { addToast } = useToast();
  const router = useRouter();
  const dispatch = useDispatch();
  const params = useParams();
  const { selectedContentModel, loading, deleting } = useSelector(
    (state) => state.contentModel,
  );
  const { contentModelId, spaceId, spaceEnvironmentId} = params;
  const pathname = usePathname();

  const { takeConsent, closeConsent } = useConsent();

  const activeTabIndex = useMemo(() => {
    if (pathname.includes("update-model")) {
      return 1;
    }
    return 0;
  }, [pathname]);

  useLayoutEffect(() => {
    dispatch(getContentModelById(contentModelId));
  }, [contentModelId]);

  const handleDelete = useCallback(async () => {
    try {
      closeConsent();
      if (contentModelId) {
        const res = await dispatch(deleteContentModel(contentModelId, spaceId, spaceEnvironmentId));
        const {
          result: { body },
        } = res;
        if (body.responseCode === 200) {
          addToast(body.responseMessage);
          router.push(`${replaceUrlParams(APP_URLS.CONTENT_MODELS.LIST, { spaceId, spaceEnvironmentId })}`);
        } else {
          addToast(body?.responseMessage || "An unknown error occured!", {
            type: "error",
          });
        }
      }
    } catch (err) {
      console.error(err);
    }
  }, [contentModelId, closeConsent, dispatch, router.push]);

  const [tooltipText, setTooltipText] = useState("Copy to clipboard");

  const copyToClipboard = (textToCopy) => {
    const el = document.createElement("textarea");
    el.value = textToCopy;
    el.setAttribute("readonly", "");
    el.style.position = "absolute";
    el.style.left = "-9999px";
    document.body.appendChild(el);
    const selected =
      document.getSelection().rangeCount > 0
        ? document.getSelection().getRangeAt(0)
        : false;
    el.select();
    document.execCommand("copy");
    document.body.removeChild(el);
    if (selected) {
      document.getSelection().removeAllRanges();
      document.getSelection().addRange(selected);
    }

    setTooltipText("Copied");
    setTimeout(() => {
      setTooltipText("Copy to clipboard");
    }, 1300);
  };

  return (
    <>
      <div className={styles["header-container"]}>
        <header className={styles.header}>
          <Link href={replaceUrlParams(APP_URLS.CONTENT_MODELS.LIST, { spaceId, spaceEnvironmentId })}>
            <div className={styles.back}>
              <BsArrowLeft />
            </div>
          </Link>
          <p className="m-0 color-gray-500 text-body1">/</p>
          <p className="m-0 font-weight-semi-bold text-body1">
            {loading ? "Please wait..." : selectedContentModel?.name}
          </p>
          <ToolTip direction="right" text={tooltipText}>
            <Button
              className={cn(styles["copy-button"], "text-body1")}
              startIcon={MdOutlineContentCopy}
              variant="default"
              text="Copy ID"
              onClick={() => copyToClipboard(contentModelId)}
            />
          </ToolTip>
        </header>
        <div className={styles.actions}>
          {deleting ? (
            <Button text="Deleting ..." variant="default" />
          ) : (
            <ContextMenu
              options={[
                {
                  id: 1,
                  title: "Delete",
                  onClick: () => {
                    takeConsent({
                      message: (
                        <div className="text-body2">
                          <div className="mb-5">
                            Are you sure you want to delete this content model?
                          </div>
                          {Boolean(selectedContentModel?.fields?.length) && (
                            <div className="mt-5 mb-5">
                              <div className="mb-5">
                                We've found {selectedContentModel.fields.length}{" "}
                                {selectedContentModel.fields.length > 1
                                  ? "fields"
                                  : "field"}{" "}
                                which use
                                {selectedContentModel.fields.length === 1 &&
                                  "s"}{" "}
                                the content model {selectedContentModel.name}.
                                Content models that are currently used by fields
                                should be deleted carefully.
                              </div>
                              <Alert
                                text="Deleting this content model can create data inconsistencies. It's an irreversible opertaion."
                                variant="error"
                              />
                            </div>
                          )}
                          <div className="actions-container">
                            <Button
                              text="Cancel"
                              variant="default"
                              onClick={closeConsent}
                            />
                            <Button
                              text="Delete"
                              variant="error"
                              onClick={handleDelete}
                            />
                          </div>
                        </div>
                      ),
                      heading: "Delete content model",
                    });
                  },
                },
              ]}
            />
          )}
        </div>
      </div>
      <div className={cn(styles["grid-container"], styles["with-data"])}>
        <Sidebar
          activeTabIndex={activeTabIndex}
          fieldCount={selectedContentModel?.fields?.length}
          contentModelId={contentModelId}
        />
        <div className={styles.content}>{children}</div>
      </div>
    </>
  );
};

export default Layout;
