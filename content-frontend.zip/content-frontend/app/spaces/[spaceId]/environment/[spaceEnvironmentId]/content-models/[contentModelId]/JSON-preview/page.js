"use client";

import JSONPreview from "@/components/contentModel/JSONPreview";

const UpdateContentModelPage = () => {
  return (
    <div>
      <JSONPreview />
    </div>
  );
};

export default UpdateContentModelPage;
