import ContentFieldsDetails from "@/components/contentFields/contentFieldsDetails";

export default function ContentFields() {
  return <ContentFieldsDetails />;
}
