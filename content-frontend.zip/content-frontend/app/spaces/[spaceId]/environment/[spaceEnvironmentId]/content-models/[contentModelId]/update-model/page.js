"use client";

import CreateUpdateContentTypeForm from "@/components/contentModel/createUpdateContentTypeForm";

const UpdateContentModelPage = () => {
  return (
    <div>
      <CreateUpdateContentTypeForm isEditMode />
    </div>
  );
};

export default UpdateContentModelPage;
