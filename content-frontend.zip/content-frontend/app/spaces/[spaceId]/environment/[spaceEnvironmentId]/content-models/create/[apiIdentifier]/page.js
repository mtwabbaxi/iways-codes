import Header from "@/components/contentModel/creation/header";
import dynamic from "next/dynamic";
import React from "react";

const ContentFieldsDetails = dynamic(
  () => import("@/components/contentFields/contentFieldsDetails")
);

export default function ContentModelCreationWithFirstField() {
  return (
    <>
      <Header />
      <ContentFieldsDetails />
    </>
  );
}
