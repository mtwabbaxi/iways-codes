import { NextResponse } from "next/server";
import { NextRequest } from "next/server";

export function middleware(req) {
  const requestUrl = req.url;
  const authCookies = req.cookies.get("auth");
  const authenticated = authCookies
    ? JSON.parse(authCookies.value).sessionToken
    : null;

  const originalUrl =
    req.nextUrl.protocol + req.headers.get("host") + req.nextUrl.pathname;

  // Check if the user is not authenticated and the current URL is not the login page
  if (!authenticated && !requestUrl.includes("/login")) {
    return NextResponse.redirect(new URL("/login", originalUrl));
  }

  // Allow the request to proceed if authenticated or on the login page
  return NextResponse.next();
}

export const config = {
  matcher: [
    "/spaces/:path*/content-models/:path*",
    "/spaces/:path*/content-models/:path*/update-model",
    "/spaces/:path*/content",
    "/",
    "/spaces/:path*/content-models",
    "/spaces/:path*/media",
    "/spaces/:path*/media/:path*",
    "/spaces/:path*/content-entry/:path*",
    "/spaces/:path*/content/:path*/:path*",
  ],
};
