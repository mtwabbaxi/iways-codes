let CONTENT_MANAGEMENT_SERVICE_URL;
let USER_SERVICE_URL;

// To Do: Why local is hard coded?

if (process.env.REACT_APP_ENV === "live") {
  CONTENT_MANAGEMENT_SERVICE_URL =
    "https://content-management-service-dev.internal.pwr.dev/v3/api-docs";
  USER_SERVICE_URL =
    "https://contentful-user-service-dev.internal.pwr.dev/v3/api-docs";
} else if (process.env.REACT_APP_ENV === "development") {
  CONTENT_MANAGEMENT_SERVICE_URL =
    "https://content-management-service-dev.internal.pwr.dev/v3/api-docs";
  USER_SERVICE_URL =
    "https://contentful-user-service-dev.internal.pwr.dev/v3/api-docs";
} else {
  CONTENT_MANAGEMENT_SERVICE_URL =
    "https://content-management-service-dev.internal.pwr.dev/v3/api-docs";
  USER_SERVICE_URL =
    "https://contentful-user-service-dev.internal.pwr.dev/v3/api-docs";
}

// if (process.env.REACT_APP_ENV_BUILD_TIME) {
//   REACT_APP_ENV_BUILD_TIME = process.env.REACT_APP_ENV_BUILD_TIME;
// } else {
//   REACT_APP_ENV_BUILD_TIME = new Date().getTime();
// }

export { CONTENT_MANAGEMENT_SERVICE_URL, USER_SERVICE_URL };
