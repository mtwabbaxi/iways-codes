/** @type {import('next').NextConfig} */
const path = require("path");

const nextConfig = {
  output: "standalone",
  images: {
    domains: ["img.freepik.com"],
  },
  sassOptions: {
    includePaths: [path.join(__dirname, "styles")],
    prependData: '@import "_theme_colors.scss"; @import "_breakpoints.scss";',
  },
};

module.exports = nextConfig;
