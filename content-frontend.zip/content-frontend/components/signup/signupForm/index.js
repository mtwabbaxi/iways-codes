"use client"

import React, {useState, useEffect} from "react"
import styles from "./signupForm.module.scss"
import cn from "classnames"
import {TextField} from "@/components/theme/form-inputs"
import {Button} from "@/components/theme/buttons"
import * as yup from "yup"
import {yupResolver} from "@hookform/resolvers/yup"
import {Controller, FormProvider, useForm} from "react-hook-form"
import {useDispatch, useSelector} from "react-redux"
import {signup} from "@/store/actions/user"
import {useToast} from "@/context/toastContext"
import {useRouter} from "next/navigation"
import {fetchAllSpaces, fetchEnvironmentBySpaceId} from "@/store/actions/spaces"
import {APP_URLS, replaceUrlParams} from "@/utils/constants"
import DropdownField from "../../shared/dropdownfield/dropdownfield"
import Link from "next/link"
import {
	AiOutlineEye,
	AiOutlineEyeInvisible,
	AiOutlineCheck,
	AiOutlineClose,
} from "react-icons/ai"

const schema = yup.object({
	fullname: yup.string().required("Full Name is required"),
	company: yup.string().required("Company is required"),
	email: yup
		.string()
		.required("Email is required")
		.matches(
			/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$/,
			"Invalid email address"
		),
	password: yup.string().required("Password is required"),
})

export default function SignupForm() {
	const [selectedJobTitle, setSelectedJobTitle] = useState("")
	const [selectedJobFunction, setSelectedJobFunction] = useState("")
	const [showPassword, setShowPassword] = useState(false)
	const [passwordValidation, setPasswordValidation] = useState({
		uppercase: false,
		lowercase: false,
		number: false,
		length: false,
		secure: false,
	})
	const methods = useForm({
		defaultValues: {
			email: "",
			password: "",
		},
		mode: "onChange",
		resolver: yupResolver(schema),
	})

	const {
		handleSubmit,
		control,
		formState: {errors},
	} = methods

	const JOB_TITLE = [
		{
			id: 1,
			children: [
				{id: 1, title: "Choose ...", value: ""},
				{id: 2, title: "C-Level", value: "C_LEVEL"},
				{id: 3, title: "Vice President", value: "VICE_PRESIDENT"},
				{id: 4, title: "Director", value: "DIRECTOR"},
				{id: 5, title: "Manager", value: "MANAGER"},
				{
					id: 6,
					title: "Individual Contributor",
					value: "INDIVIDUAL_CONTRIBUTOR",
				},
				{id: 7, title: "Consultany", value: "CONSULTANT"},
				{id: 8, title: "Other", value: "OTHER"},
			],
		},
	]

	const JOB_FUNCTION = [
		{
			id: 1,
			children: [
				{id: 1, title: "Choose ...", value: ""},
				{id: 2, title: "Customer Experience", value: "CUSTOMER_EXPERIENCE"},
				{
					id: 3,
					title: "Developer / Engineering / Programming",
					value: "DEVELOPER_ENGINEERING_PROGRAMMING",
				},
				{id: 4, title: "Digital", value: "DIGITAL"},
				{id: 5, title: "HR", value: "HR"},
				{
					id: 6,
					title: "Information Technology",
					value: "INFORMATION_TECHNOLOGY",
				},
				{id: 7, title: "Marketing", value: "MARKETING"},
				{id: 8, title: "Procurement", value: "PROCUREMENT"},
				{id: 9, title: "Product", value: "PRODUCT"},
				{id: 10, title: "Sales", value: "SALES"},
				{id: 11, title: "Security", value: "SECURITY"},
				{id: 12, title: "Other", value: "OTHER"},
			],
		},
	]

	const dispatch = useDispatch()
	const {addToast} = useToast()
	const {allSpaces, environment} = useSelector((state) => state.spaces)
	const {user} = useSelector((state) => state.user)
	const router = useRouter()

	const onSubmit = async (values) => {
		const words = values?.fullname.split(" ")
		const firstname = words[0]
		const lastname = words.slice(1).join(" ")

		try {
			const reqData = {
				firstName: firstname,
				lastName: lastname,
				email: values.email,
				company: values?.company,
				password: values?.password,
				jobTitle: selectedJobTitle?.value,
				jobFunction: selectedJobFunction?.value,
			}
			const res = await dispatch(signup(reqData))
			const {data = null, description = ""} = res?.result?.body || {}
			const {status = 0} = res?.error?.response || {}
			if (!data && status !== 403) {
				addToast(description || res?.error?.response?.body?.description, {
					type: "error",
				})
			} else if (status === 403) {
				addToast(res?.error?.message, {type: "error"})
			} else {
				addToast(description)
				window.location.href = "/login"
			}
		} catch (err) {
			console.log("error:", err)
		} finally {
		}
	}

	useEffect(() => {
		if (user && allSpaces && allSpaces.content.length) {
			const spaceId = allSpaces.content[0].spaceId
			dispatch(fetchEnvironmentBySpaceId(spaceId))
		}
	}, [allSpaces])

	useEffect(() => {
		if (user && environment && environment.content.length) {
			const spaceEnvironmentId = environment.content[0].spaceEnvironmentId
			const spaceId = environment.content[0].spaceId
			router.push(
				replaceUrlParams(APP_URLS.CONTENT_MODELS.LIST, {
					spaceId: spaceId,
					spaceEnvironmentId: spaceEnvironmentId,
				})
			)
		}
	}, [environment])

	const validatePassword = (password) => {
		const uppercaseRegex = /[A-Z]/
		const lowercaseRegex = /[a-z]/
		const numberRegex = /[0-9]/
		const lengthRegex = /^.{8,128}$/
		const secureRegex = /^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9]).{8,128}$/

		setPasswordValidation({
			uppercase: uppercaseRegex.test(password),
			lowercase: lowercaseRegex.test(password),
			number: numberRegex.test(password),
			length: lengthRegex.test(password),
			secure: secureRegex.test(password),
		})
	}

	useEffect(() => {
		validatePassword(methods.watch("password"))
	}, [methods.watch("password")])

	return (
		<div className={styles.container}>
			<h1 className={cn(styles["welcome-text"], "font-weight-medium")}>
				Start building for free
			</h1>
			<FormProvider {...methods}>
				<form
					onSubmit={handleSubmit(onSubmit)}
					className={styles["signup-form"]}
				>
					<Controller
						control={control}
						name="fullname"
						render={({field}) => (
							<TextField
								{...field}
								label="Full Name"
								placeholder="Full Name"
								error={errors?.fullname?.message}
							/>
						)}
					/>
					<Controller
						control={control}
						name="company"
						render={({field}) => (
							<TextField
								{...field}
								placeholder="Company"
								label="Company"
								error={errors?.company?.message}
							/>
						)}
					/>
					<Controller
						control={control}
						name="email"
						render={({field}) => (
							<TextField
								{...field}
								placeholder="Email"
								label="Email"
								error={errors?.email?.message}
							/>
						)}
					/>
					<div className={styles.jobDropdown}>
						<div className={styles.job_title}>
							<DropdownField
								data={JOB_TITLE}
								selectedvalue={selectedJobTitle}
								setSelectedValue={setSelectedJobTitle}
								title={"Job Title"}
							/>
						</div>
						<div className={styles.job_function}>
							<DropdownField
								data={JOB_FUNCTION}
								selectedvalue={selectedJobFunction}
								setSelectedValue={setSelectedJobFunction}
								title={"Job Function"}
							/>
						</div>
					</div>

					<Controller
						control={control}
						name="password"
						render={({field}) => (
							<>
								<div className={styles.passwordMain}>
									<label className={styles.label_pass}>Password</label>
									<button
										type="button"
										onClick={() => setShowPassword((prev) => !prev)}
										className={styles.showPasswordButton}
									>
										{showPassword ? (
											<AiOutlineEyeInvisible />
										) : (
											<AiOutlineEye />
										)}
										<p>Show</p>
									</button>
								</div>
								<TextField
									{...field}
									placeholder="Password"
									type={showPassword ? "text" : "password"}
									error={errors?.password?.message}
								/>
								<div className={styles.passwordValidation}>
									<div className={styles.validationItem}>
										{passwordValidation.uppercase ? (
											<AiOutlineCheck style={{color: "rgb(11, 124, 86)"}} />
										) : (
											<AiOutlineClose style={{color: "rgb(151, 151, 151)"}} />
										)}
										<p
											className={
												passwordValidation.uppercase
													? styles.correct
													: styles.incorrect
											}
										>
											At least one uppercase letter
										</p>
									</div>
									<div className={styles.validationItem}>
										{passwordValidation.lowercase ? (
											<AiOutlineCheck style={{color: "rgb(11, 124, 86)"}} />
										) : (
											<AiOutlineClose style={{color: "rgb(151, 151, 151)"}} />
										)}
										<p
											className={
												passwordValidation.lowercase
													? styles.correct
													: styles.incorrect
											}
										>
											At least one lowercase letter
										</p>
									</div>
									<div className={styles.validationItem}>
										{passwordValidation.number ? (
											<AiOutlineCheck style={{color: "rgb(11, 124, 86)"}} />
										) : (
											<AiOutlineClose style={{color: "rgb(151, 151, 151)"}} />
										)}
										<p
											className={
												passwordValidation.number
													? styles.correct
													: styles.incorrect
											}
										>
											At least one number
										</p>
									</div>
									<div className={styles.validationItem}>
										{passwordValidation.length ? (
											<AiOutlineCheck style={{color: "rgb(11, 124, 86)"}} />
										) : (
											<AiOutlineClose style={{color: "rgb(151, 151, 151)"}} />
										)}
										<p
											className={
												passwordValidation.length
													? styles.correct
													: styles.incorrect
											}
										>
											Between 8 and 128 characters
										</p>
									</div>
									<div className={styles.validationItem}>
										{passwordValidation.secure ? (
											<AiOutlineCheck style={{color: "rgb(11, 124, 86)"}} />
										) : (
											<AiOutlineClose style={{color: "rgb(151, 151, 151)"}} />
										)}
										<p
											className={
												passwordValidation.secure
													? styles.correct
													: styles.incorrect
											}
										>
											Use a secure password
										</p>
									</div>
								</div>
							</>
						)}
					/>

					<div className={styles.submitButtonWrapper}>
						<Button
							size="md"
							className={`
								${styles["submit-button"]} 
								${
									((Boolean(errors.email) ||
										Boolean(errors.password) ||
										!passwordValidation.uppercase ||
										!passwordValidation.lowercase ||
										!passwordValidation.number ||
										!passwordValidation.length ||
										!passwordValidation.secure) &&
										styles.disabled) ||
									""
								}
							`}
							text="Sign Up"
							textAlign="center"
							type="submit"
							disabled={
								Boolean(errors.email) ||
								Boolean(errors.password) ||
								!passwordValidation.uppercase ||
								!passwordValidation.lowercase ||
								!passwordValidation.number ||
								!passwordValidation.length ||
								!passwordValidation.secure
							}
						/>
					</div>
					<div className={styles.alreadyLogin}>
						<p>
							Already have an account?{" "}
							<Link href={replaceUrlParams(APP_URLS.LOGIN)}>Login</Link>
						</p>
					</div>
				</form>
			</FormProvider>
		</div>
	)
}
