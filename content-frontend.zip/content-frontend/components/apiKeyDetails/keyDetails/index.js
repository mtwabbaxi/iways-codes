"use client";

import React, { useEffect, useMemo, useState } from "react";
import styles from "./keyDetails.module.scss";
import cn from "classnames";
import { Checkbox, TextField } from "@/components/theme/form-inputs";
import { AiOutlineShareAlt } from "react-icons/ai";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "next/navigation";
import {
  getAllAPIKeys,
  setAPIKeyLoadingTrue,
  updateAPIKeyById,
} from "@/store/actions/apiKeys";
import { Controller, FormProvider, useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { MdContentCopy } from "react-icons/md";
import { useToast } from "@/context/toastContext";
import { fetchEnvironmentBySpaceId } from "@/store/actions/spaces";
import Header from "@/components/apiKeys/Header";

const schema = yup.object().shape({
  name: yup
    .string()
    .required("Name is required")
    .max(65, "Name must be at most 65 characters"),
  description: yup
    .string()
    .max(255, "Description must be at most 255 characters"),
});

export default function KeyDetails() {
  const params = useParams();
  const { spaceId = "", apiKeyId = "" } = params || {};
  const [details, setDetails] = useState({});
  const dispatch = useDispatch();
  const { addToast } = useToast();
  const [selectedEnvironments, setSelectedEnvironments] = useState([]);

  const { allApiKeys } = useSelector((state) => state.apiKeys);
  const { content: environments = [] } =
    useSelector((state) => state.spaces?.environment) || {};

  const defaultValues = useMemo(() => {
    if (Object.keys(details).length) {
      return {
        name: details?.name || "",
        description: details?.description || "",
        spaceEnvironmentIds: details?.spaceEnvironmentIds || [],
      };
    }
    return {};
  }, [details]);

  const methods = useForm({
    defaultValues,
    mode: "onChange",
    resolver: yupResolver(schema),
  });

  const {
    setValue,
    reset,
    handleSubmit,
    control,
    formState: { errors, touchedFields },
  } = methods;

  const { contentPreviewAPIAccessKey = "", contentDeliveryAPIAccessKey = "" } =
    details || {};

  useEffect(() => {
    reset(defaultValues);
  }, [reset, defaultValues]);

  const handleAddRemoveSelectedEnv = (envId) => {
    if (selectedEnvironments.includes(envId)) {
      const filterEnvs = selectedEnvironments.filter((env) => env !== envId);
      setSelectedEnvironments(filterEnvs);
      setValue("spaceEnvironmentIds", filterEnvs);
    } else {
      const newEnvironments = [...selectedEnvironments];
      newEnvironments.push(envId);
      setSelectedEnvironments(newEnvironments);
      setValue("spaceEnvironmentIds", newEnvironments);
    }
  };

  const onSubmit = async (values) => {
    try {
      dispatch(setAPIKeyLoadingTrue());
      const data = { ...values, spaceId };
      const res = await dispatch(updateAPIKeyById({ data, apiKeyId }));

      const {
        result: { body = {}, error },
      } = res || {};
      if (body.responseCode === 200) {
        addToast(body.responseMessage);
        dispatch(getAllAPIKeys({ spaceId }));
      } else {
        addToast(body?.responseMessage || "An unknown error occured!", {
          type: "error",
        });
      }
    } catch (error) {}
  };

  const handleCopyText = (valueToBeCopied) => {
    var tempTextarea = document.createElement("textarea");
    tempTextarea.value = valueToBeCopied;
    document.body.appendChild(tempTextarea);
    tempTextarea.select();
    tempTextarea.setSelectionRange(0, 99999); /* For mobile devices */
    document.execCommand("copy");
    document.body.removeChild(tempTextarea);
    addToast("Value Copied");
  };

  useEffect(() => {
    if (apiKeyId && allApiKeys?.length) {
      const findDetails =
        allApiKeys.find((apiKey) => apiKey?.apiKeyId === apiKeyId) || {};
      setDetails(findDetails);
    }
  }, [allApiKeys, params?.apiKeyId]);

  useEffect(() => {
    if (details?.spaceEnvironmentIds?.length) {
      setSelectedEnvironments(details?.spaceEnvironmentIds);
    }
  }, [details]);

  useEffect(() => {
    if (dispatch && spaceId) {
      dispatch(getAllAPIKeys({ spaceId }));
      dispatch(fetchEnvironmentBySpaceId(spaceId));
    }
  }, [dispatch, spaceId]);

  const fieldErrors = useMemo(() => {
    if (selectedEnvironments.length <= 0) {
      return {
        ...errors,
        spaceEnvironmentIds: {
          message: "At least one environment has to be selected.",
        },
      };
    } else {
      return errors;
    }
  }, [selectedEnvironments]);

  return (
    <>
      <FormProvider {...methods}>
        <form onSubmit={handleSubmit(onSubmit)}>
          <Header errors={fieldErrors} name={details?.name} goBack />
          <div className={cn(styles.container)}>
            <h1 className="font-weight-bold text-body1">Access token</h1>
            <p className="mt-3 text-body2">
              To query and get content using the APIs, client applications need
              to authenticate with both the Space ID and an access token.
            </p>
            <Controller
              name="name"
              control={control}
              render={({ field }) => (
                <TextField
                  {...field}
                  label="Name"
                  required
                  hint="Can be platform or device specific names (i.e. marketing website, tablet, VR app)"
                  error={errors?.name?.message}
                  maxLength={65}
                />
              )}
            />
            <Controller
              name="description"
              control={control}
              render={({ field }) => (
                <TextField
                  {...field}
                  label="Description"
                  error={errors?.description?.message}
                  hint="You can provide an optional description for reference in the future"
                  maxLength={255}
                />
              )}
            />
            <TextField
              label="Space ID"
              value={details?.spaceId || spaceId || ""}
              icon={MdContentCopy}
              iconRight
              onIconClick={() => handleCopyText(details?.spaceId)}
              readOnly
            />

            <TextField
              type="password"
              label="Content Delivery API - access token"
              required
              hint='Use this access token to consume published content (i.e. content in "Published" status).'
              icon={MdContentCopy}
              iconRight
              onIconClick={() => handleCopyText(contentDeliveryAPIAccessKey)}
              value={contentDeliveryAPIAccessKey}
              readOnly
            />

            <hr />

            <TextField
              type="password"
              label="Content Preview API - access token"
              required
              hint='Use this access token to consume unpublished content (i.e. content in "Draft" status).'
              iconRight
              icon={MdContentCopy}
              onIconClick={() => handleCopyText(contentPreviewAPIAccessKey)}
              value={contentPreviewAPIAccessKey}
              readOnly
            />

            <hr />
            <h1 className="font-weight-bold text-body1 mt-3">Environments</h1>
            <p className="mt-1 text-body2">
              Select the environments this API key should have access to. At
              least one environment has to be selected.
            </p>
            <div className="mt-3">
              {environments?.length > 0 &&
                environments.map((env, index) => (
                  <Controller
                    name="spaceEnvironmentIds"
                    control={control}
                    render={({ field }) => (
                      <Checkbox
                        {...field}
                        key={env?.spaceEnvironmentId || index}
                        iconBeforeLabel={AiOutlineShareAlt}
                        label={env?.name || ""}
                        id={env?.spaceEnvironmentId}
                        onChange={() =>
                          handleAddRemoveSelectedEnv(env?.spaceEnvironmentId)
                        }
                        checked={selectedEnvironments.includes(
                          env?.spaceEnvironmentId
                        )}
                        error={fieldErrors?.spaceEnvironmentIds?.message}
                      />
                    )}
                  />
                ))}
            </div>
          </div>
        </form>
      </FormProvider>
    </>
  );
}
