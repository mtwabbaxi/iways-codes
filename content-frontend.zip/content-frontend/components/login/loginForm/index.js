"use client"

import React, {useEffect} from "react"
import styles from "./loginForm.module.scss"
import cn from "classnames"
import {TextField} from "@/components/theme/form-inputs"
import {Button} from "@/components/theme/buttons"
import * as yup from "yup"
import {yupResolver} from "@hookform/resolvers/yup"
import {Controller, FormProvider, useForm} from "react-hook-form"
import {useDispatch, useSelector} from "react-redux"
import {login} from "@/store/actions/user"
import {useToast} from "@/context/toastContext"
import {useRouter} from "next/navigation"
import {fetchAllSpaces, fetchEnvironmentBySpaceId} from "@/store/actions/spaces"
import {APP_URLS, replaceUrlParams} from "@/utils/constants"

const schema = yup.object({
	email: yup
		.string()
		.required("Email is required")
		.matches(
			/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$/,
			"Invalid email address"
		),
	password: yup.string().required("Password is required"),
	remember: yup.boolean(),
})

export default function LoginForm() {
	const methods = useForm({
		defaultValues: {
			email: "admin@pwr.team",
			password: "Test@123",
			remember: false,
		},
		mode: "onChange",
		resolver: yupResolver(schema),
	})

	const {
		handleSubmit,
		control,
		formState: {errors},
	} = methods

	const dispatch = useDispatch()
	const {addToast} = useToast()
	const {allSpaces, environment} = useSelector((state) => state.spaces)
	const {user} = useSelector((state) => state.user)
	const router = useRouter()

	const onSubmit = async (values) => {
		try {
			const res = await dispatch(login(values))
			const {data = null, description = ""} = res?.result?.body || {}
			const {status = 0} = res?.error?.response || {}
			if (!data && status !== 403) {
				addToast(description, {type: "error"})
			} else if (status === 403) {
				addToast("Email or Password incorrect", {type: "error"})
			} else {
				addToast(description)
				await dispatch(fetchAllSpaces())
			}
		} catch (err) {
			console.log("error:", err)
		} finally {
		}
	}

	useEffect(() => {
		if (user && allSpaces && allSpaces.content.length) {
			const spaceId = allSpaces.content[0].spaceId
			dispatch(fetchEnvironmentBySpaceId(spaceId))
		}
	}, [allSpaces])

	useEffect(() => {
		if (user && environment && environment.content.length) {
			const spaceEnvironmentId = environment.content[0].spaceEnvironmentId
			const spaceId = environment.content[0].spaceId
			router.push(
				replaceUrlParams(APP_URLS.CONTENT_MODELS.LIST, {
					spaceId: spaceId,
					spaceEnvironmentId: spaceEnvironmentId,
				})
			)
		}
	}, [environment])
	return (
		<div className={styles.container}>
			<h1 className={cn(styles["welcome-text"], "font-weight-medium")}>
				Welcome back
			</h1>
			<h2
				className={cn(
					styles["login-text"],
					"font-weight-medium",
					"text-body1",
					"mt-3"
				)}
			>
				Login to your account.
			</h2>
			<FormProvider {...methods}>
				<form
					onSubmit={handleSubmit(onSubmit)}
					className={styles["login-form"]}
				>
					<Controller
						control={control}
						name="email"
						render={({field}) => (
							<TextField
								{...field}
								placeholder="Enter email"
								label="Email"
								error={errors?.email?.message}
							/>
						)}
					/>
					<Controller
						control={control}
						name="password"
						render={({field}) => (
							<TextField
								{...field}
								type="password"
								placeholder="Enter password"
								label="Password"
								error={errors?.password?.message}
							/>
						)}
					/>

					<Controller
						control={control}
						name="remember"
						render={({field}) => (
							<div className={styles["remember-checkbox"]}>
								<input id="remember-checkbox" type="checkbox" {...field} />
								<label htmlFor="remember-checkbox">Remember me</label>
							</div>
						)}
					/>

					<div>
						<Button
							size="md"
							className={styles["submit-button"]}
							text="Login"
							textAlign="center"
							type="submit"
							disabled={Boolean(errors.email) || Boolean(errors.password)}
						/>
					</div>
				</form>
			</FormProvider>
		</div>
	)
}
