import styles from "./emptyField.module.scss";
import { VscEmptyWindow } from "react-icons/vsc";
import { BsBoxArrowUpRight } from "react-icons/bs";
import { Button } from "@/components/theme/buttons";
import cn from "classnames";
import { AiOutlinePlus } from "react-icons/ai";

export default function EmptyField({ onAddField = () => {} }) {
  return (
    <div className={styles["add-field-container"]}>
      <VscEmptyWindow size="20em" className={styles.image} />
      <div className={styles["button-container"]}>
        <Button
          onClick={onAddField}
          size="md"
          variant="secondary"
          className={cn(styles.button, "font-weight-semi-bold", "text-body1")}
          text={
            <>
              <AiOutlinePlus />
              Add field
            </>
          }
        />
      </div>
      <p
        className={cn(styles.message, "text-body2", "mt-3", "color-gray-1800")}
      >
        The field type defines what content can be stored. For instance, a text{" "}
        <br /> field accepts titles and descriptions, and a media field is used
        for- <br /> images and videos.{" "}
        <span
          className={cn(
            styles["learn-more"],
            "color-blue-400",
            "font-weight-medium"
          )}
        >
          Learn more <BsBoxArrowUpRight />
        </span>
      </p>
    </div>
  );
}
