import { useDispatch, useSelector } from "react-redux";
import "./index.modules.scss";
export default function JSONPreview() {
  const { selectedContentModel } = useSelector((state) => state.contentModel);

  return (
    <div className="container">
      <div className="title">JSON Preview</div>
      <pre>{JSON.stringify(selectedContentModel, null, 2)}</pre>
    </div>
  );
}
