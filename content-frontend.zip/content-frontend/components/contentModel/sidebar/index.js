import React, { useState } from "react";
import styles from "./sidebar.module.scss";
import { Tabs } from "@/components/theme/tabs";
import { APP_URLS, replaceUrlParams } from "@/utils/constants";
import MyViews from "@/components/content/myViews/myViews";
import SharedViews from "@/components/content/sharedViews/sharedViews";
import { useParams } from "next/navigation";

export default function Sidebar({
  fieldCount = 0,
  contentModelId,
  activeTabIndex,
  isSideBar,
  pageType,
}) {
  const [activeContentTab, setActiveContentTab] = useState(0);
  const { spaceId, spaceEnvironmentId } = useParams();

  const sidebarOptions = [
    {
      title: `Fields (${fieldCount})`,
      url: `${replaceUrlParams(APP_URLS.CONTENT_MODELS.CONTENT_FIELDS.LIST, {
        spaceId: spaceId,
        spaceEnvironmentId: spaceEnvironmentId,
        contentModelId: contentModelId,
      })}`,
    },
    {
      title: "Name and description",
      url: `${replaceUrlParams(APP_URLS.CONTENT_MODELS.UPDATE_MODEL, {
        spaceId: spaceId,
        spaceEnvironmentId: spaceEnvironmentId,
        contentModelId: contentModelId,
      })}`,
    },
    {
      title: "JSON preview",
      url: `${replaceUrlParams(APP_URLS.CONTENT_MODELS.JSON_PREVIEW, {
        spaceId: spaceId,
        spaceEnvironmentId: spaceEnvironmentId,
        contentModelId: contentModelId,
      })}`,
    },
  ];

  const sidebarOptions_Content = [
    { title: "Shared views" },
    { title: "My views" },
  ];

  const handleTabClick = (index) => {
    setActiveContentTab(index);
  };

  return (
    <>
      <div className={styles.sidebar}>
        {pageType === "content" || pageType === "media" ? (
          <>
            <Tabs
              variant="default"
              size="md"
              direction="horizontal"
              tabs={sidebarOptions_Content}
              onTabClick={handleTabClick}
            />
            {/* Render content based on the active tab index */}
            {activeContentTab === 0 && (
              <SharedViews pageType={pageType} isSideBar />
            )}
            {activeContentTab === 1 && <MyViews />}
          </>
        ) : (
          <Tabs
            variant="default"
            size="md"
            activeIndex={activeTabIndex}
            direction="vertical"
            tabs={sidebarOptions}
          />
        )}
      </div>
    </>
  );
}
