"use client";

import { Button } from "@/components/theme/buttons";
import styles from "./header.module.scss";
import { AiFillQuestionCircle, AiOutlinePlus } from "react-icons/ai";
import { BsFilter } from "react-icons/bs";
import { useState, useCallback, useEffect } from "react";
import { TextField } from "@/components/theme/form-inputs";
import CreateUpdateContentTypeForm from "../createUpdateContentTypeForm";
import Modal from "@/components/shared/modal";
import { useDispatch, useSelector } from "react-redux";
import {
  resetSelectedContentModel,
  searchByNameOnContent,
  searchByNameOnMedia,
} from "@/store/actions/contentModel";
import {
  filterContentStatus,
  removeContentEntryFilter,
} from "@/store/actions/contentEntry";

import MenuDropdown from "@/components/layout/secondaryNav/menuDropdown";
import { OPTION_TYPES } from "@/components/layout/secondaryNav/menuDropdown/menuOption";
import MenuItem from "@/components/layout/secondaryNav/menuItem";
import { APP_URLS, replaceUrlParams } from "@/utils/constants";
import { useParams, useRouter } from "next/navigation";
import { IoIosArrowDown } from "react-icons/io";
import cn from "classnames";
import { filter } from "lodash";
export default function Header({
  searchText,
  onSearchChange = () => {},
  pageType,
}) {
  const [open, setOpen] = useState(false);
  const dispatch = useDispatch();
  const [searchValue, setSearchValue] = useState("");
  const { searchNameContent, searchNameMedia } = useSelector(
    (state) => state.contentModel
  );
  const { data } = useSelector((state) => state.contentModel);
  const { selectedModel, selectedStatus, filters } = useSelector(
    (state) => state.contentEntries
  );
  const { user } = useSelector((state) => state.user);
  const { assetValues } = useSelector((state) => state.media);
  const { spaceId, spaceEnvironmentId } = useParams();

  const router = useRouter();
  useEffect(() => {
    dispatch(searchByNameOnContent([]));
    dispatch(searchByNameOnMedia([]));
  }, [router]);

  const handleOpenForm = () => {
    dispatch(resetSelectedContentModel());
    setOpen(true);
  };
  const onSearchContent = (e) => {
    setSearchValue(e.target.value);
    dispatch(searchByNameOnContent(e.target.value));
  };

  const onSearchMedia = (e) => {
    setSearchValue(e.target.value);
    dispatch(searchByNameOnMedia(e.target.value));
  };

  const VIEW_DROPDOWN = [
    {
      id: 1,
      title: "View",
      children: [
        { id: 1, title: "Update view" },
        { id: 2, title: "Save as new view" },
      ],
    },
  ];

  const SELECT_MODULES = [
    {
      id: 1,
      title: selectedModel,
      children: [
        {
          id: "Any",
          title: "Any",
          data: { contentModelId: "Any" },
        },
        ...(data
          ? data.content.map((item, index) => ({
              id: index + 1,
              title: item.name,
              data: item,
            }))
          : []),
      ],
    },
  ];
  const STATUS = [
    {
      id: 1,
      title: selectedStatus,
      // icon: <IoIosArrowDown />,
      children: [
        { id: 1, title: "Published" },
        { id: 2, title: "Changed" },
        { id: 2, title: "Draft" },
      ],
    },
  ];
  const lastUpdatedBy = [
    {
      id: 1,
      title: filters?.lastUpdatedBy,
      // icon: <IoIosArrowDown />,
      children: [
        {
          id: "Any",
          title: "Any",
          lastUpdatedBy: true,
        },
        {
          id: 2,
          title: user?.firstName + " " + user?.lastName,
          lastUpdatedBy: true,
        },
      ],
    },
  ];
  const createdBy = [
    {
      id: 1,
      title: filters?.createdBy,
      // icon: <IoIosArrowDown />,
      children: [
        {
          id: "Any",
          title: "Any",
          createdBy: true,
        },
        {
          id: 2,
          title: user?.firstName + " " + user?.lastName,
          createdBy: true,
        },
      ],
    },
  ];
  const FILTER_VALUES = [
    {
      id: 1,
      title: "Filter",
      icon: <BsFilter />,
    },
  ];

  const ADD_ENTRY = [
    {
      id: 1,
      title: "Add entry",
      align: "left",
      children: [
        // {
        //   id: 1,
        //   type: OPTION_TYPES.SECTION_TITLE,
        //   title: "Suggested Content Type",
        // },
        // {
        //   id: 2,
        //   title: "Product",
        // },
        {
          id: 3,
          type: OPTION_TYPES.SECTION_TITLE,
          title: "All Content Types",
        },
        ...(data
          ? data.content.map((item, index) => ({
              id: index + 4,
              title: item.name,
              data: item,
              addEntry: true,
            }))
          : []),
      ],
    },
  ];

  const ADD_ASSET = [
    {
      id: 1,
      title: "Add asset",
      align: "left",
      children: [
        {
          id: 1,
          title: "Single asset",
          url: replaceUrlParams(APP_URLS.MEDIA.CREATE, {
            spaceId: spaceId,
            spaceEnvironmentId: spaceEnvironmentId,
          }),
        },
        { id: 2, title: "Multiple assets" },
      ],
    },
  ];

  const getMenus = useCallback((items, topBar = false) => {
    return items.map((item) => {
      if (item.children?.length) {
        return (
          <MenuDropdown
            key={item.id}
            title={item.title}
            icon={item.icon}
            children={item.children}
            align={item.align}
            pageType={pageType}
            className={styles.dropdown_container}
            topBar={topBar}
            dontAddInFilter
          />
        );
      } else {
        return (
          <MenuItem
            key={item.id}
            text={item.title}
            icon={item.icon}
            url={item.url}
            children={item.children}
            pageType={pageType}
          />
        );
      }
    });
  }, []);

  return (
    <>
      <div className={styles.container}>
        <div className={styles.heading}>
          <h3 className="text-body1 font-weight-semi-bold">
            {pageType === "content"
              ? "Content"
              : pageType === "media"
                ? "Media"
                : "Content model"}
          </h3>
          <AiFillQuestionCircle />
        </div>
        {pageType === "content" || pageType === "media" ? (
          <div className={styles.search_menu}>
            <div
              className={cn(styles.search_filters, {
                [styles.search_filter_main]: pageType === "content",
              })}
            >
              {pageType === "content" && (
                <div
                  className={cn(styles.filters_button, {
                    [styles.filters_button_width]:
                      pageType === "content" ||
                      filters.status ||
                      filters?.lastUpdatedBy ||
                      filters?.createdBy,
                  })}
                >
                  <button className={styles.content_type}>Content type</button>
                  <div className={styles.modules}>
                    {SELECT_MODULES[0] && getMenus(SELECT_MODULES, true)}
                  </div>
                  {selectedStatus?.length ? (
                    <>
                      <button
                        className={`${styles.content_type} ${styles.status_type}`}
                      >
                        status
                      </button>
                      {/* <div className={styles.status_type}>is</div> */}
                      <div
                        className={`${styles.modules} ${styles.status_text}`}
                      >
                        {getMenus(STATUS, true)}
                      </div>
                    </>
                  ) : (
                    <>
                      {filters?.lastUpdatedBy && (
                        <>
                          <button
                            className={`${styles.content_type} ${styles.status_type}`}
                          >
                            Updatedby
                          </button>
                          {/* <div className={styles.status_type}>is</div> */}
                          <div
                            className={`${styles.modules} ${styles.status_text}`}
                          >
                            {getMenus(lastUpdatedBy, true)}
                          </div>
                        </>
                      )}
                      {filters?.createdBy && (
                        <>
                          <button
                            className={`${styles.content_type} ${styles.status_type}`}
                          >
                            Createdby
                          </button>
                          {/* <div className={styles.status_type}>is</div> */}
                          <div
                            className={`${styles.modules} ${styles.status_text}`}
                          >
                            {getMenus(createdBy, true)}
                          </div>
                        </>
                      )}
                    </>
                  )}
                </div>
              )}
              <div
                className={cn(
                  pageType === "content"
                    ? styles.content_Search
                    : styles.search,
                  {
                    [styles.searchBar]:
                      pageType === "content" ||
                      filters.status ||
                      filters?.lastUpdatedBy ||
                      filters?.createdBy,
                  }
                )}
              >
                <TextField
                  value={
                    searchValue
                      ? searchValue
                      : searchNameContent?.data
                        ? searchNameContent?.data
                        : searchNameMedia?.data
                          ? searchNameMedia?.data
                          : ""
                  }
                  onChange={
                    pageType === "content" ? onSearchContent : onSearchMedia
                  }
                  type="text"
                  placeholder={
                    pageType === "media"
                      ? "Type to search for assets"
                      : pageType === "content"
                        ? "Type to search for entries"
                        : "Search for content type by Name"
                  }
                />
              </div>
              {pageType === "media" && (
                <>
                  <div className={styles.filter}>
                    {FILTER_VALUES[0] && getMenus(FILTER_VALUES)}
                  </div>
                </>
              )}
            </div>
            <div className={styles.dropdown}>
              {VIEW_DROPDOWN && getMenus(VIEW_DROPDOWN)}
            </div>
          </div>
        ) : (
          <div className={styles.search}>
            <TextField
              value={searchText}
              onChange={onSearchChange}
              type="text"
              placeholder="Search for content type by Name"
            />
          </div>
        )}

        <div className={styles.buttons}>
          {pageType === "content" ? (
            <div className={styles.add_entry_wrapper}>
              <Button
                size="md"
                text={
                  <>
                    <div className={styles.add_entry}>
                      {ADD_ENTRY[0] && getMenus(ADD_ENTRY)}
                    </div>
                  </>
                }
              />
            </div>
          ) : pageType === "media" ? (
            <div className={styles.add_asset_wrapper}>
              <Button
                size="md"
                text={
                  <>
                    <div className={styles.add_asset}>
                      {ADD_ASSET && getMenus(ADD_ASSET)}
                    </div>
                  </>
                }
              />
            </div>
          ) : (
            <Button
              onClick={handleOpenForm}
              size="md"
              text={
                <>
                  <AiOutlinePlus />
                  Add content type
                </>
              }
            />
          )}
        </div>
      </div>

      {open && (
        <Modal heading="Create new content type" onClose={() => setOpen(false)}>
          <CreateUpdateContentTypeForm onClose={() => setOpen(false)} />
        </Modal>
      )}
    </>
  );
}
