"use client";

import React, { useState } from "react";
import styles from "./header.module.scss";
import Link from "next/link";
import { BsArrowLeft } from "react-icons/bs";
import ToolTip from "@/components/theme/toolTip";
import { Button } from "@/components/theme/buttons";
import { useParams } from "next/navigation";
import { APP_URLS, replaceUrlParams } from "@/utils/constants";
import cn from "classnames";
import { MdOutlineContentCopy } from "react-icons/md";
import { useSelector } from "react-redux";

export default function Header() {
  const [tooltipText, setTooltipText] = useState("Copy to clipboard");

  const params = useParams();
  const { savedModelData = {} } =
    useSelector((state) => state.contentModel) || {};
  const { apiIdentifier = "", spaceId, spaceEnvironmentId } = params || {};

  const copyToClipboard = (textToCopy) => {
    const el = document.createElement("textarea");
    el.value = textToCopy;
    el.setAttribute("readonly", "");
    el.style.position = "absolute";
    el.style.left = "-9999px";
    document.body.appendChild(el);
    const selected =
      document.getSelection().rangeCount > 0
        ? document.getSelection().getRangeAt(0)
        : false;
    el.select();
    document.execCommand("copy");
    document.body.removeChild(el);
    if (selected) {
      document.getSelection().removeAllRanges();
      document.getSelection().addRange(selected);
    }

    setTooltipText("Copied");
    setTimeout(() => {
      setTooltipText("Copy to clipboard");
    }, 1300);
  };

  return (
    <div className={styles["header-container"]}>
      <header className={styles.header}>
        <Link
          href={replaceUrlParams(APP_URLS.CONTENT_MODELS.LIST, {
            spaceId,
            spaceEnvironmentId,
          })}
        >
          <div className={styles.back}>
            <BsArrowLeft />
          </div>
        </Link>
        <p className="m-0 color-gray-500 text-body1">/</p>
        <p className="m-0 font-weight-semi-bold text-body1">
          {savedModelData?.name}
        </p>
        <ToolTip direction="right" text={tooltipText}>
          <Button
            className={cn(styles["copy-button"], "text-body1")}
            startIcon={MdOutlineContentCopy}
            variant="default"
            text="Copy ID"
            onClick={() => copyToClipboard(apiIdentifier)}
          />
        </ToolTip>
      </header>
    </div>
  );
}
