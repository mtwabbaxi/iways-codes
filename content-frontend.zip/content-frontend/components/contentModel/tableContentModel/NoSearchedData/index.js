import { TbListSearch } from "react-icons/tb";
import styles from "./noSearchedData.module.scss";
import cn from "classnames";

const NoSearchedData = () => {
  return (
    <div className={cn(styles.container, "color-gray-1500")}>
      <TbListSearch size="10em" />
      <p className="mt-5 text-body1 font-weight-medium">No search results.</p>
      <p className="text-body2">Try a different search term.</p>
    </div>
  );
};

export default NoSearchedData;
