"use client";

import { useState, useEffect, useRef } from "react";
import Header from "../header";
import { DataTable } from "@/components/theme/datatable";
import { useParams, useRouter } from "next/navigation";
import { APP_URLS, replaceUrlParams } from "@/utils/constants";
import NoSearchedData from "./NoSearchedData";
import {
  addSortingContentModel,
  fetchAllContentModels,
  updateSortingContentModel,
} from "@/store/actions/contentModel";
import { useDispatch, useSelector } from "react-redux";
import styles from "./tableContentModal.module.scss";
import { format, formatDistance, formatRelative, subDays } from "date-fns";
import { fetchAllSpaces } from "@/store/actions/spaces";
import { FaChevronUp, FaChevronDown } from "react-icons/fa";
import Loader from "@/components/shared/skeletonLoading";
import { debounce } from "lodash";
import cn from "classnames";

const columns = [
  {
    title: "Name",
    key: "name",
    styles: {
      paddingLeft: "1.5rem",
      width: "50%",
    },
    render: (data) => {
      return (
        <div className={styles.name}>
          <div className="font-weight-medium">{data.name}</div>
          <div className="mt-1 color-gray-1500">{data.description}</div>
        </div>
      );
    },
  },
  {
    title: "Fields",
    key: "fieldCount",
    dataIndex: "fieldCount",
  },
  {
    title: "Last Updated By",
    key: "lastUpdatedBy",
    render: (data) => {
      return <div>{data.lastUpdatedBy || "-"}</div>;
    },
  },
  {
    title: "Updated",
    key: "lastModifiedDate",
    render: (data) => {
      return (
        <div>
          {formatDistance(
            subDays(new Date(data.lastModifiedDate), 0),
            new Date(),
            { addSuffix: true }
          )}
        </div>
      );
    },
  },
];

export default function TableContentModel() {
  const dispatch = useDispatch();
  const router = useRouter();
  const [searchKeyword, setSearchKeyword] = useState();
  const {
    data,
    loading,
    sortBy = {},
  } = useSelector((state) => state.contentModel);

  const { spaceId, spaceEnvironmentId } = useParams();
  const debouncedFetchAllContentModels = useRef(
    debounce((keyword, sortBy) => {
      dispatch(
        fetchAllContentModels(spaceId, spaceEnvironmentId, {
          searchKeyword: keyword,
          sortBy,
        })
      );
    }, 1000) // Adjust the delay as needed
  ).current;

  const handleSort = (key) => {
    const newOrder = sortBy[key] === "ASC" ? "DESC" : "ASC";
    if (key in sortBy) {
      dispatch(updateSortingContentModel(key, newOrder));
    } else {
      dispatch(addSortingContentModel(key, newOrder));
    }
  };

  const columns = [
    {
      title: (
        <div
          className={cn(styles.sortableColumn)}
          onClick={() => handleSort("name")}
        >
          Name
          {sortBy?.name === "ASC" || !sortBy?.name ? (
            <FaChevronUp
              className={cn(styles["arrow-up"], styles.arrow, {
                [styles.hovered]: !sortBy?.name,
              })}
            />
          ) : sortBy?.name === "DESC" ? (
            <FaChevronDown className={cn(styles["arrow-down"], styles.arrow)} />
          ) : null}
        </div>
      ),
      key: "name",
      styles: {
        paddingLeft: "1.5rem",
        width: "50%",
      },
      render: (data) => {
        return (
          <div className={styles.name}>
            <div className="font-weight-medium">{data.name}</div>
            <div className="mt-1 color-gray-1500">{data.description}</div>
          </div>
        );
      },
    },
    {
      title: "Fields",
      key: "fieldCount",
      dataIndex: "fieldCount",
    },
    {
      title: (
        <div
          className={`${styles["update-column-container"]}

          `}
          onClick={() => handleSort("lastUpdatedBy")}
        >
          Last Updated By
          {sortBy?.lastUpdatedBy === "ASC" || !sortBy?.lastUpdatedBy ? (
            <FaChevronUp
              className={cn(styles["arrow-up"], styles.arrow, {
                [styles.hovered]: !sortBy?.lastUpdatedBy,
              })}
            />
          ) : sortBy?.lastUpdatedBy === "DESC" ? (
            <FaChevronDown className={cn(styles["arrow-down"], styles.arrow)} />
          ) : null}
        </div>
      ),
      key: "lastUpdatedBy",
      render: (data) => {
        return <div>{data.lastUpdatedBy || "-"}</div>;
      },
    },
    {
      title: (
        <div
          className={`${styles["update-column-container"]}

          `}
          onClick={() => handleSort("lastModifiedDate")}
        >
          Updated
          {sortBy?.lastModifiedDate === "ASC" || !sortBy?.lastModifiedDate ? (
            <FaChevronUp
              className={cn(styles["arrow-up"], styles.arrow, {
                [styles.hovered]: !sortBy?.lastModifiedDate,
              })}
            />
          ) : sortBy?.lastModifiedDate === "DESC" ? (
            <FaChevronDown className={cn(styles["arrow-down"], styles.arrow)} />
          ) : null}
        </div>
      ),
      key: "lastModifiedDate",
      render: (data) => {
        return (
          <div>
            {formatDistance(
              subDays(new Date(data.lastModifiedDate), 0),
              new Date(),
              { addSuffix: true }
            )}
          </div>
        );
      },
    },
  ];

  const handleSearchChange = (e) => {
    const { value } = e.target;
    setSearchKeyword(value);
    debouncedFetchAllContentModels(value, sortBy);
  };

  const rowClickHandler = (row) => {
    if (row.contentModelId) {
      router.push(
        replaceUrlParams(APP_URLS.CONTENT_MODELS.CONTENT_FIELDS.LIST, {
          spaceId: spaceId,
          spaceEnvironmentId: spaceEnvironmentId,
          contentModelId: row.contentModelId,
        })
      );
    }
  };

  useEffect(() => {
    dispatch(
      fetchAllContentModels(spaceId, spaceEnvironmentId, {
        searchKeyword,
        sortBy,
      })
    );
  }, [sortBy]); // searchKeyword is not in dependencies because we are dealing that it in handleSearchChange

  useEffect(() => {
    return () => {
      // Cleanup on component unmount
      debouncedFetchAllContentModels.cancel();
    };
  }, [debouncedFetchAllContentModels]);

  if (loading) return <Loader />;
  return (
    <>
      <Header searchText={searchKeyword} onSearchChange={handleSearchChange} />

      {Boolean(!data?.content?.length) && <NoSearchedData />}

      {Boolean(data?.content?.length) && (
        <DataTable
          rowClickHandler={rowClickHandler}
          columns={columns}
          dataSource={data?.content}
        />
      )}
    </>
  );
}
