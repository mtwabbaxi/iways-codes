"use client";

import React, { useEffect, useMemo } from "react";
import { FormProvider, useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { TextArea, TextField } from "@/components/theme/form-inputs";
import { Button } from "@/components/theme/buttons";
import styles from "./createUpdateContentTypeForm.module.scss";
import cn from "classnames";
import { camelCase } from "lodash";
import { useToast } from "@/context/toastContext";
import { useRouter } from "next/navigation";
import {
  createContentModel,
  fetchAllContentModels,
  modifySelectedContentModel,
  resetSelectedContentModel,
  saveCreatingModelData,
  updateContentModel,
} from "@/store/actions/contentModel";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "next/navigation";
import { APP_URLS, replaceUrlParams } from "@/utils/constants";

export default function CreateUpdateContentTypeForm({
  onClose = () => {},
  isEditMode,
}) {
  const { loading, selectedContentModel, data } = useSelector(
    (state) => state.contentModel
  );

  const contentModelIdSchema = useMemo(() => {
    if (!isEditMode) {
      return yup
        .string()
        .test({
          name: "unique-contentModelId",
          exclusive: true,
          message: "API Identifier already exists",
          test: async function (value) {
            if (
              value &&
              data?.content?.some((c) => c?.contentModelId === value)
            ) {
              return false;
            }
            return true;
          },
        })
        .required("API identifier is required")
        .max(64, "API Identifier must be at most 64 characters");
    } else {
      return yup
        .string()
        .required("API identifier is required")
        .max(64, "API Identifier must be at most 64 characters");
    }
  }, [isEditMode]);

  const schema = yup.object().shape({
    name: yup
      .string()
      .required("Name is required")
      .max(50, "Name must be at most 50 characters"),
    contentModelId: contentModelIdSchema,
    description: yup
      .string()
      .max(500, "Description must be at most 500 characters"),
  });

  const router = useRouter();

  const dispatch = useDispatch();
  const { spaceId, spaceEnvironmentId } = useParams();
  const { addToast } = useToast();
  const defaultValues = useMemo(() => {
    return {
      name: selectedContentModel?.name ?? "",
      contentModelId: selectedContentModel?.contentModelId ?? "",
      description: selectedContentModel?.description ?? "",
    };
  }, [selectedContentModel]);

  const methods = useForm({
    defaultValues,
    mode: "onChange",
    resolver: yupResolver(schema),
  });

  const {
    reset,
    setValue,
    watch,
    handleSubmit,
    control,
    formState: { errors, touchedFields },
  } = methods;

  watch((data, { type }) => {
    if (isEditMode && type === "change") {
      dispatch(modifySelectedContentModel(data));
    }
  });

  useEffect(() => {
    reset(defaultValues);
  }, [reset, defaultValues]);

  const onSubmit = async (values) => {
    try {
      if (isEditMode) {
        let res = null;
        res = await dispatch(
          updateContentModel(values, spaceId, spaceEnvironmentId)
        );
        const {
          result: { body },
        } = res;
        if (body.responseCode === 200) {
          addToast(body.responseMessage);
          if (!isEditMode) {
            dispatch(fetchAllContentModels(spaceId, spaceEnvironmentId));
            dispatch(resetSelectedContentModel());
            onClose();
          }
        } else if (body.responseCode === 400) {
          addToast(body.responseMessage, { type: "error" });
        } else {
          addToast("An unknow error occurred!", { type: "error" });
        }
      } else {
        dispatch(saveCreatingModelData({ ...values }));

        router.push(
          `${replaceUrlParams(APP_URLS.CONTENT_MODELS.CREATE, {
            spaceId,
            spaceEnvironmentId,
            apiIdentifier: values.contentModelId,
          })}`
        );
      }
    } catch (err) {
      console.log("error: ", err);
    }
  };

  return (
    <FormProvider {...methods}>
      <form className={styles.form} onSubmit={handleSubmit(onSubmit)}>
        <Controller
          name="name"
          control={control}
          render={({ field }) => (
            <TextField
              {...field}
              label="Name"
              required
              placeholder="For example Product, Blog Post, Author"
              maxLength="50"
              error={errors?.name?.message}
              onChange={(e) => {
                if (!touchedFields.contentModelId && !isEditMode) {
                  setValue("contentModelId", camelCase(e.target.value), {
                    shouldValidate: true,
                  });
                }
                setValue("name", e.target.value, {
                  shouldDirty: true,
                  shouldValidate: true,
                  shouldTouch: true,
                });
                if (isEditMode) {
                  dispatch(
                    modifySelectedContentModel({
                      name: e.target.value,
                    })
                  );
                }
              }}
            />
          )}
        />
        {!isEditMode && (
          <Controller
            name="contentModelId"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                label="API Identifier"
                required
                placeholder="For example Product, Blog Post, Author"
                hint="Generated from name"
                maxLength="64"
                error={errors?.contentModelId?.message}
              />
            )}
          />
        )}
        <Controller
          name="description"
          control={control}
          render={({ field }) => (
            <TextArea
              {...field}
              label="Description"
              placeholder="For example Product, Blog Post, Author"
              maxLength="500"
              error={errors?.description?.message}
            />
          )}
        />
        <Button
          className={cn(styles["submit-button"], "mt-5")}
          type="submit"
          size="md"
          variant="secondary"
          text={isEditMode ? "Save" : "Create"}
          loading={loading}
          disabled={
            errors?.name?.message ||
            errors?.description?.message ||
            errors?.contentModelId?.message
          }
        />
      </form>
    </FormProvider>
  );
}
