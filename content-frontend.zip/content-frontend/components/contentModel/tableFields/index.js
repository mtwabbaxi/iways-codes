"use client";
import { useState, useMemo, useCallback, useEffect } from "react";
import Modal from "@/components/shared/modal";
import AllFieldsCell from "@/components/allFieldsCell";
import Content from "../content";
import EmptyField from "../emptyField";
import FieldNameForm from "@/components/contentFields/fieldNameForm/fieldNameForm";
import FieldSettingsForm from "@/components/contentFields/fieldSettingsForm/fieldSettingsForm";
import fieldsData from "@/data/fields";
import { useSelector, useDispatch } from "react-redux";
import { getContentModelById } from "@/store/actions/contentModel";
import { useParams } from "next/navigation";

export default function TableFields({ data = [] }) {
  const { selectedContentModel } = useSelector((state) => state.contentModel);
  const [step, setStep] = useState(-1);
  const [formData, setFormData] = useState({});
  const [editMode, setEditMode] = useState(false);
  const [addEditUpdateOrDeleteCount, setAddEditUpdateOrDeleteCount] =
    useState(0);
  const dispatch = useDispatch();

  const params = useParams();

  let { contentModelId, spaceId, spaceEnvironmentId } = params;

  contentModelId = decodeURIComponent(contentModelId); // Cupiditate%20nisi%20dolo -> Cupiditate nisi dolo
  const handleNext = useCallback((payload) => {
    if (payload) {
      setFormData((d) => ({ ...d, ...payload }));
    }
    setStep((s) => s + 1);
  }, []);

  const field = useMemo(
    () => fieldsData.find((f) => f.fieldType === formData.fieldType),
    [formData.fieldType]
  );

  const enableEditMode = (row) => {
    const formData = {
      contentModelId: row.contentModelId,
      fieldId: row.id,
      name: row.name,
      api_identifier: row.id,
      field: { ...row },
    };
    setFormData(formData);
    setStep(3);
    setEditMode(true);
  };

  const handlePrevious = useCallback(() => {
    setStep((s) => s - 1);
  }, []);
  const handleOpen = useCallback(() => {
    setFormData({});
    setEditMode(false);
    setStep(1);
  }, []);
  const handleClose = useCallback(() => {
    setFormData({});
    setEditMode(false);
    setStep(-1);
  }, []);

  const headingText = useMemo(() => {
    switch (step) {
      case 1:
        return "Add Field";
      case 2:
        return (
          <div className="text-body1">
            Add Field{" "}
            <span className="text-caption font-weight-regular">
              {field?.contentTypeDetail?.title}
            </span>
          </div>
        );
      case 3:
        return formData?.name;
      default:
        return "";
    }
  }, [step, field, formData?.name]);

  useEffect(() => {
    dispatch(getContentModelById(contentModelId, spaceId, spaceEnvironmentId));
  }, [contentModelId, spaceId]);

  return (
    <>
      {selectedContentModel?.fields.length ? (
        <Content
          onDelete={() => setAddEditUpdateOrDeleteCount((prev) => prev + 1)}
          setOpen={handleOpen}
          data={data}
          enableEditMode={enableEditMode}
        />
      ) : (
        <EmptyField onAddField={handleOpen} />
      )}
      {step > -1 && (
        <Modal
          heading={headingText}
          contentClassName={step === 3 ? "pb-0" : ""}
          onClose={handleClose}
          size={step < 3 ? "md" : "lg"}
        >
          {step === 1 && <AllFieldsCell onCellClick={handleNext} />}
          {step === 2 && (
            <FieldNameForm
              field={field}
              onNext={handleNext}
              onPrevious={handlePrevious}
            />
          )}
          {step === 3 && (
            <FieldSettingsForm
              onAddEditOrUpdate={() =>
                setAddEditUpdateOrDeleteCount((prev) => prev + 1)
              }
              onClose={handleClose}
              formData={formData}
              editMode={editMode}
            />
          )}
        </Modal>
      )}
    </>
  );
}
