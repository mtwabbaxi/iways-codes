import { useCallback, useState } from "react";
import { RxText } from "react-icons/rx";
import { AiOutlineNumber } from "react-icons/ai";
import { SlLocationPin } from "react-icons/sl";
import { GoFileMedia } from "react-icons/go";
import { RxReader } from "react-icons/rx";
import { AiOutlineCalendar, AiOutlinePlus } from "react-icons/ai";
import { PiCircleHalfTiltDuotone } from "react-icons/pi";
import { VscJson } from "react-icons/vsc";
import { VscReferences } from "react-icons/vsc";
import styles from "./content.module.scss";
import { DataTable } from "@/components/theme/datatable";
import { Button } from "@/components/theme/buttons";
import { ContextMenu } from "@/components/theme/menus";
import { useDispatch, useSelector } from "react-redux";
import { deleteField, getContentModelById } from "@/store/actions/contentModel";
import { useToast } from "@/context/toastContext";
import { BsCheckCircleFill } from "react-icons/bs";
import cn from "classnames";
import { useParams } from "next/navigation";
import Modal from "@/components/shared/modal";

export default function Content({
  setOpen = () => {},
  enableEditMode = () => {},
  onDelete = () => {},
}) {
  const { selectedContentModel } = useSelector((state) => state.contentModel);
  const dispatch = useDispatch();
  const { addToast } = useToast();
  const { spaceId, spaceEnvironmentId, contentModelId } = useParams();

  const [openDeleteMessageModal, setOpenDeleteMessageModal] = useState(false);

  const data = selectedContentModel?.fields.map((item) => {
    return {
      name: item.contentTypeDetail.title,
      fieldType: item.fieldType,
      data: item,
    };
  });

  const getTypeIcon = useCallback((type) => {
    switch (type) {
      case "RICH_TEXT":
        return RxReader;
      case "MEDIA":
        return GoFileMedia;
      case "NUMBER":
        return AiOutlineNumber;
      case "DATETIME":
        return AiOutlineCalendar;
      case "JSON":
        return VscJson;
      case "REFERENCE":
        return VscReferences;
      case "LOCATION":
        return SlLocationPin;
      case "BOOLEAN":
        return PiCircleHalfTiltDuotone;
      case "Short text":
      default:
        return RxText;
    }
  });

  const handleDelete = async (row) => {
    try {
      if (row?.data?.entryTitle) {
        setOpenDeleteMessageModal(true);
        return;
      }
      let res = null;
      const data = {
        fieldId: row.data.id,
        contentModelId: selectedContentModel.contentModelId,
      };
      res = await dispatch(deleteField(data, spaceId, spaceEnvironmentId));
      const {
        result: { body },
      } = res;
      if (body.responseCode === 200) {
        addToast(body.responseMessage);
        dispatch(
          getContentModelById(contentModelId, spaceId, spaceEnvironmentId)
        );
        onDelete();
      } else {
        addToast(body?.responseMessage || "An unknown error occured!", {
          type: "error",
        });
      }
    } catch (err) {
      console.log("error: ", err);
    } finally {
    }
  };

  const handleEdit = (row) => {
    enableEditMode(row.data);
  };

  const columns = [
    {
      title: "Name",
      key: "name",
      styles: {
        paddingLeft: "4rem",
      },
      render: ({ data }) => {
        return (
          <div className={styles["entry-title-container"]}>
            <p>{data?.name}</p>
            {data?.entryTitle && (
              <Button className={styles["entry-title"]} text="Entry Title" />
            )}
          </div>
        );
      },
    },
    {
      title: "Field Type",
      key: "fieldType",
      render: ({ fieldType }) => {
        const Icon = getTypeIcon(fieldType);
        return (
          <div className={styles["col-field-type"]}>
            <span>
              <Icon />
            </span>
            <span>{fieldType}</span>
          </div>
        );
      },
    },
    {
      title: "Localization",
      key: "localization",
      render: (row) => {
        const { data = [] } = row || {};
        return data?.localized ? (
          <BsCheckCircleFill className={cn(styles.localizationIcon, "mt-2")} />
        ) : (
          <span className="color-gray-500">—</span>
        );
      },
    },
    {
      title: "",
      key: "actions",
      render: (row) => {
        const menuOptions = [
          {
            id: 1,
            title: "Hide Field When Editing",
            // onClick: () => handleDelete(row),
          },
          {
            id: 1,
            title: "Disable in Response",
            // onClick: () => handleDelete(row),
          },
          { id: 1, title: "Delete", onClick: () => handleDelete(row) },
        ];
        return (
          <div className={styles["col-actions"]}>
            <span
              className="color-blue-600 font-weight-medium"
              onClick={() => handleEdit(row)}
            >
              Edit
            </span>
            <div className={styles?.MenuWrapper}>
              <ContextMenu options={menuOptions} />
            </div>
          </div>
        );
      },
    },
  ];

  const handleCloseModel = () => setOpenDeleteMessageModal(false);

  return (
    <div className={styles.content}>
      <div className={styles.container}>
        <h1 className="text-h5 mb-5">Fields</h1>

        <DataTable columns={columns} dataSource={data} />
        <div className={styles.actions}>
          <Button
            className={styles["btn-add-field"]}
            variant="default"
            text="Add Field"
            startIcon={AiOutlinePlus}
            size="md"
            fullWidth
            onClick={() => setOpen(true)}
          />
        </div>
        {openDeleteMessageModal && (
          <Modal
            heading="This field can’t be deleted right now"
            onClose={handleCloseModel}
          >
            <p className="text-body2 color-gray-1500">
              The field text acts as a title for this content type. Before
              deleting it you need to choose another field as title.
            </p>
            <Button
              onClick={handleCloseModel}
              className={styles["close-btn"]}
              variant="primary"
              text="Okay, got it"
            />
          </Modal>
        )}
      </div>
    </div>
  );
}
