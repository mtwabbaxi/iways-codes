import styles from "./mediaConfirmPopup.module.scss";
import { IoMdClose } from "react-icons/io";
import Link from "next/link";
import { APP_URLS, replaceUrlParams } from "@/utils/constants";
import { useParams } from "next/navigation";

const MediaConfirmPopup = ({
  setIsContentDeletePopupOpen,
  setisDeleteConfirmed,
  message,
  assetValues,
}) => {
  const params = useParams();
  const { spaceId = "", spaceEnvironmentId = "" } = params || {};

  const handleOverlayClick = (e) => {
    if (!e.target.closest(`.${styles.deleteConfirmPopup}`)) {
      setIsContentDeletePopupOpen(false);
    }
  };

  return (
    <div className={styles.container}>
      <div
        className={`${styles.overlay} ${styles.isContentDeletePopupOpen}`}
        onClick={handleOverlayClick}
      >
        <div className={styles.deleteConfirmPopup}>
          <div className={styles.header}>
            <h1>Are you sure you want to permanently delete this asset?</h1>
            <button
              className={styles.closeIcon}
              onClick={() => setIsContentDeletePopupOpen(false)}
            >
              <IoMdClose />
            </button>
          </div>
          <hr />
          <div className={styles.content}>
            <p className={styles?.no_entries}>
              {assetValues?.linkContentEntries?.length > 0 ? (
                <div className={styles?.exist_entries}>
                  <p>
                    There is {assetValues?.linkContentEntries?.length} entry
                    that links to this asset:
                  </p>
                  {assetValues?.linkContentEntries?.map((entry) => {
                    return (
                      <ul>
                        <li>
                          <Link
                            href={replaceUrlParams(APP_URLS.CONTENT.UPDATE, {
                              spaceId: spaceId,
                              spaceEnvironmentId: spaceEnvironmentId,
                              contentModelId: entry?.contentModelId,
                              contentEntryId: entry?.id,
                            })}
                          >
                            {entry?.name}
                          </Link>{" "}
                        </li>
                      </ul>
                    );
                  })}
                </div>
              ) : (
                <b>No entries link to this asset.</b>
              )}
            </p>
            <p className={styles.informDetail}>
              Once you delete this asset, it's gone for good and cannot be
              retrieved.
            </p>
            <div className={styles.buttonGroup}>
              <button
                className={styles.cancelButton}
                onClick={() => setIsContentDeletePopupOpen(false)}
              >
                Cancel
              </button>
              <button
                className={styles.confirmButton}
                onClick={() => setisDeleteConfirmed(true)}
              >
                Permanently delete
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MediaConfirmPopup;
