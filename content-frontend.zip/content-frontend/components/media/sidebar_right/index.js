import React, { useState } from "react";
import styles from "./sidebar.module.scss";
import { Tabs } from "@/components/theme/tabs";
import { APP_URLS } from "@/utils/constants";
import General from "../general/general";

export default function Sidebar_Right({
  page,
  media = false,
  referenceSidebar = false,
  referenceFieldForMedia = false,
  referenceImage = false,
  onSubmit = () => {},
}) {
  const [activeContentTab, setActiveContentTab] = useState(0);

  const sidebarOptions_Content = [{ title: "General" }, { title: "Info" }];

  const handleTabClick = (index) => {
    setActiveContentTab(index);
  };

  return (
    <>
      <div className={styles.sidebar}>
        <>
          <Tabs
            variant="default"
            size="md"
            direction="horizontal"
            tabs={sidebarOptions_Content}
            onTabClick={handleTabClick}
          />
          {/* Render content based on the active tab index */}
          {activeContentTab === 0 && (
            <General
              page={page}
              media={media}
              referenceSidebar={referenceSidebar}
              referenceFieldForMedia={referenceFieldForMedia}
              referenceImage={referenceImage}
              onSubmit={onSubmit}
            />
          )}
          {activeContentTab === 1 && ""}
        </>
      </div>
    </>
  );
}
