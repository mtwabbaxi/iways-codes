"use client";

import { useState, useEffect, useMemo } from "react";
import { DataTable } from "@/components/theme/datatable";
import { useParams, useRouter } from "next/navigation";
import { APP_URLS, replaceUrlParams } from "@/utils/constants";
import NoSearchedData from "@/components/contentModel/tableContentModel/NoSearchedData";
import { useDispatch, useSelector } from "react-redux";
import styles from "./tableContent.module.scss";
import { formatDistance, subDays } from "date-fns";
import cn from "classnames";
import {
  FaChevronLeft,
  FaChevronRight,
  FaChevronUp,
  FaChevronDown,
} from "react-icons/fa";
import {
  UpdateMultipleMediaAssetStatus,
  addMediaSorting,
  deleteAsset,
  deleteMultipleMediaAsset,
  revertMultipleMediaAsset,
  fetchAllMediaAsset,
  removeMediaSorting,
} from "@/store/actions/media";
import { ContextMenu } from "@/components/theme/menus";
import { useToast } from "@/context/toastContext";
import ConfirmPopup from "@/components/content/confirmPopup/confirmPopup";
import { Checkbox } from "@/components/theme/form-inputs";
import OptionRow from "@/components/sharedComponents/optionRow";

export default function TableContent() {
  const dispatch = useDispatch();
  const router = useRouter();
  const [currentPage, setCurrentPage] = useState(1);
  const [isMediaDeletePopupOpen, setIsMediaDeletePopupOpen] = useState(false);
  const [currRow, setCurrRow] = useState("");
  const [isDeleteConfirmed, setisDeleteConfirmed] = useState(false);
  const itemsPerPage = 50;
  const { content: allAssets = [] } = useSelector(
    (state) => state.media?.allAssets
  );
  const { searchNameMedia } = useSelector((state) => state.contentModel);
  const { spaceId, spaceEnvironmentId } = useParams();
  const startIdx = (currentPage - 1) * itemsPerPage;
  const endIdx = startIdx + itemsPerPage;
  const displayedData = useMemo(() => {
    if (allAssets.length) {
      return allAssets.length && allAssets?.slice(startIdx, endIdx);
    }
    return [];
  }, [allAssets]);
  const { addToast } = useToast();
  const totalPages =
    allAssets?.length && Math.ceil(allAssets.length / itemsPerPage);
  const [selectedEntries, setSelectedEntries] = useState([]);
  const [selectAll, setSelectAll] = useState(false);
  const { filters = {}, sortBy } = useSelector((state) => state.media);

  const handleSort = (key) => {
    const newSortOrder =
      sortBy[key] === "ASC" ? "DESC" : sortBy[key] === "DESC" ? "" : "ASC";
    if (newSortOrder) {
      dispatch(addMediaSorting(key, newSortOrder));
    } else {
      dispatch(removeMediaSorting(key));
    }
  };

  const handleDelete = async (row) => {
    try {
      let res = null;
      res = await dispatch(
        deleteAsset(row.assetId, spaceId, spaceEnvironmentId)
      );
      const {
        result: { body },
      } = res;
      console.log(body);
      if (body.responseCode === 200) {
        addToast(body.responseMessage);
        dispatch(fetchAllMediaAsset(spaceId, spaceEnvironmentId));
      } else {
        addToast(body?.responseMessage || "An unknown error occured!", {
          type: "error",
        });
      }
    } catch (err) {
      console.log("error: ", err);
    } finally {
      setIsMediaDeletePopupOpen(false);
      setisDeleteConfirmed(false);
    }
  };

  const handleDeleteConfirmPopup = async (row) => {
    setIsMediaDeletePopupOpen(true);
    setCurrRow(row);
  };

  useEffect(() => {
    if (isDeleteConfirmed) {
      handleDelete(currRow);
    } else {
      setIsMediaDeletePopupOpen(false);
      setCurrRow("row");
    }
  }, [isDeleteConfirmed]);

  useEffect(() => {
    setSelectedEntries([]);
  }, [displayedData.length]);

  const isChecked = (id) => {
    return Boolean(selectedEntries.filter((s) => s?.id === id).length);
  };

  const handleAllSelect = (e) => {
    const { value } = e.target;
    if (value === "false") {
      setSelectAll(true);
      const allIds = displayedData.map((d) => {
        return {
          id: d?.assetId,
          status: d?.status,
        };
      });
      setSelectedEntries(allIds);
    } else {
      setSelectAll(false);
      setSelectedEntries([]);
    }
  };

  const handleSelection = (entry) => {
    if (isChecked(entry?.assetId)) {
      const currentSelection = selectedEntries.filter(
        (s) => s?.id !== entry?.assetId
      );
      setSelectedEntries(currentSelection);
    } else {
      setSelectedEntries([
        ...selectedEntries,
        {
          id: entry?.assetId,
          status: entry?.status,
        },
      ]);
    }
  };

  const columns = [
    {
      title: (
        <Checkbox
          id="all"
          value={selectAll}
          onChange={(e) => handleAllSelect(e)}
        />
      ),
      key: "select",
      styles: {
        paddingLeft: "0.5rem",
        width: "1%",
      },
      render: (allAssets) => {
        return (
          <div className={styles.name}>
            <div className="font-weight-medium">
              <div onClick={(e) => e.stopPropagation()}>
                <Checkbox
                  id={allAssets.assetId}
                  checked={isChecked(allAssets.assetId)}
                  onChange={() => handleSelection(allAssets)}
                />
              </div>
            </div>
          </div>
        );
      },
    },
    {
      title: "Name",
      key: "name",
      styles: {
        paddingLeft: "1.5rem",
        // width: "50%",
      },
      render: (allAssets) => {
        return (
          <div
            className={styles.title}
            // onClick={() => rowClickHandler(allAssets)}
          >
            <div className="font-weight-medium">
              {allAssets?.title || "Untitled"}
            </div>
          </div>
        );
      },
    },
    {
      title: "Image",
      key: "image",
      styles: {
        paddingLeft: "1.5rem",
        // width: "50%",
      },
      render: (allAssets) => {
        return (
          <div className={styles.tableImage}>
            <img src={allAssets.url} />
          </div>
        );
      },
    },
    {
      title: "Dimensions",
      key: "dimensions",
      render: (allAssets) => {
        const dimensions = allAssets.dimensions;
        if (dimensions) {
          const [width, height] = dimensions.split(":");
          return (
            <div
              style={{
                width: "max-content",
              }}
            >{`${width}px x ${height}px`}</div>
          );
        }
      },
    },
    {
      title: "Type",
      key: "type",
      dataIndex: "mediaType",
    },
    {
      title: (
        <div
          className={`${styles["update-column-container"]}
          ${
            sortBy?.lastModifiedDate === "ASC"
              ? styles["arrow-up-active"]
              : sortBy?.lastModifiedDate === "DESC"
                ? styles["arrow-down-active"]
                : ""
          }
          `}
          onClick={() => handleSort("lastModifiedDate")}
        >
          Updated
          <FaChevronUp className={cn(styles["arrow-up"], styles.arrow)} />
          <FaChevronDown className={cn(styles["arrow-down"], styles.arrow)} />
        </div>
      ),
      key: "lastModifiedDate",
      render: (allAssets) => {
        return (
          <div>
            {formatDistance(
              subDays(new Date(allAssets.lastModifiedDate), 0),
              new Date(),
              { addSuffix: true }
            )}
          </div>
        );
      },
    },
    {
      title: "By",
      key: "lastUpdatedBy",
      render: (allAssets) => {
        return <div>{allAssets.lastUpdatedBy || "-"}</div>;
      },
    },
    {
      title: "Status",
      key: "status",
      render: (allAssets) => {
        const currStatus = allAssets?.status.toLowerCase();
        return (
          <div className={`${styles[currStatus]}`}>{allAssets.status}</div>
        );
      },
    },
    {
      title: "",
      key: "actions",
      render: (row) => {
        const menuOptions = [
          {
            id: 1,
            title: "Delete",
            onClick: () => handleDeleteConfirmPopup(row),
          },
        ];
        return (
          <div className={styles["col-actions"]}>
            <ContextMenu options={menuOptions} />
          </div>
        );
      },
    },
  ];

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handlePageChange = (page) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  const rowClickHandler = (row) => {
    if (row.assetId) {
      router.push(
        replaceUrlParams(APP_URLS.MEDIA.UPDATE, {
          spaceId: spaceId,
          spaceEnvironmentId: spaceEnvironmentId,
          assetId: row.assetId,
        })
      );
    }
  };

  useEffect(() => {
    dispatch(
      fetchAllMediaAsset(spaceId, spaceEnvironmentId, { filters, sortBy })
    );
  }, [filters, sortBy]);

  const handleSelectionDelete = async () => {
    const data = {
      assetIds: selectedEntries.map((e) => e?.id),
      spaceId,
      spaceEnvironmentId,
    };
    try {
      const res = await dispatch(deleteMultipleMediaAsset(data));
      console.log(res);
      if (res?.result?.body?.responseCode === 200) {
        addToast(res?.result?.body?.responseMessage);
        await dispatch(fetchAllMediaAsset(spaceId, spaceEnvironmentId));
      }
    } catch (error) {
      console.log({ error });
    } finally {
      setSelectedEntries([]);
    }
  };

  const handleSelectionRevert = async () => {
    const data = {
      assetIds: selectedEntries.map((e) => e?.id),
      spaceId,
      spaceEnvironmentId,
    };
    try {
      const res = await dispatch(revertMultipleMediaAsset(data));
      console.log(res);
      if (res?.result?.body?.responseCode === 200) {
        addToast(res?.result?.body?.responseMessage);
        await dispatch(fetchAllMediaAsset(spaceId, spaceEnvironmentId));
      } else {
        addToast(res?.result?.body?.responseMessage);
      }
    } catch (error) {
      console.log({ error });
    } finally {
      setSelectedEntries([]);
    }
  };

  const handleSelectionPublishOrUnpublish = async (status) => {
    const data = {
      assetIds: selectedEntries.map((e) => e?.id),
      spaceId,
      spaceEnvironmentId,
      status,
    };
    try {
      const res = await dispatch(UpdateMultipleMediaAssetStatus(data));
      console.log(res);
      if (res?.result?.body?.responseCode === 200) {
        addToast(res?.result?.body?.responseMessage);
        await dispatch(fetchAllMediaAsset(spaceId, spaceEnvironmentId));
      }
    } catch (error) {
      console.log({ error });
    } finally {
      setSelectedEntries([]);
    }
  };

  return (
    <div className={styles.TableContent}>
      {displayedData.length <= 0 && <NoSearchedData />}
      {selectedEntries.length > 0 && (
        <OptionRow
          handleDelete={handleSelectionDelete}
          handleUnPublish={handleSelectionPublishOrUnpublish}
          handlePublish={handleSelectionPublishOrUnpublish}
          handleRevert={handleSelectionRevert}
          selectedEntries={selectedEntries}
        />
      )}
      {displayedData?.length > 0 && (
        <>
          <DataTable
            rowClickHandler={rowClickHandler}
            columns={columns}
            dataSource={displayedData}
          />
          <div className={styles.pagination}>
            <span>{`${startIdx + 1} - ${startIdx + displayedData.length} of ${
              allAssets?.length
            } items`}</span>
            {allAssets?.length > itemsPerPage && (
              <>
                <button onClick={handlePrevPage} disabled={currentPage === 1}>
                  <FaChevronLeft />
                </button>
                <button
                  onClick={handleNextPage}
                  disabled={currentPage === totalPages}
                >
                  <FaChevronRight />
                </button>
              </>
            )}
          </div>
        </>
      )}
      {isMediaDeletePopupOpen && (
        <ConfirmPopup
          setIsContentDeletePopupOpen={setIsMediaDeletePopupOpen}
          setisDeleteConfirmed={setisDeleteConfirmed}
          message="Are you sure you want to delete this media?"
        />
      )}
    </div>
  );
}
