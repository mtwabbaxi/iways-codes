import styles from "./createPage_top_Tabs.module.scss";
import { Tabs } from "@/components/theme/tabs";

const CreatePage_top_Tabs = ({ options }) => {
  const handleTabClick = (index) => {
    setActiveContentTab(index);
  };
  return (
    <div>
      <div className={styles.tabs_container}>
        <Tabs
          variant="default"
          size="md"
          direction="horizontal"
          tabs={options}
          onTabClick={handleTabClick}
        />
      </div>
    </div>
  );
};

export default CreatePage_top_Tabs;
