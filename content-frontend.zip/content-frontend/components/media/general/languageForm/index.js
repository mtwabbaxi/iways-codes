"use client";

import React, { useEffect, useMemo, useState } from "react";
import styles from "./languageForm.module.scss";
import cn from "classnames";
import { useDispatch, useSelector } from "react-redux";
import {
  addRemoveSelectedLanguage,
  fetchAllEnableLanguages,
  fetchAllLocales,
} from "@/store/actions/locales";
import { useParams } from "next/navigation";
import { SELETE_LOCALE } from "@/utils/constants";
import { Checkbox } from "@/components/theme/form-inputs";
import { Button } from "@/components/theme/buttons";
import { useToast } from "@/context/toastContext";

export default function LanguageForm({ onClose = () => {} }) {
  const dispatch = useDispatch();
  const { addToast } = useToast();

  const [selectedLanguages, setSelectedLanguages] = useState(["en-US"]);

  const { content = {} } =
    (useSelector((state) => state?.locales) || {})?.allLocales || {};

  const { contentEntrySelectedLanguages = [], loading = false } =
    useSelector((state) => state?.locales) || {};

  const params = useParams();

  const localesWithTitle = useMemo(() => {
    if (content?.length) {
      return content.map((item) => {
        const matchedLocale = SELETE_LOCALE[0].children.find(
          (locale) => locale.value === item.languageCode
        );
        return { ...item, title: matchedLocale?.title || null };
      });
    } else {
      return [];
    }
  }, [content]);

  const handleAddOrRemoveLanguage = (value) => {
    if (value === "en-US") return;
    if (selectedLanguages.includes(value)) {
      setSelectedLanguages(selectedLanguages.filter((l) => l !== value));
    } else {
      const newLanguages = [...selectedLanguages];
      newLanguages.push(value);
      setSelectedLanguages(newLanguages);
    }
  };

  const SingleLanguage = ({ title = "", onChange = () => {}, value = "" }) => {
    return (
      <Checkbox
        onChange={value !== "en-US" ? onChange : () => {}}
        label={title}
        checked={value === "en-US" ? true : selectedLanguages.includes(value)}
        id={value}
        disabled={value === "en-US"}
      />
    );
  };

  const handleSelectAll = () => {
    if (localesWithTitle?.length) {
      setSelectedLanguages(localesWithTitle?.map((item) => item?.languageCode));
    } else {
      setSelectedLanguages(["en-US"]);
    }
  };

  const handleSave = async () => {
    const res = await dispatch(addRemoveSelectedLanguage(selectedLanguages));
    const {
      result: { body = {} },
    } = res || {};
    if (body.responseCode === 200) {
      dispatch(fetchAllEnableLanguages());
      addToast(body.responseMessage);
      onClose();
    } else {
      addToast(body?.responseMessage || "An unknown error occured!", {
        type: "error",
      });
    }
  };

  useEffect(() => {
    if (contentEntrySelectedLanguages.length > 1) {
      setSelectedLanguages(contentEntrySelectedLanguages);
    }
  }, [contentEntrySelectedLanguages]);

  const isAllSelected = useMemo(() => {
    if (selectedLanguages.length === 1 && localesWithTitle.length === 1) {
      return null;
    } else if (selectedLanguages.length === localesWithTitle.length) {
      return true;
    } else {
      return false;
    }
  }, [selectedLanguages, localesWithTitle]);

  const handleDeselectAll = () => {
    setSelectedLanguages(["en-US"]);
  };

  return (
    <div className={styles.container}>
      <div className={styles["label-and-action"]}>
        <p className="font-weight-medium text-body2 color-gray-900">
          Select locale(s)
        </p>
        {isAllSelected !== null && (
          <p
            className={cn(
              "font-weight-medium",
              "text-body2",
              "color-blueViolet-100",
              styles.action
            )}
            onClick={
              isAllSelected
                ? handleDeselectAll
                : isAllSelected === false
                  ? handleSelectAll
                  : () => {}
            }
          >
            {isAllSelected === false && "Select all"}
            {isAllSelected && "Deselect all"}
          </p>
        )}
      </div>

      <div className="mt-3">
        {localesWithTitle?.length > 0 &&
          localesWithTitle.map((item, index) => (
            <SingleLanguage
              key={item?.title || index}
              title={item?.title || ""}
              onChange={() => handleAddOrRemoveLanguage(item?.languageCode)}
              value={item?.languageCode}
            />
          ))}
      </div>

      <div className={cn("mt-5", styles["buttons-actions"])}>
        <Button
          onClick={handleSave}
          text="Save"
          variant="primary"
          disabled={loading}
        />
        <Button
          onClick={onClose}
          text="Cancel"
          variant="default"
          disabled={loading}
        />
      </div>
    </div>
  );
}
