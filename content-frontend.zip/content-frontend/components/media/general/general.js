import { useState, useCallback, useMemo, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { triggerFormSubmission } from "@/store/actions/form";
import styles from "./general.module.scss";
import MenuDropdown from "@/components/layout/secondaryNav/menuDropdown";
import MenuItem from "@/components/layout/secondaryNav/menuItem";
import ButtonDropdown from "@/components/sharedComponents/buttonDropdown";
import {
  setMediaEntryStatus,
  setMediaSubmitButton,
} from "@/store/actions/media";
import {
  setContentEntryStatus,
  setContentSubmitButton,
  setReferenceContentSubmitButton,
} from "@/store/actions/contentEntry";
import Modal from "@/components/shared/modal";
import LanguageForm from "./languageForm";
import Chips from "@/components/theme/chips";
import {
  addRemoveSelectedLanguage,
  fetchAllEnableLanguages,
  fetchAllLocales,
  isSubmitButton,
} from "@/store/actions/locales";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useToast } from "@/context/toastContext";
import { APP_URLS, replaceUrlParams } from "@/utils/constants";
import { useFormContext } from "react-hook-form";

const General = ({
  page,
  media = false,
  referenceSidebar = false,
  referenceFieldForMedia = false,
  referenceImage = false,
  onSubmit = () => {},
}) => {
  const { handleSubmit } = useFormContext() || {};
  const params = useParams();
  const { addToast } = useToast();
  const { spaceId = "", spaceEnvironmentId = "" } = params || {};
  const [lastSavedTime, setLastSavedTime] = useState(new Date());
  const [status, setStatus] = useState("");
  const [openModal, setOpenModal] = useState(false);
  const dispatch = useDispatch();

  const handlePublishClick = () => {
    if (!referenceFieldForMedia) {
      dispatch(triggerFormSubmission());
    }
  };
  const VIEW_DROPDOWN = [
    {
      id: 1,
      title: "Multiple locales",
      children: [
        { id: 1, title: "Multiple locales" },
        { id: 2, title: "Single locale" },
      ],
    },
  ];

  const getMenus = useCallback((items) => {
    return items.map((item) => {
      if (item.children?.length) {
        return (
          <MenuDropdown
            key={item.id}
            title={item.title}
            icon={item.icon}
            children={item.children}
            align={item.align}
            className={styles.dropdown_container}
          />
        );
      } else {
        return (
          <MenuItem
            key={item.id}
            text={item.title}
            icon={item.icon}
            url={item.url}
            children={item.children}
            pageType={pageType}
          />
        );
      }
    });
  }, []);

  function formatLastSavedTime(time) {
    const now = new Date();
    const diffInMinutes = Math.floor((now - time) / 60000); // Calculate the difference in minutes

    if (diffInMinutes < 1) {
      return "a few seconds ago";
    } else if (diffInMinutes === 1) {
      return "a minute ago";
    } else {
      return `about ${diffInMinutes} minutes ago`;
    }
  }

  const { contentEntryValues, contentEntries } = useSelector(
    (state) => state.contentEntries
  );
  const {
    assetValues,
    createMediaCurrUploadFile,
    createMediaCurrTitle,
    mediaEntryStatus,
    createMediaCurrDescription,
  } = useSelector((state) => state.media);
  const { status: fetchedMediaStatus = "" } = assetValues || {};

  const { status: fetchedStatus = "" } = contentEntryValues || {};

  useEffect(() => {
    if (!media && fetchedStatus) {
      setStatus(fetchedStatus);
    } else if (media && mediaEntryStatus === "CHANGED") {
      setStatus(mediaEntryStatus);
    } else if (media && fetchedMediaStatus) {
      setStatus(fetchedMediaStatus);
    }
  }, [
    media,
    fetchedStatus,
    fetchedMediaStatus,
    mediaEntryStatus,
    contentEntryValues,
    assetValues,
  ]);

  const buttonText = useMemo(() => {
    if (status === "DRAFT") return "Draft";
    if (status === "PUBLISHED") return "Published";
    if (status === "CHANGED") return "Changed";
    // if (status === "UNPUBLISHED") return "Unpublished";
    return ""; // its mean we're not in edit mode
  }, [status]);

  useEffect(() => {
    if (!buttonText) {
      setStatus("DRAFT");
    }
    if (media) {
      if (mediaEntryStatus === "CHANGED") {
        dispatch(setMediaEntryStatus("CHANGED"));
      } else {
        dispatch(setMediaEntryStatus("DRAFT"));
      }
    } else {
      if (fetchedStatus === "CHANGED") {
        dispatch(setContentEntryStatus("CHANGED"));
      } else {
        dispatch(setContentEntryStatus("DRAFT"));
      }
    }
  }, [buttonText, status]);
  useEffect(() => {
    if (!referenceSidebar) {
      dispatch(setMediaSubmitButton(isSubmitButton));
    }
  }, [isSubmitButton, referenceSidebar]);
  const changeStatusHandler = () => {
    if (media) {
      dispatch(setMediaSubmitButton(true));
    } else if (referenceSidebar) {
      if (onSubmit && handleSubmit) {
        console.log("innner");
        handleSubmit(onSubmit());
      } else {
        dispatch(setReferenceContentSubmitButton(true));
      }
    } else {
      dispatch(setContentSubmitButton(true));
    }
  };

  const handleOpen = () => setOpenModal(true);
  const handleClose = () => setOpenModal(false);

  const { contentEntrySelectedLanguages } = useSelector(
    (state) => state?.locales
  );

  const handleDelete = async (lang) => {
    if (contentEntrySelectedLanguages?.length) {
      const res = await dispatch(
        addRemoveSelectedLanguage(
          contentEntrySelectedLanguages.filter((l) => l !== lang)
        )
      );

      const {
        result: { body = {} },
      } = res || {};
      if (body.responseCode === 200) {
        addToast(body.responseMessage);
        dispatch(fetchAllEnableLanguages());
      } else {
        addToast(body.responseMessage || "An unknown error occured!", {
          type: "error",
        });
      }
    }
  };

  useEffect(() => {
    if (dispatch) {
      dispatch(fetchAllLocales(spaceId, spaceEnvironmentId));
      dispatch(fetchAllEnableLanguages());
    }
  }, [dispatch]);
  return (
    <>
      <div className={styles.container}>
        <div className={styles.status}>
          <h2>Status</h2>
        </div>
        <div className={styles.current}>
          <p>Current</p>
          <button>{buttonText || "Draft"}</button>
        </div>
        <div className={styles.publish}>
          {!buttonText ||
          createMediaCurrTitle.length > 50 ||
          createMediaCurrDescription > 500 ? (
            <button
              onClick={handlePublishClick}
              disabled
              className={styles.disabledButton}
              type="submit"
            >
              Draft
            </button>
          ) : (
            <ButtonDropdown
              text={buttonText}
              optionsLabel="Change status to"
              onChange={() => changeStatusHandler()}
              media={media}
              disabled={Boolean(createMediaCurrUploadFile)}
              referenceSidebar={referenceSidebar}
              referenceFieldForMedia={referenceFieldForMedia}
              referenceImage={referenceImage}
              onSubmit={onSubmit}
              fetchedMediaStatus={fetchedMediaStatus}
              status={status}
            />
          )}
        </div>
        <p className={styles.currTime}>
          Last saved {formatLastSavedTime(lastSavedTime)}
        </p>
        <div className={styles.links}>
          <div className={styles.status}>
            <h2>Links</h2>
          </div>
          {assetValues?.linkContentEntries?.length > 0 && media ? (
            <div className={styles?.exist_entries}>
              <p>
                There is {assetValues?.linkContentEntries?.length} entry that
                links to this asset:
              </p>
              {assetValues?.linkContentEntries?.map((entry) => {
                return (
                  <ul>
                    <li>
                      <Link
                        href={replaceUrlParams(APP_URLS.CONTENT.UPDATE, {
                          spaceId: spaceId,
                          spaceEnvironmentId: spaceEnvironmentId,
                          contentModelId: entry?.contentModelId,
                          contentEntryId: entry?.id,
                        })}
                      >
                        {entry?.name}
                      </Link>{" "}
                    </li>
                  </ul>
                );
              })}
            </div>
          ) : (
            <p>No entries link to this asset.</p>
          )}
        </div>
        <div className={styles.translation}>
          <div className={styles.translation_wrapper}>
            <h2>translation</h2>
            <div className={styles.dropdown}>
              {VIEW_DROPDOWN && getMenus(VIEW_DROPDOWN)}
            </div>
          </div>
          <div className={styles["selected-languages"]}>
            {contentEntrySelectedLanguages?.length > 0 &&
              contentEntrySelectedLanguages.map((lang, index) => (
                <Chips
                  key={index}
                  value={lang}
                  noIcon={lang === "en-US"}
                  handleDelete={() => handleDelete(lang)}
                />
              ))}
            <button onClick={handleOpen} className={styles.change}>
              Change
            </button>
          </div>
        </div>
      </div>
      {openModal && (
        <Modal heading="Translation" onClose={handleClose}>
          <LanguageForm onClose={handleClose} />
        </Modal>
      )}
    </>
  );
};

export default General;
