"use client";

import React, { useEffect, useState } from "react";
import styles from "./createForm.module.scss";
import { TextField, TextArea } from "@/components/theme/form-inputs";
import { Button } from "@/components/theme/buttons";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { Controller, FormProvider, useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { useToast } from "@/context/toastContext";
import { useParams, useRouter } from "next/navigation";
import MediaUpload from "@/components/shared/uploadMedia";
import CreatePage_top_Tabs from "../createPage_top_Tabs/createPage_top_Tabs";
import {
  AiFillGolden,
  AiOutlineTag,
  AiTwotoneDelete,
  AiTwotoneEdit,
} from "react-icons/ai";
import {
  addMediaAsset,
  deleteAsset,
  fetchMediaAssetById,
  setMediaEntryStatus,
  updateMediaAsset,
  uploadMedia,
  setCurrTitle,
  setCurrUploadFile,
  setMediaSubmitButton,
  setCreateMediaOpen,
  fetchAllMediaAsset,
  setCurrDescription,
} from "@/store/actions/media";
import { APP_URLS, replaceUrlParams } from "@/utils/constants";
import { usePathname } from "next/navigation";

const schema = yup.object({
  title: yup.string().max(50, "Title must be at most 50 characters long"),
  description: yup
    .string()
    .max(500, "Description must be at most 500 characters long"),
  file: yup.mixed().required(),
});

export default function CreateForm({
  isEditMode,
  existingMedia,
  onClose,
  isOpen,
  setNewAsset = () => {},
  referenceImage,
}) {
  const [titleCharCount, settitleCharCount] = useState(0);
  const [descriptionCharCount, setDescriptionCharCount] = useState(0);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [fileRequiredMessage, setFileRequiredMessage] = useState("");
  const {
    files,
    mediaType,
    mediaDimensions,
    mediaEntryStatus,
    mediaSubmitButton,
  } = useSelector((state) => state.media);
  const { assetValues } = useSelector((state) => state.media);
  const methods = useForm({
    defaultValues: {
      title: "",
      description: "",
      file: null,
    },
    mode: "onChange",
    resolver: yupResolver(schema),
  });

  const editValues = assetValues
    ? assetValues
    : existingMedia
      ? existingMedia
      : "";

  const {
    handleSubmit,
    control,
    formState: { errors, values },
  } = methods;

  const dispatch = useDispatch();
  const { addToast } = useToast();
  const pathname = usePathname();
  const router = useRouter();
  const params = useParams();
  const { assetId, spaceId, spaceEnvironmentId } = params;
  const currTitle = methods.watch("title");
  const currDesc = methods.watch("description");

  const existingID = existingMedia?.assetId || assetId;

  const handleMediaChange = async (mediaFile, mediaType, mediaDimensions) => {
    const maxSizeInBytes = 10 * 1024 * 1024; // 10MB in bytes
    if (mediaFile.size > maxSizeInBytes) {
      addToast("File size exceeds the maximum limit of 10MB.", {
        type: "error",
      });
      return;
    }

    const allowedFormats = [
      "image/png",
      "image/jpeg",
      "image/jpg",
      "image/gif",
    ];
    const fileType = mediaFile.type.toLowerCase();

    if (!allowedFormats.includes(fileType)) {
      addToast(
        "Invalid file format. Only PNG, JPEG, JPG, and GIF formats are allowed.",
        {
          type: "error",
        }
      );
      return;
    }

    setUploadedFile(mediaFile);

    try {
      const res = await dispatch(
        uploadMedia(mediaFile, mediaType, mediaDimensions)
      );

      const {
        result: { body },
      } = res;

      if (body.responseCode === 200) {
        addToast(body.responseMessage);
      } else {
        addToast(body?.responseMessage || "An unknown error occurred!", {
          type: "error",
        });
      }
    } catch (err) {
      console.log("error: ", err);
    }
  };

  useEffect(() => {
    if (assetValues?.status === "PUBLISHED" && isEditMode) {
      if (
        currTitle !== editValues.title ||
        currDesc !== editValues.description ||
        Boolean(uploadedFile)
      ) {
        dispatch(setMediaEntryStatus("CHANGED"));
      }
    }
  }, [currTitle, currDesc, uploadedFile]);

  useEffect(() => {
    if (assetValues?.status === "PUBLISHED" && isEditMode) {
      window.addEventListener("beforeunload", onSubmitButtonClick, {
        capture: true,
      });
      return () => {
        window.removeEventListener("beforeunload", onSubmitButtonClick, {
          capture: true,
        });
        if (
          currTitle !== editValues.title ||
          currDesc !== editValues.description ||
          Boolean(uploadedFile)
        ) {
          const isUploadFile = Boolean(uploadedFile) || "";
          const reqData = {
            status: "CHANGED",
            title: currTitle || editValues.title,
            description: currDesc || editValues.description,
            url: isUploadFile || assetValues?.url,
            mediaType:
              isEditMode && editValues?.mediaType ? editValues?.mediaType : "",
            dimensions:
              isEditMode && editValues?.dimensions
                ? editValues?.dimensions
                : mediaDimensions
                  ? `${mediaDimensions.width}:${mediaDimensions.height}`
                  : "",
          };

          dispatch(
            updateMediaAsset(existingID, reqData, spaceId, spaceEnvironmentId)
          );
        }
      };
    } else if (!isEditMode) {
      window.addEventListener("beforeunload", onSubmitButtonClick, {
        capture: true,
      });

      return () => {
        window.removeEventListener("beforeunload", onSubmitButtonClick, {
          capture: true,
        });
        if (pathname?.includes("media/create")) {
          if (Boolean(uploadedFile) && !isEditMode) {
            onSubmitButtonClick();
          }
        }
      };
    }
  }, [router, pathname, files, mediaType, mediaDimensions, assetValues]);

  useEffect(() => {
    if (isEditMode && editValues) {
      methods.reset({
        title: editValues.title,
        description: editValues.description || "",
        file: editValues.url, // Assuming this is the field you want to pre-fill
      });
    } else {
      methods.reset({
        title: null,
        description: "",
        file: null,
      });
    }
  }, [isEditMode, editValues]);

  useEffect(() => {
    if (mediaSubmitButton) {
      const submitButton = document.getElementById("submit-media-button");
      if (submitButton) {
        onSubmitButtonClick();
      }
    }
  }, [mediaSubmitButton]);

  const onSubmitButtonClick = () => {
    const formValues = methods.getValues();
    onSubmit(formValues);
  };

  const onSubmit = async (values) => {
    if (mediaSubmitButton !== true) {
      return;
    }

    let data;
    if (isEditMode) {
      const isUploadFile = Boolean(uploadedFile) ? files?.[0] : "";
      data = {
        status: mediaEntryStatus,
        title: values?.title,
        description: values?.description,
        url: isUploadFile || assetValues?.url || values?.file,
        mediaType:
          isEditMode && editValues?.mediaType ? editValues?.mediaType : "",
        dimensions:
          isEditMode && editValues?.dimensions
            ? editValues?.dimensions
            : mediaDimensions
              ? `${mediaDimensions.width}:${mediaDimensions.height}`
              : "",
      };
    } else {
      data = {
        status: mediaEntryStatus,
        title: values?.title,
        description: values?.description,
        url: files?.[0],
        mediaType: mediaType ? mediaType : "",
        dimensions: mediaDimensions
          ? `${mediaDimensions.width}:${mediaDimensions.height}`
          : "",
      };
    }

    try {
      let res;
      if (isEditMode) {
        res = await dispatch(
          updateMediaAsset(existingID, data, spaceId, spaceEnvironmentId)
        );
      } else {
        if (uploadedFile) {
          res = await dispatch(
            addMediaAsset(data, spaceId, spaceEnvironmentId)
          );
        } else {
          setFileRequiredMessage("Required");
        }
      }
      const {
        result: { body },
      } = res;
      if (body.responseCode === 200) {
        addToast(body.responseMessage);
        dispatch(setMediaSubmitButton(false));
        if (isOpen || existingMedia) {
          onClose(false);
          setNewAsset(body?.response);
          dispatch(fetchAllMediaAsset(spaceId, spaceEnvironmentId));
        } else {
          router.push(
            replaceUrlParams(APP_URLS.MEDIA.LIST, {
              spaceId: spaceId,
              spaceEnvironmentId: spaceEnvironmentId,
            })
          );
        }
      } else {
        addToast(body?.responseMessage || "An unknown error occured!", {
          type: "error",
        });
      }
      ``;
    } catch (err) {
      console.log("error: ", err);
    } finally {
      dispatch(uploadMedia(""));
    }
  };

  const sidebarOptions_Content = [
    { title: "Editor", icon: <AiFillGolden /> },
    { title: "Tags", icon: <AiOutlineTag /> },
  ];

  useEffect(() => {
    if (isEditMode && existingID) {
      dispatch(fetchMediaAssetById(existingID, spaceId, spaceEnvironmentId));
    }
  }, [existingID]);

  useEffect(() => {
    if (isEditMode && editValues) {
      methods.reset({
        title: editValues.title,
        description: editValues.description || "",
        file: editValues.url, // Assuming this is the field you want to pre-fill
      });
    } else {
      methods.reset({
        title: null,
        description: "",
        file: null,
      });
    }
  }, [isEditMode, editValues]);

  useEffect(() => {
    if (!isEditMode) {
      dispatch(setMediaEntryStatus("DRAFT"));
    }
  }, [isEditMode]);

  useEffect(() => {
    if (Boolean(uploadedFile)) {
      dispatch(setCurrUploadFile(uploadedFile));
    } else if (Boolean(editValues?.url)) {
      dispatch(setCurrUploadFile(editValues?.url));
    } else {
      dispatch(setCurrUploadFile(""));
    }
  }, [uploadedFile, editValues?.url]);

  useEffect(() => {
    if (currTitle?.length > 0) {
      dispatch(setCurrTitle(currTitle));
    } else {
      dispatch(setCurrTitle(""));
    }
  }, [currTitle]);
  useEffect(() => {
    if (descriptionCharCount > 0) {
      dispatch(setCurrDescription(descriptionCharCount));
    } else {
      dispatch(setCurrDescription(""));
    }
  }, [descriptionCharCount]);

  useEffect(() => {
    if (uploadedFile) {
      dispatch({ type: "UPDATE_FILES", payload: [uploadedFile] });
    }
  }, [uploadedFile]);

  useEffect(() => {
    if (editValues?.title) {
      settitleCharCount(editValues?.title?.length);
    }
    if (editValues?.description) {
      setDescriptionCharCount(editValues?.description?.length);
    }
  }, [editValues]);

  useEffect(() => {
    dispatch(setMediaSubmitButton(false));
  }, []);

  return (
    <>
      <div className={styles.wrapper}>
        <CreatePage_top_Tabs options={sidebarOptions_Content} />
        <div className={styles.container}>
          <FormProvider {...methods}>
            <form
              onSubmit={handleSubmit(onSubmit)}
              className={styles["publish-form"]}
            >
              <Controller
                control={control}
                name="title"
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Title"
                    placeholder="Title"
                    error={errors?.title?.message}
                    hint={titleCharCount + " characters"}
                    onChange={(e) => {
                      field.onChange(e);
                      settitleCharCount(e.target.value.length);
                    }}
                  />
                )}
              />
              <Controller
                control={control}
                name="description"
                render={({ field }) => (
                  <>
                    <TextArea
                      {...field}
                      label="Description"
                      className="textarea"
                      placeholder="Description"
                      error={errors?.description?.message}
                      hint={
                        <div className={styles.descriptionLimit}>
                          <div
                            dangerouslySetInnerHTML={{
                              __html: `${descriptionCharCount} characters`,
                            }}
                          ></div>
                          <div>Maximum 500 characters</div>
                        </div>
                      }
                      onChange={(e) => {
                        field.onChange(e);
                        setDescriptionCharCount(e.target.value.length);
                      }}
                    />
                  </>
                )}
              />

              <Controller
                control={control}
                name="file"
                render={({ field }) => (
                  <div>
                    <MediaUpload
                      {...field}
                      label="File"
                      required
                      isEditMode={isEditMode}
                      onMediaChange={handleMediaChange}
                      setUploadedFile={setUploadedFile}
                      setFileRequiredMessage={setFileRequiredMessage}
                      isContentExisitPopupOpen={isOpen}
                    />
                    <span style={{ display: "block", marginTop: 10 }}>
                      {!uploadedFile && (
                        <span style={{ color: "red", fontSize: 14 }}>
                          {fileRequiredMessage && fileRequiredMessage}
                        </span>
                      )}
                    </span>
                  </div>
                )}
              />
              <Button
                size="md"
                id="submit-media-button"
                className={styles["submit-button"]}
                text="Publish"
                textAlign="center"
                type="submit"
                disabled={Boolean(uploadedFile)}
                onClick={
                  !Boolean(uploadedFile) ? onSubmitButtonClick : () => {}
                }
              />
            </form>
          </FormProvider>
        </div>
      </div>
    </>
  );
}
