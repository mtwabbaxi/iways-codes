import React, { useCallback } from "react";
import styles from "./allFieldsCell.module.scss";
import FieldCell from "../shared/fieldCell";

import { RxText } from "react-icons/rx";
import { AiOutlineNumber } from "react-icons/ai";
import { SlLocationPin } from "react-icons/sl";
import { GoFileMedia } from "react-icons/go";
import { RxReader } from "react-icons/rx";
import { AiOutlineCalendar } from "react-icons/ai";
import { PiCircleHalfTiltDuotone } from "react-icons/pi";
import { VscJson } from "react-icons/vsc";
import { VscReferences } from "react-icons/vsc";
import fieldsData from "@/data/fields";

export default function AllFieldsCell({ onCellClick = () => {} }) {
  const getTypeIcon = useCallback((type) => {
    switch (type) {
      case "RICH_TEXT":
        return RxReader;
      case "MEDIA":
        return GoFileMedia;
      case "NUMBER":
        return AiOutlineNumber;
      case "DATETIME":
        return AiOutlineCalendar;
      case "JSON":
        return VscJson;
      case "REFERENCE":
        return VscReferences;
      case "LOCATION":
        return SlLocationPin;
      case "BOOLEAN":
        return PiCircleHalfTiltDuotone;
      case "SHORT_TEXT":
      default:
        return RxText;
    }
  });

  return (
    <div className={styles.container}>
      {fieldsData.map((field, index) => (
        <FieldCell
          key={index}
          icon={getTypeIcon(field.fieldType)}
          heading={field.contentTypeDetail.title}
          subHeading={field.contentTypeDetail.subTitle}
          onClick={onCellClick}
          type={field.fieldType}
          field={field}
        />
      ))}
    </div>
  );
}
