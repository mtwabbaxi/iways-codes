"use client"
import {useState, useEffect} from "react"
import styles from "./header.module.scss"
import {AiOutlineSetting} from "react-icons/ai"
import {
	isSubmitButton,
	deleteLocales,
	fetchAllLocales,
	selectedLocaleData,
} from "@/store/actions/locales"
import {useDispatch, useSelector} from "react-redux"
import {useParams, useRouter} from "next/navigation"
import {APP_URLS, replaceUrlParams} from "@/utils/constants"
import LocalesConfirmPopup from "../localesConfirmPopup/localesConfirmPopup"
import {useToast} from "@/context/toastContext"
import Link from "next/link"
import {BsArrowLeft} from "react-icons/bs"

export default function Header({page}) {
	const [isDeletePopupOpen, setIsDeletePopupOpen] = useState(false)
	const [isDeleteConfirmed, setisDeleteConfirmed] = useState(false)
	const {localeCurrValue, seletedLocaleValue} = useSelector(
		(state) => state.locales
	)
	const dispatch = useDispatch()
	const router = useRouter()
	const params = useParams()
	const {addToast} = useToast()
	const {spaceId, spaceEnvironmentId} = params
	const currLanguage =
		seletedLocaleValue?.languageCode === "af"
			? "Afrikaans"
			: seletedLocaleValue?.languageCode === "ar"
			  ? "Arabic"
			  : seletedLocaleValue?.languageCode === "zh"
			    ? "Chinese"
			    : seletedLocaleValue?.languageCode === "en-US"
			      ? "English (United States)"
			      : seletedLocaleValue?.languageCode === "fr"
			        ? "French"
			        : seletedLocaleValue?.languageCode === "de"
			          ? "German"
			          : ""

	const submitHandler = () => {
		dispatch(isSubmitButton(true))
	}

	const deleteHandler = () => {
		setIsDeletePopupOpen(true)
	}

	const cancelandler = () => {
		dispatch(selectedLocaleData(""))
		router.push(
			replaceUrlParams(APP_URLS.SETTINGS.LOCALES.LIST, {
				spaceId: spaceId,
				spaceEnvironmentId: spaceEnvironmentId,
			})
		)
	}

	const handleDelete = async (row) => {
		try {
			let res = null
			const data = {
				localeId: row.localeId,
			}
			res = await dispatch(deleteLocales(data))
			const {
				result: {body},
			} = res
			if (body.responseCode === 200) {
				addToast(body.responseMessage)
				dispatch(fetchAllLocales(spaceId, spaceEnvironmentId))
				dispatch(selectedLocaleData(""))
				router.push(
					replaceUrlParams(APP_URLS.SETTINGS.LOCALES.LIST, {
						spaceId: spaceId,
						spaceEnvironmentId: spaceEnvironmentId,
					})
				)
			} else {
				addToast(body?.responseMessage || "An unknown error occured!", {
					type: "error",
				})
			}
		} catch (err) {
			console.log("error: ", err)
		} finally {
			setIsDeletePopupOpen(false)
			setisDeleteConfirmed(false)
		}
	}

	useEffect(() => {
		if (isDeleteConfirmed) {
			handleDelete(seletedLocaleValue)
		} else {
			setIsDeletePopupOpen(false)
		}
	}, [isDeleteConfirmed])

	return (
		<>
			<div className={styles.container}>
				<div className={styles.heading}>
					{page === "create" && (
						<>
							<Link
								href={replaceUrlParams(APP_URLS.SETTINGS.LOCALES.LIST, {
									spaceId: spaceId,
									spaceEnvironmentId: spaceEnvironmentId,
								})}
							>
								<div className={styles.back}>
									<BsArrowLeft />
								</div>
							</Link>
							<p className="m-0 color-gray-500 text-body1">/</p>
						</>
					)}
					<AiOutlineSetting />
					<h3 className="text-body1 font-weight-semi-bold">
						{currLanguage !== ""
							? currLanguage
							: page === "create"
							  ? "New Locale"
							  : "Locales"}
					</h3>
				</div>
				{page === "create" && (
					<div className={styles.buttons}>
						<button className={styles.cancel} onClick={() => cancelandler()}>
							Cancel
						</button>
						{Boolean(seletedLocaleValue.localeId) &&
							!seletedLocaleValue?.default && (
								<button
									className={styles.delete}
									onClick={() => deleteHandler()}
								>
									Delete
								</button>
							)}
						<button
							className={`${styles.save} ${
								!localeCurrValue && styles.disabled
							}`}
							disabled={!localeCurrValue}
							onClick={() => submitHandler()}
						>
							Save
						</button>
					</div>
				)}
			</div>
			{isDeletePopupOpen && (
				<LocalesConfirmPopup
					setIsDeletePopupOpen={setIsDeletePopupOpen}
					setisDeleteConfirmed={setisDeleteConfirmed}
					message={"Are you sure you want to delete this environment?"}
					currRow={seletedLocaleValue}
					currLanguage={currLanguage}
				/>
			)}
		</>
	)
}
