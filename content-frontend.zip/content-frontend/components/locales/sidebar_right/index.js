import React, { useEffect, useState } from "react";
import styles from "./sidebar.module.scss";
import { BsExclamationTriangle } from "react-icons/bs";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { APP_URLS, replaceUrlParams } from "@/utils/constants";
import { useDispatch, useSelector } from "react-redux";
import { fetchAllSpaces } from "@/store/actions/spaces";
import {
  fetchAllSubscriptionPlan,
  setUserSubscription,
} from "@/store/actions/subscriptionplan";

export default function Sidebar_Right({}) {
  const router = useRouter();
  const dispatch = useDispatch();
  const { spaceId, spaceEnvironmentId } = useParams();
  const { allSpaces } = useSelector((state) => state.spaces);
  const [localeDetails, setLocaleDetails] = useState({});

  const handlerCreateForm = () => {
    router.push(
      replaceUrlParams(APP_URLS.SETTINGS.LOCALES.CREATE, {
        spaceId: spaceId,
        spaceEnvironmentId: spaceEnvironmentId,
      })
    );
  };
  useEffect(() => {
    if (dispatch) {
      dispatch(fetchAllSpaces());
    }
  }, [dispatch]);

  useEffect(() => {
    if (allSpaces?.content?.length) {
      const filterSelectedSpaceData = allSpaces?.content.find(
        (s) => s.spaceId === spaceId
      );
      const data = {
        limit: filterSelectedSpaceData.upperLimits.locale,
        usage: filterSelectedSpaceData.usage.locale,
      };
      setLocaleDetails(data);
    }
  }, [allSpaces, spaceId]);

  return (
    <>
      <div className={styles.container}>
        <div className={styles.sidebar}>
          <div className={styles.usage}>
            <h2>LOCALES USAGE</h2>
          </div>
          <div className={styles.env_number}>
            <p>This environment</p>
            <p>{localeDetails?.usage}</p>
          </div>
          <div className={styles.org_spaces}>
            <p>
              <Link href="#">Your organization</Link> (all spaces)
            </p>
            <p>
              {localeDetails?.usage === localeDetails?.limit && (
                <span>
                  <BsExclamationTriangle />
                </span>
              )}{" "}
              {localeDetails?.usage}/{localeDetails?.limit}
            </p>
          </div>
          <p className={styles.more_locales}>
            Do you need to add more locales?
            <br />
            <Link href="#">Upgrade your package</Link>
          </p>
          <button className={styles.add_env} onClick={handlerCreateForm}>
            Add Locale
          </button>
        </div>
      </div>
    </>
  );
}
