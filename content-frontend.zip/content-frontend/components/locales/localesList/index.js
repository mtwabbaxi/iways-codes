"use client"

import {useState, useEffect} from "react"
import Header from "@/components/contentModel/header"
import {DataTable} from "@/components/theme/datatable"
import {useParams, useRouter} from "next/navigation"
import {APP_URLS, replaceUrlParams} from "@/utils/constants"
import NoSearchedData from "@/components/contentModel/tableContentModel/NoSearchedData"
import {deleteField, fetchAllContentModels} from "@/store/actions/contentModel"
import {useDispatch, useSelector} from "react-redux"
import styles from "./localesList.module.scss"
import {format, formatDistance, formatRelative, subDays} from "date-fns"
import {
	FaChevronLeft,
	FaChevronRight,
	FaChevronUp,
	FaChevronDown,
} from "react-icons/fa"

import {deleteEnvironment} from "@/store/actions/environments"

import {fetchAllLocales, selectedLocaleData} from "@/store/actions/locales"
import {ContextMenu} from "@/components/theme/menus"
import {useToast} from "@/context/toastContext"

export default function LocalsList() {
	const dispatch = useDispatch()
	const router = useRouter()
	const {addToast} = useToast()
	const [filteredData, setFilteredData] = useState([])
	const [searchText, setSearchText] = useState("")
	const [currentPage, setCurrentPage] = useState(1)
	const itemsPerPage = 50
	const {searchNameContent} = useSelector((state) => state.contentModel)
	const {spaceId, spaceEnvironmentId} = useParams()
	const [sortOrder, setSortOrder] = useState("asc")
	const [currRow, setCurrRow] = useState("")
	const [isDeleteConfirmed, setisDeleteConfirmed] = useState(false)
	const {filterValue} = useSelector((state) => state.environments)

	const {allLocales} = useSelector((state) => state.locales)

	const startIdx = (currentPage - 1) * itemsPerPage
	const endIdx = startIdx + itemsPerPage
	const displayedData = filteredData?.slice(startIdx, endIdx)

	const totalPages = Math.ceil(filteredData?.length / itemsPerPage)

	useEffect(() => {
		dispatch(fetchAllLocales(spaceId, spaceEnvironmentId))
		dispatch(selectedLocaleData(""))
		dispatch(fetchAllContentModels(spaceId, spaceEnvironmentId))
	}, [])
	const handleSort = (key) => {
		const newSortOrder = sortOrder === "asc" ? "desc" : "asc"
		setSortOrder(newSortOrder)
		setFilteredData((prevData) => {
			const sortedData = [...prevData]
			sortedData.sort((a, b) => {
				if (newSortOrder === "asc") {
					return a[key] > b[key] ? 1 : -1
				} else {
					return b[key] > a[key] ? 1 : -1
				}
			})
			return sortedData
		})
	}

	const handleNextPage = () => {
		if (currentPage < totalPages) {
			setCurrentPage(currentPage + 1)
		}
	}

	const handleDelete = async (row) => {
		try {
			let res = null
			const data = {
				spaceEnvironmentId: row.spaceEnvironmentId,
			}
			res = await dispatch(deleteEnvironment(data))
			const {
				result: {body},
			} = res
			if (body.responseCode === 200) {
				addToast(body.responseMessage)
				dispatch(fetchAllLocales(spaceId, spaceEnvironmentId))
			} else {
				addToast(body?.responseMessage || "An unknown error occured!", {
					type: "error",
				})
			}
		} catch (err) {
			console.log("error: ", err)
		} finally {
			setCurrRow("")
			setisDeleteConfirmed(false)
		}
	}

	const columns = [
		{
			title: "Locale",
			key: "languageCode",
			render: (allLocales) => {
				return (
					<div className={styles.languageCode}>
						<div className="font-weight-medium">
							{allLocales.languageCode === "en-US"
								? " English (United States) (en-US)"
								: allLocales.languageCode === "af"
								  ? " Afrikaans (af)"
								  : allLocales.languageCode === "ar"
								    ? " Arabic (ar)"
								    : allLocales.languageCode === "zh"
								      ? "Chinese (zh)"
								      : allLocales.languageCode === "fr"
								        ? "French (fr)"
								        : allLocales.languageCode === "de"
								          ? "German (de)"
								          : allLocales.languageCode}
							{allLocales.default && (
								<span className={styles.default}>
									<div>
										<span>Default</span>
									</div>
								</span>
							)}
						</div>
					</div>
				)
			},
		},
		{
			title: "Fallback",
			key: "fallBack",
			render: (allLocales) => {
				return (
					<div className={styles.fallBack}>
						<div className="font-weight-medium">
							{allLocales.fallBack === "en-US"
								? " English (United States) (en-US)"
								: allLocales.fallBack === "af"
								  ? " Afrikaans (af)"
								  : allLocales.fallBack === "ar"
								    ? " Arabic (ar)"
								    : allLocales.fallBack === "zh"
								      ? "Chinese (zh)"
								      : allLocales.fallBack === "fr"
								        ? "French (fr)"
								        : allLocales.fallBack === "de"
								          ? "German (de)"
								          : "None"}
						</div>
					</div>
				)
			},
		},
		{
			title: "	Incl. in response",
			key: "includedInResponse",
			render: (allLocales) => {
				return (
					<div className={styles.includedInResponse}>
						<div className="font-weight-medium">
							{allLocales.includedInResponse ? "Enabled" : "Disabled"}
						</div>
					</div>
				)
			},
		},
		{
			title: "Editing",
			key: "editing",
			render: (allLocales) => {
				return (
					<div className={styles.editing}>
						<div className="font-weight-medium">
							{allLocales.editing ? "Enabled" : "Disabled"}
						</div>
					</div>
				)
			},
		},
		{
			title: "Required fields",
			key: "requiredField",
			render: (allLocales) => {
				return (
					<div className={styles.requiredField}>
						<div className="font-weight-medium">
							{!allLocales.requiredField
								? "Content is required"
								: "Can be published empty"}
						</div>
					</div>
				)
			},
		},
	]

	const handlePrevPage = () => {
		if (currentPage > 1) {
			setCurrentPage(currentPage - 1)
		}
	}

	const handlePageChange = (page) => {
		if (page >= 1 && page <= totalPages) {
			setCurrentPage(page)
		}
	}

	useEffect(() => {
		if (searchNameContent?.data?.length > 0) {
			setSearchText(searchNameContent.data)
			setFilteredData(
				allLocales?.content?.filter(
					(f) =>
						f?.name
							?.toLowerCase()
							.indexOf(searchNameContent.data.toLowerCase()) !== -1
				)
			)
		} else if (allLocales?.content?.length) {
			setFilteredData(allLocales?.content)
		} else {
			setFilteredData(allLocales?.content)
		}
	}, [allLocales, searchNameContent])

	const rowClickHandler = (row) => {
		if (row.localeId) {
			dispatch(selectedLocaleData(row))
			router.push(
				replaceUrlParams(APP_URLS.SETTINGS.LOCALES.UPDATE, {
					spaceId: spaceId,
					spaceEnvironmentId: spaceEnvironmentId,
					localeId: row.localeId,
				})
			)
		}
	}

	useEffect(() => {
		// Initialize filteredData with allLocales.content
		setFilteredData(allLocales?.content)

		if (filterValue) {
			// If there is a filter value, update filteredData
			// Add your filtering logic here based on the filterValue
			setFilteredData((prevData) =>
				prevData.filter(
					(entry) => entry.contentModelId === filterValue
					// Add your filter condition here, e.g., entry.property === filterValue
				)
			)
		}

		// Set search text to empty when there is no filter or when filterValue is empty
		setSearchText("")
	}, [allLocales, filterValue])

	useEffect(() => {
		if (isDeleteConfirmed) {
			handleDelete(currRow)
		} else {
			setCurrRow("")
		}
	}, [isDeleteConfirmed])

	return (
		<>
			{/* <Header searchText={searchText} onSearchChange={handleSearchChange} /> */}

			{Boolean(!displayedData?.length) && <NoSearchedData />}

			{Boolean(displayedData?.length) && (
				<>
					<DataTable
						rowClickHandler={rowClickHandler}
						columns={columns}
						dataSource={displayedData}
					/>
					{/* <div className={styles.pagination}>
						<span>{`${startIdx + 1} - ${startIdx + displayedData.length} of ${
							filteredData.length
						} items`}</span>
						{filteredData.length > itemsPerPage && (
							<>
								<button onClick={handlePrevPage} disabled={currentPage === 1}>
									<FaChevronLeft />
								</button>
								<button
									onClick={handleNextPage}
									disabled={currentPage === totalPages}
								>
									<FaChevronRight />
								</button>
							</>
						)}
					</div> */}
				</>
			)}
		</>
	)
}
