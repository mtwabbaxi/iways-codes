"use client";

import React, { useEffect, useState } from "react";
import styles from "./localesCreateForm.module.scss";
import { TextField, TextArea, Checkbox } from "@/components/theme/form-inputs";
import { Button } from "@/components/theme/buttons";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { Controller, FormProvider, useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { useToast } from "@/context/toastContext";
import { useParams, useRouter } from "next/navigation";
import { AiFillGolden, AiOutlineTag } from "react-icons/ai";
import { APP_URLS, replaceUrlParams } from "@/utils/constants";
import DropdownField from "@/components/shared/dropdownfield/dropdownfield";
import { FcInfo } from "react-icons/fc";
import {
  fetchAllLocales,
  setCurrLocale,
  addLocale,
  isSubmitButton,
  updateLocale,
  selectedLocaleData,
} from "@/store/actions/locales";
import { fetchAllSpaces } from "@/store/actions/spaces";

const schema = yup.object({});

export default function LocalesCreateForm({ isEditMode }) {
  const [titleCharCount, settitleCharCount] = useState(0);
  const [descriptionCharCount, setDescriptionCharCount] = useState(0);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [fileRequiredMessage, setFileRequiredMessage] = useState("");
  const [selectedLocale, setSelectedLocale] = useState("");
  const [selectedFallback, setSelectedFallback] = useState("");
  const { allLocales, isLocaleSubmit, seletedLocaleValue } = useSelector(
    (state) => state.locales
  );

  const methods = useForm({
    defaultValues: {
      localeInResponse: false,
      editing: false,
      empty_field: false,
    },
    mode: "onChange",
    resolver: yupResolver(schema),
  });

  const {
    handleSubmit,
    control,
    formState: { errors, values },
  } = methods;

  const dispatch = useDispatch();
  const { addToast } = useToast();
  const router = useRouter();
  const params = useParams();
  const { localeId, spaceId, spaceEnvironmentId } = params;
  const currTitle = methods.watch("title");

  const SELETE_LOCALE = [
    {
      id: 1,
      children: [
        { id: 1, title: "Select a locale", value: "" },
        { id: 2, title: "Afrikaans (af)", value: "af" },
        { id: 3, title: "Arabic (ar)", value: "ar" },
        { id: 4, title: "Chinese (zh)", value: "zh" },
        {
          id: 5,
          title: "English (United States) (en-US)",
          value: "en-US",
        },
        { id: 6, title: "French (fr)", value: "fr" },
        { id: 7, title: "German (de)", value: "de" },
      ],
    },
  ];

  const SELETE_FALLBACK = [
    {
      id: 1,
      children: [
        { id: 1, title: "None (no fallback)", value: "None" },
        ...allLocales?.content
          ?.filter((locale) => locale.languageCode !== selectedLocale?.value)
          ?.map((locale) => ({
            id: locale.localeId,
            title:
              locale.languageCode === "en-US"
                ? " English (United States) (en-US)"
                : locale.languageCode === "af"
                  ? " Afrikaans (af)"
                  : locale.languageCode === "ar"
                    ? " Arabic (ar)"
                    : locale.languageCode === "zh"
                      ? "Chinese (zh)"
                      : locale.languageCode === "fr"
                        ? "French (fr)"
                        : locale.languageCode === "de"
                          ? "German (de)"
                          : locale.languageCode,
            value: locale.languageCode,
          })),
      ],
    },
  ];

  const LOCALE_SETTINGS = {
    options: [
      {
        name: "localeInResponse",
        value: "localeInResponse",
        label: "Enable this locale in response",
        hint: "Includes locale in the Delivery API response.",
      },
      {
        name: "editing",
        value: "editing",
        label: "Enable editing for this locale",
        hint: "Displays locale to editors and enables it in Management API.",
      },
      {
        name: "empty_field",
        value: "empty_field",
        label: "Allow empty fields for this locale",
        hint: "Entries with required fields can still be published if locale is empty.",
      },
    ],
  };

  useEffect(() => {
    if (isLocaleSubmit) {
      onSubmitButtonClick();
    }
  }, [isLocaleSubmit]);

  const onSubmitButtonClick = () => {
    const formValues = methods.getValues();
    onSubmit(formValues);
  };

  const onSubmit = async (values) => {
    let data;
    if (isEditMode) {
      data = {
        languageCode: selectedLocale?.value || seletedLocaleValue?.languageCode,
        fallBack: selectedFallback?.value || seletedLocaleValue?.fallBack,
        editing: values.editing,
        includedInResponse: values.localeInResponse,
        requiredField: values.empty_field,
        spaceId: spaceId,
      };
    } else {
      data = {
        languageCode: selectedLocale?.value,
        fallBack: selectedFallback?.value,
        editing: values.editing,
        includedInResponse: values.localeInResponse,
        requiredField: values.empty_field,
        spaceId: spaceId,
      };
    }

    try {
      let res;
      if (isEditMode) {
        res = await dispatch(
          updateLocale(localeId, data, spaceId, spaceEnvironmentId)
        );
      } else {
        res = await dispatch(addLocale(data, spaceId, spaceEnvironmentId));
      }
      const {
        result: { body },
      } = res;
      if (body.responseCode === 200) {
        addToast(body.responseMessage);
        dispatch(isSubmitButton(false));
        dispatch(fetchAllSpaces());

        router.push(
          replaceUrlParams(APP_URLS.SETTINGS.LOCALES.LIST, {
            spaceId: spaceId,
            spaceEnvironmentId: spaceEnvironmentId,
          })
        );
      } else {
        addToast(body?.responseMessage || "An unknown error occured!", {
          type: "error",
        });
      }
      ``;
    } catch (err) {
      console.log("error: ", err);
    } finally {
      dispatch(selectedLocaleData(""));
    }
  };

  const sidebarOptions_Content = [
    { title: "Editor", icon: <AiFillGolden /> },
    { title: "Tags", icon: <AiOutlineTag /> },
  ];

  useEffect(() => {
    if (isEditMode && seletedLocaleValue) {
      methods.reset({
        localeInResponse: seletedLocaleValue?.includedInResponse,
        editing: seletedLocaleValue?.editing,
        empty_field: seletedLocaleValue?.requiredField,
      });
      const selectedLocaleOption = SELETE_LOCALE[0].children.find(
        (option) => option.value === seletedLocaleValue?.languageCode
      );
      const selectedFallbackOption = SELETE_FALLBACK[0].children.find(
        (option) => option.value === seletedLocaleValue?.fallBack
      );
      setSelectedLocale(selectedLocaleOption || "");
      setSelectedFallback(selectedFallbackOption || "none");
    } else {
      methods.reset({
        localeInResponse: false,
        editing: false,
        empty_field: false,
      });
    }
  }, [isEditMode, seletedLocaleValue]);

  useEffect(() => {
    if (selectedLocale.id) {
      dispatch(setCurrLocale(selectedLocale.value));
    } else {
      dispatch(setCurrLocale(""));
    }
  }, [selectedLocale]);

  useEffect(() => {
    if (uploadedFile) {
      dispatch({ type: "UPDATE_FILES", payload: [uploadedFile] });
    }
  }, [uploadedFile]);

  useEffect(() => {
    dispatch(fetchAllLocales(spaceId, spaceEnvironmentId));
  }, []);

  return (
    <>
      <div className={styles.wrapper}>
        <div className={styles.container}>
          <FormProvider {...methods}>
            <form
              onSubmit={handleSubmit(onSubmit)}
              className={styles["publish-form"]}
            >
              <div className={styles.select_locale}>
                <label>Locale</label>
                <DropdownField
                  data={SELETE_LOCALE}
                  selectedvalue={selectedLocale}
                  setSelectedValue={setSelectedLocale}
                />
              </div>
              <div className={styles.fallback_locale}>
                <label>Fallback locale</label>
                <p>
                  If no content is provided for the locale above, the Delivery
                  API will return content in a locale specified below:
                </p>
                <DropdownField
                  data={SELETE_FALLBACK}
                  selectedvalue={selectedFallback}
                  setSelectedValue={setSelectedFallback}
                />
              </div>

              <div className={styles.enabled_field}>
                <FcInfo />
                <div className={styles.message}>
                  <p>
                    If you have required fields in your content model,{" "}
                    <b> enable empty required fields</b> (there’s a checkbox
                    below). You need to do that because required fields can’t be
                    published when content in a certain locale is not provided.
                  </p>
                </div>
              </div>
              <div className={styles.checkboxes_container}>
                <label>Locale settings</label>

                {LOCALE_SETTINGS.options.map((item, index) => {
                  return (
                    <div className={styles.checkboxes_wrapper}>
                      <Controller
                        key={"" + index}
                        name={item.name}
                        control={control}
                        render={({ field }) => {
                          return (
                            <Checkbox
                              {...field}
                              id={item.value}
                              checked={field.value}
                              value={item.value}
                              label={item.label}
                              hint={item.hint}
                            />
                          );
                        }}
                      />
                    </div>
                  );
                })}
              </div>
            </form>
          </FormProvider>
        </div>
      </div>
    </>
  );
}
