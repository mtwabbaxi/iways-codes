import {useState} from "react"
import styles from "./localesConfirmPopup.module.scss"
import {TextField} from "@/components/theme/form-inputs"
import {AiFillExclamationCircle} from "react-icons/ai"

const LocalesConfirmPopup = ({
	setIsDeletePopupOpen,
	setisDeleteConfirmed,
	message,
	currRow,
	currLanguage,
}) => {
	const [localesCode, setLocalesCode] = useState("")
	const handleOverlayClick = (e) => {
		if (!e.target.closest(`.${styles.deleteConfirmPopup}`)) {
			setIsDeletePopupOpen(false)
		}
	}

	return (
		<div className={styles.container}>
			<div
				className={`${styles.overlay} ${styles.isContentDeletePopupOpen}`}
				onClick={handleOverlayClick}
			>
				<div className={styles.deleteConfirmPopup}>
					<div className={styles.header}>
						<h1>
							You're about to delete the {currLanguage} ({currRow?.languageCode}
							) locale
						</h1>
					</div>
					<hr />
					<div className={styles.content}>
						<p>
							This will break any API clients that rely on{" "}
							{currRow?.languageCode} existing.
						</p>
						<p>
							<b>
								Please note that this action is permanent and you cannot undo
								it.
							</b>
						</p>
						<div className={styles.inputValue}>
							<TextField
								label="Please type the locale code below to confirm this change:"
								placeholder="Please type the old locale code"
								onChange={(e) => {
									setLocalesCode(e.target.value)
								}}
								value={localesCode}
							/>
						</div>
						<div className={styles.buttonGroup}>
							<button
								className={styles.cancelButton}
								onClick={() => setIsDeletePopupOpen(false)}
							>
								Don't delete
							</button>
							<button
								className={
									currRow?.languageCode === localesCode
										? styles.confirmButton
										: `${styles.confirmButton} ${styles.disabled}`
								}
								onClick={() => setisDeleteConfirmed(true)}
								disabled={currRow?.languageCode === localesCode ? false : true}
							>
								Delete
							</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	)
}

export default LocalesConfirmPopup
