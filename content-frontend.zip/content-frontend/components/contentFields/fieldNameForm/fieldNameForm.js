import { useMemo, useEffect } from "react";
import cn from "classnames";
import styles from "./fieldNameForm.module.scss";
import { Checkbox, Radio, TextField } from "@/components/theme/form-inputs";
import { Button } from "@/components/theme/buttons";
import { Alert } from "@/components/theme/alerts";
import { FormProvider, useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { camelCase } from "lodash";

const schema = yup.object().shape({
  name: yup
    .string()
    .required("Name is required")
    .max(50, "Name must be at most 50 characters"),
  api_identifier: yup
    .string()
    .required("API identifier is required")
    .max(64, "API Identifier must be at most 64 characters"),
  count: yup.string().max(500, "Description must be at most 500 characters"),
});

const TYPES = {
  NUMBER: [
    {
      label: "Integer",
      description: "1, 2, 3, 4, 5, 8, 13, ...",
      checked: true,
      value: "INTEGER",
    },
    {
      label: "Decimal",
      description: "3.146658989",
      value: "DECIMAL",
    },
  ],
  REFERENCE: [
    {
      label: "One reference",
      description:
        "For example, a blog post can reference its only one author.",
      checked: true,
      value: "ONE",
    },
    {
      label: "Many references",
      description:
        "For example, a blog post can reference its severl authors. API response will include a separate block for each child",
      value: "MANY",
    },
  ],
  MEDIA: [
    {
      label: "One file",
      description: "For example, a single photo.",
      checked: true,
      value: "ONE",
    },
    {
      label: "Many files",
      description:
        "For example, severl photos. API response will include a separate block for each child",
      value: "MANY",
    },
  ],
};

const FieldNameForm = ({
  onNext = () => {},
  onPrevious = () => {},
  field = {},
}) => {
  const types = useMemo(() => {
    return TYPES[field.fieldType] ?? [];
  }, [field.fieldType]);

  const defaultValues = useMemo(() => {
    return {
      name: "",
      api_identifier: "",
      ...(field.fieldType === "NUMBER" ? { type: "INTEGER" } : {}),
      ...(field.fieldType === "REFERENCE" ? { type: "ONE" } : {}),
      ...(field.fieldType === "MEDIA" ? { type: "ONE" } : {}),
    };
  }, [field.fieldType]);
  const methods = useForm({
    defaultValues,
    mode: "onChange",
    resolver: yupResolver(schema),
  });
  const {
    reset,
    setValue,
    handleSubmit,
    control,
    formState: { errors, touchedFields },
  } = methods;

  useEffect(() => {
    reset(defaultValues);
  }, [reset, defaultValues]);

  const onSubmit = async (values) => {
    console.log("🚀 ~ onSubmit ~ values:", values);
    try {
      onNext(values);
    } catch (err) {
      console.log("error: ", err);
    } finally {
    }
  };

  return (
    <FormProvider {...methods}>
      <form className={styles.form} onSubmit={handleSubmit(onSubmit)}>
        <div
          className={cn(styles.container, {
            [styles["layout-2-cols"]]: Boolean(types.length),
          })}
        >
          <Controller
            name="name"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                label="Name"
                required
                hint="Appears in entry editor"
                maxLength={50}
                error={errors?.name?.message}
                onChange={(e) => {
                  if (!touchedFields.api_identifier) {
                    setValue("api_identifier", camelCase(e.target.value), {
                      shouldValidate: true,
                    });
                  }
                  setValue("name", e.target.value, {
                    shouldDirty: true,
                    shouldValidate: true,
                    shouldTouch: true,
                  });
                }}
              />
            )}
          />
          <Controller
            name="api_identifier"
            control={control}
            render={({ field }) => (
              <TextField
                {...field}
                label="Field ID"
                required
                hint="Appears in API responses"
                maxLength={64}
                error={errors?.api_identifier?.message}
              />
            )}
          />

          {Boolean(types.length) && (
            <>
              <div className="text-body2 font-weight-semi-bold col-span-all">
                Type
              </div>
              {types.map((type) => (
                <Controller
                  key={`type-${type.value}`}
                  name="type"
                  control={control}
                  render={({ field }) => (
                    <Radio
                      {...field}
                      label={type.label}
                      hint={type.description}
                      id={`type-${type.value}`}
                      value={type.value}
                      checked={field.value === type.value}
                    />
                  )}
                />
              ))}
            </>
          )}

          {field.canArray && (
            <Controller
              name="list"
              control={control}
              render={({ field }) => {
                return (
                  <Checkbox
                    {...field}
                    id="ch_list"
                    className="col-span-all"
                    label="List"
                    hint="Select this if there is more than one value to store, like several names or a list of ingredients. API response will include a separate block for each field."
                    checked={field.value}
                  />
                );
              }}
            />
          )}

          <Alert
            text="These settings can't be changed later."
            className="col-span-all mt-5"
          />

          <div className={styles.actions}>
            <Button
              text="Change field type"
              variant="default"
              size="md"
              onClick={onPrevious}
            />
            <Button
              disabled={
                Boolean(errors?.api_identifier?.message) ||
                Boolean(errors?.name?.message)
              }
              text="Add and configure"
              size="md"
              type="submit"
            />
          </div>
        </div>
      </form>
    </FormProvider>
  );
};

export default FieldNameForm;
