import React, { useState, useEffect } from "react";
import DropdownField from "@/components/shared/dropdownfield/dropdownfield";
import { TextField } from "@/components/theme/form-inputs";
import styles from "./acceptSpecificFileSize.module.scss";

const AcceptSpecificFileSize = ({
  minValue,
  setMinValue,
  maxValue,
  setMaxValue,
  selectedLimitCharacter,
  setSelectedLimitCharacter,
  minSizeType,
  setMinSizeType,
  maxSizeType,
  setMaxSizeType,
  existValues,
}) => {
  // const [selectedLimitCharacter, setSelectedLimitCharacter] =
  //   useState("between");
  // const [minValue, setMinValue] = useState("Min");
  // const [minSizeType, setMinSizeType] = useState("");
  // const [maxValue, setMaxValue] = useState("Max");
  // const [maxSizeType, setMaxSizeType] = useState("");
  const SELETE_LIMIT_CHARACTER = [
    {
      id: 1,
      children: [
        { id: 1, title: "Between", value: "BETWEEN" },
        { id: 2, title: "At Least", value: "ATLEAST" },
        { id: 3, title: "Not More Than", value: "NOT_MORE_THAN" },
      ],
    },
  ];

  const SELECT_FILE_SIZE = [
    {
      id: 1,
      children: [
        { id: 1, title: "Bytes", value: "bytes" },
        { id: 2, title: "KB", value: "kb" },
        { id: 3, title: "MB", value: "mb" },
      ],
    },
  ];

  useEffect(() => {
    setMinSizeType(SELECT_FILE_SIZE[0].children[0]);
    setMaxSizeType(SELECT_FILE_SIZE[0].children[0]);

    if (existValues?.assetLimitValidation) {
      const title = existValues?.assetLimitValidation?.limitType;
      setSelectedLimitCharacter({
        value: existValues?.assetLimitValidation?.limitType,
        title:
          title === "BETWEEN"
            ? "Between"
            : title === "ATLEAST"
              ? "At Least"
              : title === "NOT_MORE_THAN"
                ? "Not More Than"
                : "Between",
      });
      setMinValue(existValues?.assetLimitValidation?.minimum);
      setMaxValue(existValues?.assetLimitValidation?.maximum);
      setMinSizeType(existValues?.assetLimitValidation?.minSizeType);
      setMaxSizeType(existValues?.assetLimitValidation?.maxSizeType);
    }
  }, []);

  return (
    <div className={styles.wrapper_fileSize}>
      <div className={styles.dropdown}>
        <DropdownField
          data={SELETE_LIMIT_CHARACTER}
          selectedvalue={selectedLimitCharacter}
          setSelectedValue={setSelectedLimitCharacter}
        />
      </div>

      {selectedLimitCharacter?.value === "ATLEAST" ? (
        <>
          <div className={styles?.container}>
            <div className={styles?.minWrapper}>
              <div>
                <TextField
                  value={minValue}
                  type="number"
                  onChange={(e) => setMinValue(e.target.value)}
                  placeholder="Min"
                />
              </div>
              <div className={styles?.min_dropdown}>
                <DropdownField
                  data={SELECT_FILE_SIZE}
                  selectedvalue={minSizeType}
                  setSelectedValue={setMinSizeType}
                />
              </div>
            </div>
          </div>
        </>
      ) : selectedLimitCharacter?.value === "NOT_MORE_THAN" ? (
        <>
          <div className={styles?.container}>
            <div className={styles?.maxWrapper}>
              <div>
                <TextField
                  value={maxValue}
                  type="number"
                  onChange={(e) => setMaxValue(e.target.value)}
                  placeholder="Max"
                />
              </div>
              <div className={styles?.max_dropdown}>
                <DropdownField
                  data={SELECT_FILE_SIZE}
                  selectedvalue={minSizeType}
                  setSelectedValue={setMinSizeType}
                />
              </div>
            </div>
          </div>
        </>
      ) : (
        <>
          <div className={styles?.container}>
            <div className={styles?.minWrapper}>
              <div>
                <TextField
                  value={minValue}
                  type="number"
                  onChange={(e) => setMinValue(e.target.value)}
                  placeholder="Min"
                />
              </div>
              <div className={styles?.min_dropdown}>
                <DropdownField
                  data={SELECT_FILE_SIZE}
                  selectedvalue={minSizeType}
                  setSelectedValue={setMinSizeType}
                />
              </div>
            </div>
            <div>
              <p>and</p>
            </div>
            <div className={styles?.maxWrapper}>
              <div>
                <TextField
                  value={maxValue}
                  type="number"
                  onChange={(e) => setMaxValue(e.target.value)}
                  placeholder="Max"
                />
              </div>
              <div className={styles?.max_dropdown}>
                <DropdownField
                  data={SELECT_FILE_SIZE}
                  selectedvalue={maxSizeType}
                  setSelectedValue={setMaxSizeType}
                />
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default AcceptSpecificFileSize;
