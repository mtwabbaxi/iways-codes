import React, { useState } from "react";
import DropdownField from "@/components/shared/dropdownfield/dropdownfield";
import { TextField } from "@/components/theme/form-inputs";
import styles from "./limitCharacterCount.module.scss";
import { useEffect } from "react";

const LimitCharacterCount = ({
  minValue,
  setMinValue,
  maxValue,
  setMaxValue,
  selectedLimitCharacter,
  setSelectedLimitCharacter,
  existValues,
}) => {
  // const [selectedLimitCharacter, setSelectedLimitCharacter] =
  //   useState("between");
  // const [minValue, setMinValue] = useState("Min");
  // const [maxValue, setMaxValue] = useState("Max");

  useEffect(() => {
    if (existValues?.jsonLimitValidation) {
      const title = existValues?.jsonLimitValidation?.limitType.toLowerCase();
      setSelectedLimitCharacter({
        value: existValues?.jsonLimitValidation?.limitType.toLowerCase(),
        title:
          title === "between"
            ? "Between"
            : title === "min"
              ? "At Least"
              : title === "max"
                ? "Not More Than"
                : "Between",
      });
      setMinValue(existValues?.jsonLimitValidation?.minimum);
      setMaxValue(existValues?.jsonLimitValidation?.maximum);
    }

    if (existValues?.limitNumberValidation) {
      const title = existValues?.limitNumberValidation?.limitType.toLowerCase();
      setSelectedLimitCharacter({
        value: existValues?.limitNumberValidation?.limitType.toLowerCase(),
        title:
          title === "between"
            ? "Between"
            : title === "min"
              ? "At Least"
              : title === "max"
                ? "Not More Than"
                : "Between",
      });
      setMinValue(existValues?.limitNumberValidation?.minimum);
      setMaxValue(existValues?.limitNumberValidation?.maximum);
    }

    if (existValues?.characterLimitValidation) {
      const title =
        existValues?.characterLimitValidation?.limitType.toLowerCase();
      setSelectedLimitCharacter({
        value: existValues?.characterLimitValidation?.limitType.toLowerCase(),
        title:
          title === "between"
            ? "Between"
            : title === "min"
              ? "At Least"
              : title === "max"
                ? "Not More Than"
                : "Between",
      });
      setMinValue(existValues?.characterLimitValidation?.minimum);
      setMaxValue(existValues?.characterLimitValidation?.maximum);
    }
  }, []);

  const SELETE_LIMIT_CHARACTER = [
    {
      id: 1,
      children: [
        { id: 1, title: "Between", value: "between" },
        { id: 2, title: "At Least", value: "min" },
        { id: 3, title: "Not More Than", value: "max" },
      ],
    },
  ];

  return (
    <div
      className={
        selectedLimitCharacter?.value === "between"
          ? styles.wrapper_limitCount
          : selectedLimitCharacter?.value === "min"
            ? styles.wrapper_min_limitCount
            : selectedLimitCharacter?.value === "max"
              ? styles.wrapper_max_limitCount
              : styles.wrapper_limitCount
      }
    >
      <div className={styles.dropdown}>
        <DropdownField
          data={SELETE_LIMIT_CHARACTER}
          selectedvalue={selectedLimitCharacter}
          setSelectedValue={setSelectedLimitCharacter}
        />
      </div>

      {selectedLimitCharacter?.value === "min" ? (
        <>
          <div>
            <TextField
              value={minValue}
              type="number"
              onChange={(e) => setMinValue(e.target.value)}
              placeholder="Min"
            />
          </div>
        </>
      ) : selectedLimitCharacter?.value === "max" ? (
        <>
          <div>
            <TextField
              value={maxValue}
              type="number"
              onChange={(e) => setMaxValue(e.target.value)}
              placeholder="Max"
            />
          </div>
        </>
      ) : (
        <>
          <div>
            <TextField
              value={minValue}
              type="number"
              onChange={(e) => setMinValue(e.target.value)}
              placeholder="Min"
            />
          </div>
          <div>
            <p>and</p>
          </div>

          <div>
            <TextField
              value={maxValue}
              type="number"
              onChange={(e) => setMaxValue(e.target.value)}
              placeholder="Max"
            />
          </div>
        </>
      )}
    </div>
  );
};

export default LimitCharacterCount;
