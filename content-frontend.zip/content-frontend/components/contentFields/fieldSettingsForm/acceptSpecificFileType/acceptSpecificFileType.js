import { useState, useEffect } from "react";
import styles from "./acceptSpecificFileType.module.scss";
import { AiOutlineUp, AiOutlineDown } from "react-icons/ai";

const AcceptSpecificFileType = ({
  data,
  selectedValues,
  setSelectedValues,
  existValues,
}) => {
  if (!data) {
    return false;
  }

  const onChangeHandler = (selectedOption) => {
    const updatedValues = [...selectedValues];

    if (updatedValues.includes(selectedOption)) {
      updatedValues.splice(updatedValues.indexOf(selectedOption), 1);
    } else {
      updatedValues.push(selectedOption);
    }

    setSelectedValues(updatedValues);
  };

  useEffect(() => {
    if (Boolean(existValues?.specifiedMediaFileType?.mediaTypes?.length)) {
      setSelectedValues(existValues?.specifiedMediaFileType?.mediaTypes);
    }
  }, []);

  return (
    <>
      <div className={styles.container}>
        <div className={styles.wrapper}>
          <div className={styles.checkboxContainer}>
            {data?.map((group, groupIndex) => (
              <div key={groupIndex} className={styles.groupContainer}>
                {group?.options?.map((option, optionIndex) => (
                  <div key={optionIndex} className={styles.checkboxOption}>
                    <input
                      type="checkbox"
                      id={option?.id}
                      value={option?.value}
                      checked={selectedValues.includes(option?.value)}
                      onChange={() => onChangeHandler(option?.value)}
                    />
                    <label htmlFor={option?.id}>{option?.label}</label>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default AcceptSpecificFileType;
