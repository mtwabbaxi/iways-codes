import { FcInfo } from "react-icons/fc";
import styles from "../fieldSettingsForm.module.scss";
import { Controller, useFormContext } from "react-hook-form";
import { IoClose } from "react-icons/io5";
import RadioItem from "../radioItem";
import { TextField } from "@/components/theme/form-inputs";
import cn from "classnames";
import { getLocaleByCode } from "@/utils/constants";

export default function BooleanValidationsElm({
  showDefaultMessage,
  setShowDefaultMessage = () => {},
  errors,
  id,
  localized,
  allLocales = () => {},
  showOnlyLocaleLabel = false,
}) {
  const { control, watch } = useFormContext();
  const formCurrentValues = watch();

  return (
    <div className={styles["default-value-container"]}>
      <div
        id={id}
        className={cn(
          styles["field-heading"],
          "field-heading",
          "font-weight-semi-bold",
          "mb-5"
        )}
      >
        Default Values
      </div>
      {showDefaultMessage && (
        <div className={styles["default-content"]}>
          <FcInfo className={styles["info-icon"]} />
          <p className={styles.message}>
            This setting allows you to set a default value for this field, which
            will be automatically inserted to new content entries. It can help
            editors avoid content entry altogether, or just give them a helpful
            prompt for how to structure their content.
          </p>
          <IoClose
            onClick={() => setShowDefaultMessage(false)}
            className={styles.close}
          />
        </div>
      )}
      {localized ? (
        <>
          {allLocales?.content.map((item) => {
            return (
              <Controller
                name={
                  item.languageCode === "en-US"
                    ? "default_value"
                    : `default_value - ${item.languageCode}`
                }
                control={control}
                render={({ field }) => (
                  <RadioItem
                    {...field}
                    value={
                      formCurrentValues?.[
                        item.languageCode === "en-US"
                          ? "default_value"
                          : `default_value - ${item.languageCode}`
                      ]
                    }
                    label={item?.languageCode}
                    localized
                    className="mb-3 mt-2"
                    trueConditionLabel={
                      formCurrentValues?.true_custom_label
                        ? formCurrentValues?.true_custom_label
                        : "Yes"
                    }
                    falseConditionLabel={
                      formCurrentValues?.false_custom_label
                        ? formCurrentValues?.false_custom_label
                        : "No"
                    }
                    language={getLocaleByCode(item?.languageCode)}
                    showOnlyLocaleLabel={showOnlyLocaleLabel}
                  />
                )}
              />
            );
          })}
        </>
      ) : (
        <Controller
          name="default_value"
          control={control}
          render={({ field }) => (
            <RadioItem
              {...field}
              value={formCurrentValues?.default_value}
              className="mb-3 mt-2"
              trueConditionLabel={
                formCurrentValues?.true_custom_label
                  ? formCurrentValues?.true_custom_label
                  : "Yes"
              }
              falseConditionLabel={
                formCurrentValues?.false_custom_label
                  ? formCurrentValues?.false_custom_label
                  : "No"
              }
            />
          )}
        />
      )}

      <Controller
        name="true_custom_label"
        control={control}
        render={({ field }) => (
          <TextField
            {...field}
            label="True condition custom label"
            maxLength={50}
            error={errors?.true_custom_label?.message}
          />
        )}
      />
      <Controller
        name="false_custom_label"
        control={control}
        render={({ field }) => (
          <TextField
            {...field}
            label="False condition custom label"
            maxLength={50}
            error={errors?.false_custom_label?.message}
          />
        )}
      />
    </div>
  );
}
