"use client";

import { useMemo, useEffect, useState } from "react";
import styles from "./fieldSettingsForm.module.scss";
import { TextField, Checkbox } from "@/components/theme/form-inputs";
import { FormProvider, useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { camelCase } from "lodash";
import { Alert } from "@/components/theme/alerts";
import { Divider } from "@/components/theme/misc";
import RadioItem from "./radioItem";
import { Button } from "@/components/theme/buttons";
import {
  addField,
  createContentModel,
  getContentModelById,
  updateField,
} from "@/store/actions/contentModel";
import { useDispatch, useSelector } from "react-redux";
import { useToast } from "@/context/toastContext";
import { useParams, useRouter } from "next/navigation";
import SpecifiedEntry from "./specifiedEntry";
import { bool } from "yup";
import AppearanceDateTime from "./appearanceDateTime";
import cn from "classnames";
import { FcInfo } from "react-icons/fc";
import { IoClose, IoRemoveSharp } from "react-icons/io5";
import CustomDateField from "@/components/shared/dateField";
import BooleanValidationsElm from "./BooleanValidationElm";
import {
  APP_URLS,
  formatOptions,
  getLocaleByCode,
  replaceUrlParams,
  timeModeOptions,
} from "@/utils/constants";
import {
  AiOutlineUnderline,
  AiOutlineItalic,
  AiOutlineUnorderedList,
  AiOutlineOrderedList,
  AiOutlineClose,
} from "react-icons/ai";
import { IoIosCode } from "react-icons/io";
import {
  MdSuperscript,
  MdOutlineSubscript,
  MdOutlineImage,
} from "react-icons/md";
import { FaQuoteRight } from "react-icons/fa6";
import { FaTable } from "react-icons/fa";
import { RxExternalLink } from "react-icons/rx";
import { PiCirclesThreeFill } from "react-icons/pi";
import { LuSlidersHorizontal } from "react-icons/lu";
import { RiBarChartHorizontalLine } from "react-icons/ri";
import LimitCharacterCount from "./limitCharacterCount";
import MultiDropdownFields from "@/components/shared/multiDropdownfields/multiDropdownfields";
import DropdownField from "@/components/shared/dropdownfield/dropdownfield";
import Link from "next/link";
import AcceptSpecificFileSize from "./acceptSpecificFileSize";
import AcceptSpecificFileType from "./acceptSpecificFileType/acceptSpecificFileType";
import AcceptSpecificImageDimension from "./acceptSpecificImageDimension/acceptSpecificImageDimension";
import AcceptSpecificDateRange from "./acceptSpecificDateRange/acceptSpecificDateRange";
import { fetchAllLocales } from "@/store/actions/locales";
import { all } from "axios";

const FieldSettingsForm = ({
  formData = {},
  editMode,
  onClose = () => {},
  onAddEditOrUpdate = () => {},
}) => {
  useEffect(() => {
    dispatch(fetchAllLocales(spaceId, spaceEnvironmentId));
  }, []);
  const { allLocales } = useSelector((state) => state.locales);
  const SETTINGS = {
    heading: "Settings",
    values_options: [
      {
        heading: "Field options",
        options: [
          ...(formData?.field?.fieldType === "TEXT"
            ? [
                {
                  name: "entryTitle",
                  value: "entryTitle",
                  label: "This field represents the Entry title",
                  hint: "",
                },
              ]
            : []),
          {
            name: "localized",
            value: "localized",
            label: "Enable localization of this field",
            hint: "All the content can be translated to English (United States)",
          },
        ],
      },
      ...(formData?.field?.fieldType === "RICH_TEXT"
        ? [
            {
              heading: "Formatting",
              options: [
                {
                  name: "formatting",
                  value: [
                    "H1",
                    "H2",
                    "H3",
                    "H4",
                    "H5",
                    "H6",
                    "B",
                    <AiOutlineItalic />,
                    <AiOutlineUnderline />,
                    <IoIosCode />,
                    <MdSuperscript />,
                    <MdOutlineSubscript />,
                    <AiOutlineUnorderedList />,
                    <AiOutlineOrderedList />,
                    <FaQuoteRight />,
                    <IoRemoveSharp />,
                    <FaTable />,
                  ],
                },
              ],
            },
            {
              heading: "Allow hyperlinks",
              options: [
                {
                  name: "allow_hyperlinks",
                  value: [
                    <span>
                      <RxExternalLink /> Link to URL
                    </span>,
                    <span>
                      <PiCirclesThreeFill /> Link to entry
                    </span>,
                    <span>
                      <MdOutlineImage /> Link to asset
                    </span>,
                  ],
                },
              ],
            },
            {
              heading: "Allow embedded entries & assets",
              options: [
                {
                  name: "allow_embedded_entries_assets",
                  value: [
                    <span>
                      <LuSlidersHorizontal /> Entry
                    </span>,
                    <span>
                      <RiBarChartHorizontalLine /> Inline entry
                    </span>,
                    <span>
                      <MdOutlineImage /> Asset
                    </span>,
                  ],
                },
              ],
            },
          ]
        : []),
    ],
  };
  const { savedModelData = {}, data } =
    useSelector((state) => state.contentModel) || {};

  const VALIDATIONS = {
    heading: "Validation",
    values_options: [
      ...(formData?.field?.fieldType !== "RICH_TEXT"
        ? [
            {
              options: [
                ...(formData?.field?.fieldType !== "LOCATION" &&
                formData?.field?.fieldType !== "BOOLEAN"
                  ? [
                      ...(formData?.field?.fieldType !== "DATETIME"
                        ? [
                            ...(formData?.field?.fieldType !== "MEDIA"
                              ? [
                                  ...(formData?.field?.fieldType !== "JSON"
                                    ? [
                                        ...(formData?.field?.fieldType !==
                                        "REFERENCE"
                                          ? [
                                              {
                                                name: "required",
                                                value: "required",
                                                label: "Required field",
                                                hint: "You won't be able to publish an entry if this field is empty",
                                              },

                                              {
                                                name: "unique",
                                                value: "unique",
                                                label: "Unique field",
                                                hint: "You won't be able to publish an entry if there is an existing entry with identical content",
                                              },
                                              ...(formData?.field?.fieldType !==
                                              "TEXT"
                                                ? [
                                                    {
                                                      name: "accept_specified_number_range",
                                                      value:
                                                        "accept_specified_number_range",
                                                      label:
                                                        "Accept only specified number range",
                                                      hint: "Specify a minimum and/or maximum allowed number for this field",
                                                    },
                                                    {
                                                      name: "acceptOnlySpecificValues_number",
                                                      value:
                                                        "acceptOnlySpecificValues_number",
                                                      label:
                                                        "Accept only specified values",
                                                      hint: "You won't be able to publish an entry if the field value is not in the list of specified values",
                                                    },
                                                  ]
                                                : [
                                                    {
                                                      name: "limitCharacterCount_text",
                                                      value:
                                                        "limitCharacterCount_text",
                                                      label:
                                                        "Limit character count",
                                                      hint: "Specify a minimum and/or maximum allowed number of characters",
                                                    },
                                                    {
                                                      name: "matchSpecificPattern",
                                                      value:
                                                        "matchSpecificPattern",
                                                      label:
                                                        "Match a specific pattern",
                                                      hint: "Make this field match a pattern: e-mail address, URI, or a custom regular expression",
                                                    },
                                                    {
                                                      name: "prohibitSpecificPattern",
                                                      value:
                                                        "prohibitSpecificPattern",
                                                      label:
                                                        "Prohibit a specific pattern",
                                                      hint: "Make this field invalid when a pattern is matched: custom regular expression (e.g. bad word list)",
                                                    },
                                                    {
                                                      name: "acceptOnlySpecificValues_text",
                                                      value:
                                                        "acceptOnlySpecificValues_text",
                                                      label:
                                                        "Accept only specified values",
                                                      hint: "You won't be able to publish an entry if the field value is not in the list of specified values",
                                                    },
                                                  ]),
                                            ]
                                          : [
                                              {
                                                name: "required",
                                                value: "required",
                                                label: "Required field",
                                                hint: "You won't be able to publish an entry if this field is empty",
                                              },
                                              {
                                                name: "acceptSpecifiedEntryType_reference",
                                                value:
                                                  "acceptSpecifiedEntryType_reference",
                                                label:
                                                  "Accept only specified entry type",
                                                hint: "Make this field only accept entries from specified content type(s)",
                                                dropDownValues: [
                                                  "H1",
                                                  "H2",
                                                  "H3",
                                                  "H4",
                                                  "H5",
                                                  "H6",
                                                ],
                                              },
                                            ]),
                                      ]
                                    : [
                                        {
                                          name: "required",
                                          value: "required",
                                          label: "Required field",
                                          hint: "You won't be able to publish an entry if this field is empty",
                                        },
                                        {
                                          name: "limitNumberOfProperties",
                                          value: "limitNumberOfProperties",
                                          label: "Limit number of properties",
                                          hint: "Specify a minimum and/or maximum allowed number of properties",
                                        },
                                      ]),
                                ]
                              : [
                                  {
                                    name: "required",
                                    value: "required",
                                    label: "Required field",
                                    hint: "You won't be able to publish an entry if this field is empty",
                                  },
                                  {
                                    name: "acceptSpecificFileSize",
                                    value: "acceptSpecificFileSize",
                                    label: "Accept only specified file size",
                                    hint: "Specify a minimum and/or maximum allowed file size",
                                  },
                                  {
                                    name: "acceptSpecifiedFileType",
                                    value: "acceptSpecifiedFileType",
                                    label: "Accept only specified file types",
                                    hint: "Make this field only accept specified file types",
                                  },
                                  {
                                    name: "acceptSpecifiedImageDimension",
                                    value: "acceptSpecifiedImageDimension",
                                    label:
                                      "Accept only specified image dimensions",
                                    hint: "Specify a minimum and/or maximum allowed image dimension",
                                  },
                                ]),
                          ]
                        : [
                            {
                              name: "required",
                              value: "required",
                              label: "Required field",
                              hint: "You won't be able to publish an entry if this field is empty",
                            },
                            {
                              name: "acceptSpecificDateRange",
                              value: "acceptSpecificDateRange",
                              label: "Accept only specified date range",
                              hint: "Specify an early and/or latest allowed date for this field",
                            },
                          ]),
                    ]
                  : [
                      {
                        name: "required",
                        value: "required",
                        label: "Required field",
                        hint: "You won't be able to publish an entry if this field is empty",
                      },
                    ]),
              ],
            },
          ]
        : [
            {
              heading: "General validations",
              options: [
                {
                  name: "required",
                  value: "required",
                  label: "Required field",
                  hint: "You won't be able to publish an entry if this field is empty",
                },
                ...(formData?.field?.fieldType !== "RICH_TEXT"
                  ? [
                      {
                        name: "unique",
                        value: "unique",
                        label: "Unique field",
                        hint: "You won't be able to publish an entry if there is an existing entry with identical content",
                      },
                    ]
                  : []),

                {
                  name: "limitCharacterCount",
                  value: "limitCharacterCount",
                  label: "Limit character count",
                  hint: "Specify a minimum and/or maximum allowed number of characters",
                },
              ],
            },
            {
              heading: "Link to enty",
              options: [
                {
                  name: "numberLimit_enty",
                  value: "numberLimit_enty",
                  label: "Limit number of entries",
                  hint: "Specify a minimum and/or maximum allowed number of entries",
                },
                {
                  name: "accept_specified_entryType",
                  value: "accept_specified_entryType",
                  label: "Accept only specified entry type",
                  hint: "Make this link type only accept entries from specified content type(s)",
                },
              ],
            },
            {
              heading: "Link to asset",
              options: [
                {
                  name: "numberLimit_link",
                  value: "numberLimit_link",
                  label: "Limit number of entries",
                  hint: "Specify a minimum and/or maximum allowed number of entries",
                },
              ],
            },
            {
              heading: "Embedded block entry",
              options: [
                {
                  name: "numberLimit_block",
                  value: "numberLimit_block",
                  label: "Limit number of entries",
                  hint: "Specify a minimum and/or maximum allowed number of entries",
                },
                {
                  name: "acceptSpecifiedEntryType",
                  value: "acceptSpecifiedEntryType",
                  label: "Accept only specified entry type",
                  hint: "Make this link type only accept entries from specified content type(s)",
                  dropDownValues: ["H1", "H2", "H3", "H4", "H5", "H6"],
                },
              ],
            },
            {
              heading: "Embedded inline entry",
              options: [
                {
                  name: "numberLimit_inline",
                  value: "numberLimit_inline",
                  label: "Limit number of entries",
                  hint: "Specify a minimum and/or maximum allowed number of entries",
                },
                {
                  name: "acceptOnlySpecifiedEntryType",
                  value: "acceptOnlySpecifiedEntryType",
                  label: "Accept only specified entry type",
                  hint: "Make this link type only accept entries from specified content type(s)",
                },
              ],
            },
            {
              heading: "Embedded asset",
              options: [
                {
                  name: "numberLimit_asset",
                  value: "numberLimit_asset",
                  label: "Limit number of entries",
                  hint: "Specify a minimum and/or maximum allowed number of entries",
                },
              ],
            },
          ]),
    ],
  };

  const REF_SETTINGS = [
    {
      name: "create_new_entries",
      trueConditionLabel: "Yes",
      falseConditionLabel: "No",
      label: 'Show "Create new entries"',
      hint: "When enabled, people can create and link new entries (based on user permissions)",
    },
    {
      name: "link_existing_entries",
      trueConditionLabel: "Yes",
      falseConditionLabel: "No",
      label: 'Show "Link existing entries"',
      hint: "When enabled, people can link existing entries (based on user permissions)",
    },
  ];

  const SELETE_SPECIFIC_PATTERN = [
    {
      id: 1,
      children: [
        { id: 1, title: "Custom", value: "foo|bar[baz]" },
        { id: 2, title: "E-Mail", value: "^\\w[\\w.-]*@([\\w-]+\\.)+[\\w-]+$" },
        {
          id: 3,
          title: "URL",
          value:
            "^(ftp|http|https):\\/\\/(\\w+:{0,1}\\w*@)?(\\S+)(:[0-9]+)?(\\/|\\/([\\w#!:.?+=&%@!\\/-]))?$",
        },
        {
          id: 4,
          title: "Date (US)",
          value:
            "^(0?[1-9]|1[012])[- /.](0?[1-9]|[12][0-9]|3[01])[- /.](19|20)?\\d\\d$",
        },
        {
          id: 5,
          title: "Date (European)",
          value:
            "^(0?[1-9]|[12][0-9]|3[01])[- /.](0?[1-9]|1[012])[- /.](19|20)?\\d\\d$",
        },
        {
          id: 6,
          title: "12h Time",
          value: "^(0?[1-9]|1[012]):[0-5][0-9](:[0-5][0-9])?\\s*[aApP][mM]$",
        },
        {
          id: 7,
          title: "24h Time",
          value: "^(0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9])?$",
        },
        {
          id: 8,
          title: "US phone number",
          value:
            "^\\d[ -.]?\\(?\\d\\d\\d\\)?[ -.]?\\d\\d\\d[ -.]?\\d\\d\\d\\d$",
        },
        { id: 9, title: "US zip code", value: "^\\d{5}$|^\\d{5}-\\d{4}$}" },
      ],
    },
  ];

  const SELETE_FILE_TYPE = [
    {
      heading: "General validations",
      options: [
        {
          id: 1,
          value: "attachment",
          label: "Attachment",
        },
        {
          id: 2,
          value: "plain_text",
          label: "Plain text",
        },
        {
          id: 3,
          value: "image/jpeg",
          label: "Image",
        },
        {
          id: 4,
          value: "audio",
          label: "Audio",
        },
        {
          id: 5,
          value: "video",
          label: "Video",
        },
        {
          id: 6,
          value: "rich_text",
          label: "Rich text",
        },
        {
          id: 7,
          value: "presentation",
          label: "Presentation",
        },
        {
          id: 8,
          value: "spreadsheet",
          label: "Spreadsheet",
        },
        {
          id: 9,
          value: "pdf_document",
          label: "PDF Document",
        },
        {
          id: 10,
          value: "archive",
          label: "Archive",
        },
        {
          id: 11,
          value: "code",
          label: "Code",
        },
        {
          id: 12,
          value: "markup",
          label: "Markup",
        },
      ],
    },
  ];

  const JSON_DATA = [SETTINGS, VALIDATIONS];

  const getSchemaForDefaultValueField = useMemo(() => {
    if (
      formData.field.fieldType === "TEXT" ||
      formData.field.fieldType === "DATETIME" ||
      formData.field.fieldType === "NUMBER"
    ) {
      return yup
        .string()
        .max(
          256,
          "Please shorten the text so it's no longer than 256 characters"
        );
    }
  }, [formData]);

  const schema = yup.object().shape({
    name: yup
      .string()
      .required("Name is required")
      .max(50, "Name must be at most 50 characters"),
    api_identifier: yup
      .string()
      .required("API identifier is required")
      .max(64, "API Identifier must be at most 64 characters"),
    default_value: getSchemaForDefaultValueField,

    count: yup.string().max(500, "Description must be at most 500 characters"),
    ...(formData?.field?.fieldType === "DATETIME"
      ? {
          format: yup
            .string()
            .test("greaterThanZero", "Format is required", (value) =>
              value ? parseInt(value, 10) > 0 : false
            ),
          time_mode: yup
            .string()
            .test("greaterThanZero", "Time mode is required", (value) =>
              value ? parseInt(value, 10) > 0 : false
            ),
          utcFormat: yup.string(),
          timeInput: yup.string(),
          details: yup.mixed(),
          date: yup.string(),
        }
      : {}),
  });

  const haveDefaultValue = useMemo(() => {
    return (
      formData.field.fieldType === "TEXT" ||
      formData.field.fieldType === "NUMBER" ||
      formData.field.fieldType === "DATETIME"
    );
  }, [formData.field.fieldType]);

  const defaultValues = useMemo(() => {
    return {
      ...(formData?.field?.fieldType === "TEXT"
        ? {
            entryTitle: formData?.field?.entryTitle,
          }
        : {}),
      name: formData?.name ?? "",
      api_identifier: formData?.api_identifier ?? "",
      default_value:
        formData?.field?.fieldType !== "BOOLEAN"
          ? formData?.field?.value || ""
          : typeof formData?.field?.value === "boolean"
            ? formData?.field?.value
            : "",
      count: "single",
      list: false,
      required: formData?.field?.required || false,
      unique: formData?.field?.unique || false,
      // error_message: "",
      localized: formData?.field?.localized || false,
      limitCharacterCount: formData?.field?.limitCharacterCount || false,
      numberLimit_link: formData?.field?.numberLimit_link || false,
      numberLimit_enty: formData?.field?.numberLimit_enty || false,
      numberLimit_block: formData?.field?.numberLimit_block || false,
      numberLimit_inline: formData?.field?.numberLimit_inline || false,
      numberLimit_asset: formData?.field?.numberLimit_asset || false,
      accept_specified_entryType:
        formData?.field?.accept_specified_entryType || false,
      acceptSpecifiedEntryType:
        formData?.field?.acceptSpecifiedEntryType || false,
      acceptOnlySpecifiedEntryType:
        formData?.field?.acceptOnlySpecifiedEntryType || false,
      matchSpecificPattern: formData?.field?.isMatchSpecificPattern || false,
      prohibitSpecificPattern:
        formData?.field?.isProhibitSpecificPattern || false,
      acceptOnlySpecificValues:
        formData?.field?.acceptOnlySpecificValues || false,
      acceptSpecificFileSize: formData?.field?.limitValidation || false,
      acceptSpecifiedFileType: formData?.field?.specifiedFileType || false,
      acceptSpecifiedImageDimension:
        formData?.field?.specifiedDimensions || false,
      acceptSpecificDateRange: formData?.field?.dateTimeValidation || false,
      limitNumberOfProperties: formData?.field?.limitValidation || false,
      acceptSpecifiedEntryType_reference:
        formData?.field?.validation?.isSpecifiedContentTypes || false,
      customText_entryType_reference:
        formData?.field?.validation?.specifiedValues?.customErrorMessage || "",
      customText_limitNumberProperties:
        formData?.field?.jsonLimitValidation?.customErrorMessage || "",
      customText_accept_specified_number_value:
        formData?.field?.integerNumber?.specifiedValues?.customErrorMessage ||
        formData?.field?.decimalNumber?.specifiedValues?.customErrorMessage ||
        "",
      accept_specified_number_range: formData?.field?.limitValidation,
      customText_accept_specified_number_range:
        formData?.field?.limitNumberValidation?.customErrorMessage || "",
      acceptOnlySpecificValues_number:
        formData?.field?.integerNumber?.isSpecifiedValues ||
        formData?.field?.decimalNumber?.isSpecifiedValues,
      acceptOnlySpecificValues_text: formData?.field?.isSpecifiedValues,
      customText_accept_specified_text_value:
        formData?.field?.specifiedValues?.customErrorMessage,
      limitCharacterCount_text: formData?.field?.characterLimit || false,
      customText_limitNumberCount_text:
        formData?.field?.characterLimitValidation?.customErrorMessage || "",
      flagtext: formData?.field?.matchSpecificPattern?.flags,
      customText_matchPattern:
        formData?.field?.matchSpecificPattern?.customErrorMessage,
      prohibittext:
        formData?.field?.matchProhibitSpecificPattern?.specifyPatternType,
      flagtext_prohibit: formData?.field?.matchProhibitSpecificPattern?.flags,
      customText_prohibit:
        formData?.field?.matchProhibitSpecificPattern?.customErrorMessage,
      customText_acceptSpecificFileSize:
        formData?.field?.assetLimitValidation?.customErrorMessage,
      customText_selectedFileType:
        formData?.field?.specifiedMediaFileType?.customErrorMessage,
      customText_acceptSpecifiedImageDimension:
        formData?.field?.specifiedDimensionsValues?.customErrorMessage,
      customText_datetime:
        formData?.field?.dateLimitValidation?.customErrorMessage,
      ...(formData?.field?.fieldType === "BOOLEAN"
        ? {
            true_custom_label: formData.field?.true_custom_label || "Yes",
            false_custom_label: formData.field?.false_custom_label || "No",
          }
        : {}),
      helpText: formData?.field?.helpText || "",
      ...(formData?.field?.fieldType === "DATETIME"
        ? {
            format:
              formData?.field?.details?.format?.id || formatOptions[2].id || {},
            time_mode:
              formData?.field?.details?.time_mode?.id ||
              timeModeOptions[1].id ||
              {},
            utcFormat: formData?.field?.details?.utcFormat || "",
            timeInput: formData?.field?.details?.timeInput || "",
            date: formData?.field?.details?.date || "",
          }
        : {}),
    };
  }, [formData]);

  const methods = useForm({
    defaultValues,
    mode: "onChange",
    resolver: yupResolver(schema),
  });
  const dispatch = useDispatch();
  const params = useParams();
  const router = useRouter();

  let {
    contentModelId,
    spaceId,
    spaceEnvironmentId,
    apiIdentifier = "",
  } = params;
  contentModelId = decodeURIComponent(contentModelId); // Cupiditate%20nisi%20dolo -> Cupiditate nisi dolo

  const { addToast } = useToast();
  const {
    setValue,
    reset,
    handleSubmit,
    control,
    watch,
    formState: { errors, touchedFields },
  } = methods;

  const { format, utcFormat, timeInput, time_mode, date, localized } = watch();

  const [enteries, setEnteries] = useState({ create: true, link: false });
  const [showDefaultMessage, setShowDefaultMessage] = useState(true);
  const [limitCharacterCountChecked, setLimitCharacterCountChecked] =
    useState(false);
  const [limitLinkNumberChecked, setLimitLinkNumberChecked] = useState(false);
  const [limitLinkEnryChecked, setLimitLinkEnryChecked] = useState(false);
  const [limitLinkBlockChecked, setLimitLinkBlockChecked] = useState(false);
  const [limitLinkInlineChecked, setLimitLinkInlineChecked] = useState(false);
  const [limitLinkAssetChecked, setLimitLinkAssetChecked] = useState(false);
  const [acceptSpecifiedEntryType, setAcceptSpecifiedEntryType] =
    useState(false);
  const [acceptSpecifiedOnlyEntryType, setAcceptSpecifiedOnlyEntryType] =
    useState(false);
  const [acceptOnlySpecifiedEntryValue, setAcceptOnlySpecifiedEntryValue] =
    useState(false);
  const [matchSpecificPattern, setMatchSpecificPattern] = useState(false);
  const [prohibitSpecificPattern, setProhibitSpecificPattern] = useState(false);
  const [acceptOnlySpecificPattern, setAcceptOnlySpecificPattern] =
    useState(false);
  const [acceptSpecificFileSize, setAcceptSpecificFileSize] = useState(false);
  const [acceptSpecificFileType, setAcceptSpecificFileType] = useState(false);
  const [acceptSpecificImageDimension, setAcceptSpecificImageDimension] =
    useState(false);
  const [selectedSpecificPattern, setSelectedSpecificPattern] = useState("");
  const [acceptSpecificDateRange, setAcceptSpecificDateRange] = useState(false);
  const [selectedValues, setSelectedValues] = useState([]);

  const [inputValue, setInputValue] = useState("");
  const [specificPatternSelectedValues, setspecificPatternSelectedValues] =
    useState([]);
  const [selectedFileType, setSelectedFileType] = useState([]);
  const [selectedImageDimension, setSelectedImageDimension] = useState([]);
  const [selectedImageDimensionValues, setSelectedImageDimensionValues] =
    useState([]);
  const [selectedDateRangeValues, setSelectedDateRangeValues] = useState([]);
  const [selectedDateRange, setSelectedDateRange] = useState([]);
  const [limitNumberPropertiesChecked, setLimitNumberPropertiesChecked] =
    useState(false);
  const [
    acceptSpecifiedEntryType_reference,
    setAcceptSpecifiedEntryType_reference,
  ] = useState(false);
  const [
    acceptSpecifiedNumberRangeChecked,
    setAcceptSpecifiedNumberRangeChecked,
  ] = useState(false);
  const [
    acceptSpecifiedValuesNumberChecked,
    setAcceptSpecifiedValuesNumberChecked,
  ] = useState(false);

  const [
    acceptSpecifiedValuesTextChecked,
    setAcceptSpecifiedValuesTextChecked,
  ] = useState(false);

  const [limitCharacterCountTextChecked, setLimitCharacterCountTextChecked] =
    useState(false);

  const [minValueLimitNumberProperties, setMinValueLimitNumberProperties] =
    useState("");
  const [maxValueLimitNumberProperties, setMaxValueLimitNumberProperties] =
    useState("");
  const [selectedLimitNumberProperties, setSelectedLimitNumberProperties] =
    useState({ value: "between" });

  const [minSizeType, setMinSizeType] = useState("");
  const [maxSizeType, setMaxSizeType] = useState("");

  const [
    minValueAcceptSpecifiedNumberRange,
    setMinValueAcceptSpecifiedNumberRange,
  ] = useState("");
  const [
    maxValueAcceptSpecifiedNumberRange,
    setMaxValueAcceptSpecifiedNumberRange,
  ] = useState("");
  const [
    selectedAcceptSpecifiedNumberRange,
    setSelectedAcceptSpecifiedNumberRange,
  ] = useState({ value: "between" });

  const [
    acceptSpecifiedEntryTypeSelectedValue,
    setAcceptSpecifiedEntryTypeSelectedValue,
  ] = useState([]);

  useEffect(() => {
    reset(defaultValues);
  }, [reset, defaultValues]);

  useEffect(() => {
    if (Boolean(selectedSpecificPattern)) {
      setSelectedSpecificPattern(selectedSpecificPattern);
    } else if (
      Boolean(formData?.field?.matchSpecificPattern?.specifyPatternType)
    ) {
      const existingPatternType =
        formData?.field?.matchSpecificPattern?.specifyPatternType;
      const existPattern = SELETE_SPECIFIC_PATTERN[0]?.children.find(
        (item) => item.value.toLowerCase() == existingPatternType.toLowerCase()
      );
      if (existPattern) {
        setSelectedSpecificPattern(existPattern);
      }
    } else {
      setSelectedSpecificPattern(SELETE_SPECIFIC_PATTERN[0]?.children[0]);
    }
  }, [selectedSpecificPattern]);

  useEffect(() => {
    if (
      Boolean(formData?.field?.integerNumber?.specifiedValues?.values?.length)
    ) {
      setspecificPatternSelectedValues(
        formData?.field?.integerNumber?.specifiedValues?.values
      );
    } else if (
      Boolean(formData?.field?.decimalNumber?.specifiedValues.values?.length)
    ) {
      setspecificPatternSelectedValues(
        formData?.field?.decimalNumber?.specifiedValues?.values
      );
    } else if (Boolean(formData?.field?.specifiedValues?.values?.length)) {
      setspecificPatternSelectedValues(
        formData?.field?.specifiedValues?.values
      );
    } else {
      setspecificPatternSelectedValues([]);
    }
  }, []);

  useEffect(() => {
    // Log to console based on the required field
    const watchFields = [
      "limitCharacterCount",
      "numberLimit_link",
      "numberLimit_enty",
      "numberLimit_block",
      "numberLimit_inline",
      "numberLimit_asset",
      "accept_specified_entryType",
      "acceptSpecifiedEntryType",
      "acceptOnlySpecifiedEntryType",
      "matchSpecificPattern",
      "prohibitSpecificPattern",
      "acceptOnlySpecificValues",
      "acceptSpecificFileSize",
      "acceptSpecifiedFileType",
      "acceptSpecifiedImageDimension",
      "acceptSpecificDateRange",
      "limitNumberOfProperties",
      "acceptSpecifiedEntryType_reference",
      "accept_specified_number_range",
      "acceptOnlySpecificValues_number",
      "acceptOnlySpecificValues_text",
      "limitCharacterCount_text",
    ];

    watchFields.forEach((field) => {
      const stateSetter = getFieldStateSetter(field);
      if (watch(field)) {
        stateSetter(true);
      } else {
        stateSetter(false);
      }
    });
  }, [
    watch("limitCharacterCount"),
    watch("numberLimit_link"),
    watch("numberLimit_enty"),
    watch("numberLimit_block"),
    watch("numberLimit_inline"),
    watch("numberLimit_asset"),
    watch("accept_specified_entryType"),
    watch("acceptSpecifiedEntryType"),
    watch("acceptOnlySpecifiedEntryType"),
    watch("matchSpecificPattern"),
    watch("prohibitSpecificPattern"),
    watch("acceptOnlySpecificValues"),
    watch("acceptSpecificFileSize"),
    watch("acceptSpecifiedFileType"),
    watch("acceptSpecifiedImageDimension"),
    watch("acceptSpecificDateRange"),
    watch("limitNumberOfProperties"),
    watch("acceptSpecifiedEntryType_reference"),
    watch("accept_specified_number_range"),
    watch("acceptOnlySpecificValues_number"),
    watch("acceptOnlySpecificValues_text"),
    watch("limitCharacterCount_text"),
  ]);

  const getFieldStateSetter = (fieldName) => {
    switch (fieldName) {
      case "limitCharacterCount":
        return setLimitCharacterCountChecked;
      case "numberLimit_link":
        return setLimitLinkNumberChecked;
      case "numberLimit_enty":
        return setLimitLinkEnryChecked;
      case "numberLimit_block":
        return setLimitLinkBlockChecked;
      case "numberLimit_inline":
        return setLimitLinkInlineChecked;
      case "numberLimit_asset":
        return setLimitLinkAssetChecked;
      case "acceptSpecifiedEntryType":
        return setAcceptSpecifiedEntryType;
      case "accept_specified_entryType":
        return setAcceptSpecifiedOnlyEntryType;
      case "acceptOnlySpecifiedEntryType":
        return setAcceptOnlySpecifiedEntryValue;
      case "matchSpecificPattern":
        return setMatchSpecificPattern;
      case "prohibitSpecificPattern":
        return setProhibitSpecificPattern;
      case "acceptOnlySpecificValues":
        return setAcceptOnlySpecificPattern;
      case "acceptSpecificFileSize":
        return setAcceptSpecificFileSize;
      case "acceptSpecifiedFileType":
        return setAcceptSpecificFileType;
      case "acceptSpecifiedImageDimension":
        return setAcceptSpecificImageDimension;
      case "acceptSpecificDateRange":
        return setAcceptSpecificDateRange;
      case "limitNumberOfProperties":
        return setLimitNumberPropertiesChecked;
      case "acceptSpecifiedEntryType_reference":
        return setAcceptSpecifiedEntryType_reference;
      case "accept_specified_number_range":
        return setAcceptSpecifiedNumberRangeChecked;
      case "acceptOnlySpecificValues_number":
        return setAcceptSpecifiedValuesNumberChecked;
      case "acceptOnlySpecificValues_text":
        return setAcceptSpecifiedValuesTextChecked;
      case "limitCharacterCount_text":
        return setLimitCharacterCountTextChecked;
      default:
        return () => {};
    }
  };

  const onSubmit = async (values) => {
    try {
      let res = null;
      formData.field.name = values.name;
      formData.field.id = values.api_identifier;

      let isIntegarNumberType = editMode
        ? formData.field.type === "INTEGER"
        : formData.type === "INTEGER";
      let isDecimalNumberType = editMode
        ? formData.field.type === "DECIMAL"
        : formData.type === "DECIMAL";

      const formattedValues = [];
      selectedImageDimensionValues.forEach((dimension) => {
        if (
          dimension?.values?.isActive &&
          (dimension.values.minimum ||
            dimension.values.maximum ||
            dimension.values.exactly ||
            dimension.values.limitType)
        ) {
          const formattedObject = {
            limitType: dimension.values.limitType || "ATLEAST",
            minimum: dimension.values.minimum || "",
            maximum: dimension.values.maximum || "",
            exactly: dimension.values.exactly || "",
            type: dimension.title,
          };
          formattedValues.push(formattedObject);
        }
      });

      let data = {
        contentModelId: apiIdentifier ? apiIdentifier : contentModelId,
        fieldId: values.api_identifier,
        value: {
          ...formData.field,
          ...(formData?.field?.fieldType === "TEXT"
            ? {
                entryTitle: values?.entryTitle,
              }
            : {}),
          type: formData.type || formData?.field?.type || "NONE",
          value:
            formData?.field?.fieldType === "NUMBER"
              ? Number(values.default_value)
              : formData?.field?.fieldType === "BOOLEAN"
                ? values.default_value !== undefined
                  ? values.default_value
                  : ""
                : values.default_value,
          ...(isIntegarNumberType
            ? {
                integerNumber: {
                  unique: values.unique,
                  isSpecifiedValues: acceptSpecifiedValuesNumberChecked
                    ? true
                    : false,
                  specifiedValues: {
                    values: specificPatternSelectedValues,
                    customErrorMessage:
                      values.customText_accept_specified_number_value,
                  },
                },
              }
            : {}),
          ...(isDecimalNumberType
            ? {
                decimalNumber: {
                  unique: values.unique,
                  isSpecifiedValues: acceptSpecifiedValuesNumberChecked
                    ? true
                    : false,
                  specifiedValues: {
                    values: specificPatternSelectedValues,
                    customErrorMessage:
                      values.customText_accept_specified_number_value,
                  },
                },
              }
            : {}),
          ...(formData?.field?.fieldType === "NUMBER"
            ? {
                limitValidation: acceptSpecifiedNumberRangeChecked
                  ? true
                  : false,
                limitNumberValidation: {
                  ...values.details,
                  ...(selectedAcceptSpecifiedNumberRange.value === "min"
                    ? {
                        limitType:
                          selectedAcceptSpecifiedNumberRange?.value.toUpperCase(),
                        minimum: minValueAcceptSpecifiedNumberRange,
                      }
                    : selectedAcceptSpecifiedNumberRange.value === "max"
                      ? {
                          limitType:
                            selectedAcceptSpecifiedNumberRange?.value.toUpperCase(),
                          maximum: maxValueAcceptSpecifiedNumberRange,
                        }
                      : {
                          limitType:
                            selectedAcceptSpecifiedNumberRange?.value.toUpperCase(),
                          minimum: minValueAcceptSpecifiedNumberRange,
                          maximum: maxValueAcceptSpecifiedNumberRange,
                        }),
                  customErrorMessage:
                    values.customText_accept_specified_number_range,
                },
              }
            : {}),
          localized: values.localized,
          required: values.required,
          unique: values.unique,
          helpText: values.helpText,
          ...(formData?.field?.fieldType === "BOOLEAN"
            ? {
                false_custom_label: values.false_custom_label,
                true_custom_label: values.true_custom_label,
              }
            : {}),
          ...(formData?.field?.fieldType === "DATETIME"
            ? {
                dateTimeValidation: selectedDateRangeValues?.dateTimeValidation,
                dateLimitValidation:
                  selectedDateRangeValues?.dateLimitValidation,
              }
            : {}),
          ...(formData?.field?.fieldType === "TEXT"
            ? {
                type: formData?.type
                  ? formData?.type
                  : formData?.field?.type
                    ? formData?.field?.type
                    : "NONE",
                isSpecifiedValues: acceptSpecifiedValuesTextChecked
                  ? true
                  : false,
                specifiedValues: {
                  values: specificPatternSelectedValues,
                  customErrorMessage:
                    values.customText_accept_specified_text_value,
                },
                characterLimit: limitCharacterCountTextChecked ? true : false,
                characterLimitValidation: {
                  ...values.details,
                  ...(selectedLimitNumberProperties.value === "min"
                    ? {
                        limitType:
                          selectedLimitNumberProperties?.value.toUpperCase(),
                        minimum: minValueLimitNumberProperties,
                      }
                    : selectedLimitNumberProperties.value === "max"
                      ? {
                          limitType:
                            selectedLimitNumberProperties?.value.toUpperCase(),
                          maximum: maxValueLimitNumberProperties,
                        }
                      : {
                          limitType:
                            selectedLimitNumberProperties?.value.toUpperCase(),
                          minimum: minValueLimitNumberProperties,
                          maximum: maxValueLimitNumberProperties,
                        }),
                  customErrorMessage: values.customText_limitNumberCount_text,
                },
                isMatchSpecificPattern: matchSpecificPattern ? true : false,
                matchSpecificPattern: {
                  specifyPatternType: selectedSpecificPattern?.value,
                  flags: values.flagtext,
                  customErrorMessage: values?.customText_matchPattern,
                },
                isProhibitSpecificPattern: prohibitSpecificPattern
                  ? true
                  : false,
                matchProhibitSpecificPattern: {
                  specifyPatternType: values?.prohibittext,
                  flags: values?.flagtext_prohibit,
                  customErrorMessage: values?.customText_prohibit,
                },
              }
            : {}),
          ...(formData?.field?.fieldType === "MEDIA"
            ? {
                type: formData?.type
                  ? formData?.type
                  : formData?.field?.type
                    ? formData?.field?.type
                    : "NONE",
                limitValidation: acceptSpecificFileSize ? true : false,
                assetLimitValidation: acceptSpecificFileSize
                  ? {
                      ...values.details,
                      ...(selectedLimitNumberProperties.value === "min"
                        ? {
                            limitType:
                              selectedLimitNumberProperties?.value.toUpperCase(),
                            minimum: minValueLimitNumberProperties,
                          }
                        : selectedLimitNumberProperties.value === "max"
                          ? {
                              limitType:
                                selectedLimitNumberProperties?.value.toUpperCase(),
                              maximum: maxValueLimitNumberProperties,
                            }
                          : {
                              limitType:
                                selectedLimitNumberProperties?.value.toUpperCase(),
                              minimum: minValueLimitNumberProperties,
                              maximum: maxValueLimitNumberProperties,
                              minSizeType: minSizeType,
                              maxSizeType: maxSizeType,
                            }),
                      customErrorMessage:
                        values?.customText_acceptSpecificFileSize,
                    }
                  : {},
                specifiedFileType: acceptSpecificFileType ? true : false,
                specifiedMediaFileType: acceptSpecificFileType
                  ? {
                      mediaTypes: selectedFileType,
                      customErrorMessage: values?.customText_selectedFileType,
                    }
                  : {},
                specifiedDimensions: acceptSpecificImageDimension
                  ? true
                  : false,
                specifiedDimensionsValues: acceptSpecificImageDimension
                  ? {
                      dimensions: formattedValues,
                      customErrorMessage:
                        values?.customText_acceptSpecifiedImageDimension,
                    }
                  : {},
              }
            : {}),
          ...(formData?.field?.fieldType === "JSON"
            ? {
                limitValidation: limitNumberPropertiesChecked ? true : false,
                jsonLimitValidation: {
                  ...values.details,
                  ...(selectedLimitNumberProperties.value === "min"
                    ? {
                        limitType:
                          selectedLimitNumberProperties?.value.toUpperCase(),
                        minimum: minValueLimitNumberProperties,
                      }
                    : selectedLimitNumberProperties.value === "max"
                      ? {
                          limitType:
                            selectedLimitNumberProperties?.value.toUpperCase(),
                          maximum: maxValueLimitNumberProperties,
                        }
                      : {
                          limitType:
                            selectedLimitNumberProperties?.value.toUpperCase(),
                          minimum: minValueLimitNumberProperties,
                          maximum: maxValueLimitNumberProperties,
                        }),
                  customErrorMessage: values.customText_limitNumberProperties,
                },
              }
            : {}),
          ...(formData?.field?.fieldType === "REFERENCE"
            ? {
                type: formData?.type
                  ? formData?.type
                  : formData?.field?.type
                    ? formData?.field?.type
                    : "NONE",
                validation: {
                  isSpecifiedContentTypes: acceptSpecifiedEntryType_reference
                    ? true
                    : false,
                  specifiedValues: acceptSpecifiedEntryType_reference
                    ? {
                        values: acceptSpecifiedEntryTypeSelectedValue,
                        customErrorMessage:
                          values.customText_entryType_reference,
                      }
                    : {},
                },
              }
            : {}),
        },
      };
      if (editMode) {
        res = await dispatch(
          updateField(data, formData?.field.id, spaceId, spaceEnvironmentId)
        );
      } else if (apiIdentifier) {
        res = await dispatch(
          createContentModel(savedModelData, spaceId, spaceEnvironmentId, data)
        );
      } else {
        // edit mode
        res = await dispatch(addField(data, spaceId, spaceEnvironmentId));
      }

      const {
        result: { body },
      } = res;
      if (body.responseCode === 200) {
        addToast(body.responseMessage);
        onAddEditOrUpdate((prev) => prev + 1);
        dispatch(
          getContentModelById(contentModelId, spaceId, spaceEnvironmentId)
        );
        if (apiIdentifier) {
          router.push(
            replaceUrlParams(APP_URLS.CONTENT_MODELS.CONTENT_FIELDS.LIST, {
              spaceId,
              spaceEnvironmentId,
              contentModelId: apiIdentifier,
            })
          );
        }
        onClose();
      } else {
        addToast(body?.responseMessage || "An unknown error occured!", {
          type: "error",
        });
      }
    } catch (err) {
      console.log("error: ", err);
    } finally {
    }
  };

  const smoothScrollTo = (elementIds) => {
    if (elementIds.length > 0) {
      elementIds.forEach((elementId) => {
        const element = document.getElementById(elementId);

        if (element) {
          element.scrollIntoView({ behavior: "smooth" });
        }
      });
    }
  };

  const sidebarElements = [
    { id: "NameAndFieldIdSection", label: "Name and field ID" },
    ...JSON_DATA.map((m) => ({
      id: m.heading.replace(/\s+/g, ""),
      label: m.heading,
    })),
    { id: "DefaultValue", label: "Default Value" },
  ];

  const formatToggleHandler = () => {
    console.log("disable / enabled button click");
    e.preventDefault();
    return;
  };

  const handleInputChange = (event) => {
    setInputValue(event.target.value);
  };

  const handleInputEnter = (event) => {
    if (event.key === "Enter" && inputValue.trim() !== "") {
      event.preventDefault();
      setspecificPatternSelectedValues((prevValues) => [
        ...prevValues,
        inputValue.trim(),
      ]);
      setInputValue("");
    }
  };

  const handleRemoveValue = (valueToRemove) => {
    setspecificPatternSelectedValues((prevValues) =>
      prevValues.filter((value) => value !== valueToRemove)
    );
  };

  const handleEntries = (key) => {
    const updateEnteries = { ...enteries };
    updateEnteries[key] = !updateEnteries[key];
    setEnteries({ ...updateEnteries });
  };

  const isWidthEnabled = selectedImageDimension.includes("width");
  const isHeightEnabled = selectedImageDimension.includes("height");

  const isLaterThan = selectedDateRange.includes("later_than");
  const isEarlierThan = selectedDateRange.includes("earlier_than");

  // const handleScroll = () => {
  //   const scrollPosition = window.scrollY;
  //   console.log(scrollPosition, "scrollPosition");
  //   // Assuming each section has a height of 100vh (adjust as needed)
  //   const sectionHeight = window.innerHeight;
  //   console.log(sectionHeight, "sectionHeight");

  //   const currentSectionIndex = Math.floor(scrollPosition / sectionHeight);
  //   console.log(currentSectionIndex, "currentSectionIndex");

  //   // Get the current section ID
  //   const currentSectionId =
  //     sidebarElements[currentSectionIndex]?.id || sidebarElements[0]?.id;

  //   console.log(currentSectionId, "currentSectionId");
  // };

  // useEffect(() => {
  //   window.addEventListener("scroll", handleScroll);
  //   return () => {
  //     window.removeEventListener("scroll", handleScroll);
  //   };
  // }, [window.scrollY]);
  const [enteredValues, setEnteredValues] = useState([]);
  const handleEnterPress = (enteredValue) => {
    // if (enteredValue.trim() !== "") {
    //   // Add the entered value to the array
    //   setEnteredValues((prevValues) => [...prevValues, enteredValue]);
    // }
  };

  const multipleDropdownOptions =
    Boolean(data?.content?.length) &&
    data.content.map((item) => ({
      id: item.contentModelId,
      value: item.name,
      label: item.name,
    }));

  return (
    <>
      <FormProvider {...methods}>
        <form
          className={styles.form}
          onSubmit={handleSubmit(onSubmit)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
            }
          }}
        >
          <div className={styles.settingFormParent}>
            <div className={styles.settingFormSideBarParent}>
              <div className={styles.settingFormSideBar}>
                {sidebarElements.map((element) => (
                  <div
                    key={element.id}
                    onClick={() => smoothScrollTo([element.id])}
                    className={styles.sidebar_link}
                  >
                    <div className={styles.sidebar_fields}>{element.label}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className={styles.settingForm}>
              <div
                id="NameAndFieldIdSection"
                className={cn(
                  styles["field-heading"],
                  "field-heading",
                  "font-weight-semi-bold",
                  "mb-5"
                )}
              >
                Name and field ID
              </div>
              <div>
                <Controller
                  name="name"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Name"
                      required
                      maxLength={50}
                      error={errors?.name?.message}
                    />
                  )}
                />
                <Controller
                  name="api_identifier"
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label="Field ID"
                      disabled={editMode}
                      required
                      maxLength={64}
                      error={errors?.api_identifier?.message}
                    />
                  )}
                />
              </div>

              {JSON_DATA.map((m) => {
                return (
                  <div key={m.heading} className="mb-5">
                    <div
                      className={cn(
                        styles["field-heading"],
                        "field-heading",
                        "font-weight-semi-bold",
                        "mb-5"
                      )}
                      id={m.heading.replace(/\s+/g, "")}
                    >
                      {m.heading}
                    </div>

                    <div className="mb-10">
                      {m.values_options.map((item) => {
                        return (
                          <div
                            className={cn(styles.subHeading)}
                            id={item?.heading?.replace(/\s+/g, "")}
                            key={item?.heading}
                          >
                            {item?.heading}{" "}
                            {item?.heading === "Formatting" && (
                              <button
                                className={styles?.disable_enable}
                                onClick={(e) => {
                                  e.preventDefault();
                                  formatToggleHandler();
                                }}
                              >
                                Disable all
                              </button>
                            )}
                            {item.options &&
                              item.options.map((val, index) => {
                                if (
                                  (m.heading === "Validation" &&
                                    val?.name === "limitCharacterCount" &&
                                    limitCharacterCountChecked) ||
                                  (val?.name === "numberLimit_link" &&
                                    limitLinkNumberChecked) ||
                                  (val?.name === "numberLimit_enty" &&
                                    limitLinkEnryChecked) ||
                                  (val?.name === "numberLimit_block" &&
                                    limitLinkBlockChecked) ||
                                  (val?.name === "numberLimit_inline" &&
                                    limitLinkInlineChecked) ||
                                  (val?.name === "numberLimit_asset" &&
                                    limitLinkAssetChecked) ||
                                  (val?.name === "limitNumberOfProperties" &&
                                    limitNumberPropertiesChecked) ||
                                  (val?.name ===
                                    "accept_specified_number_range" &&
                                    acceptSpecifiedNumberRangeChecked) ||
                                  (val?.name === "limitCharacterCount_text" &&
                                    limitCharacterCountTextChecked)
                                ) {
                                  return (
                                    <>
                                      <div>
                                        <Controller
                                          key={"" + index}
                                          name={val?.name}
                                          control={control}
                                          render={({ field }) => (
                                            <Checkbox
                                              {...field}
                                              id={val?.value}
                                              checked={field.value}
                                              value={val?.value}
                                              // label={val?.label + "mango"}
                                              label={val?.label}
                                              hint={val?.hint}
                                            />
                                          )}
                                        />
                                      </div>
                                      <div>
                                        {val?.name ===
                                          "limitNumberOfProperties" && (
                                          <LimitCharacterCount
                                            minValue={
                                              minValueLimitNumberProperties
                                            }
                                            setMinValue={
                                              setMinValueLimitNumberProperties
                                            }
                                            maxValue={
                                              maxValueLimitNumberProperties
                                            }
                                            setMaxValue={
                                              setMaxValueLimitNumberProperties
                                            }
                                            selectedLimitCharacter={
                                              selectedLimitNumberProperties
                                            }
                                            setSelectedLimitCharacter={
                                              setSelectedLimitNumberProperties
                                            }
                                            existValues={formData?.field}
                                          />
                                        )}
                                        {val?.name ===
                                          "accept_specified_number_range" && (
                                          <LimitCharacterCount
                                            minValue={
                                              minValueAcceptSpecifiedNumberRange
                                            }
                                            setMinValue={
                                              setMinValueAcceptSpecifiedNumberRange
                                            }
                                            maxValue={
                                              maxValueAcceptSpecifiedNumberRange
                                            }
                                            setMaxValue={
                                              setMaxValueAcceptSpecifiedNumberRange
                                            }
                                            selectedLimitCharacter={
                                              selectedAcceptSpecifiedNumberRange
                                            }
                                            setSelectedLimitCharacter={
                                              setSelectedAcceptSpecifiedNumberRange
                                            }
                                            existValues={formData?.field}
                                          />
                                        )}
                                        {val?.name ===
                                          "limitCharacterCount_text" && (
                                          <LimitCharacterCount
                                            minValue={
                                              minValueLimitNumberProperties
                                            }
                                            setMinValue={
                                              setMinValueLimitNumberProperties
                                            }
                                            maxValue={
                                              maxValueLimitNumberProperties
                                            }
                                            setMaxValue={
                                              setMaxValueLimitNumberProperties
                                            }
                                            selectedLimitCharacter={
                                              selectedLimitNumberProperties
                                            }
                                            setSelectedLimitCharacter={
                                              setSelectedLimitNumberProperties
                                            }
                                            existValues={formData?.field}
                                          />
                                        )}
                                        {val?.name !==
                                          "limitNumberOfProperties" &&
                                          val?.name !==
                                            "accept_specified_number_range" &&
                                          val?.name !==
                                            "limitCharacterCount_text" && (
                                            <LimitCharacterCount />
                                          )}
                                      </div>
                                      <div
                                        className={
                                          styles?.limitCount_customText
                                        }
                                      >
                                        <Controller
                                          name={
                                            val?.name ===
                                            "limitNumberOfProperties"
                                              ? "customText_limitNumberProperties"
                                              : val?.name ===
                                                  "accept_specified_number_range"
                                                ? "customText_accept_specified_number_range"
                                                : val?.name ===
                                                    "limitCharacterCount_text"
                                                  ? "customText_limitNumberCount_text"
                                                  : "customText"
                                          }
                                          control={control}
                                          render={({ field }) => (
                                            <TextField
                                              {...field}
                                              label="Custom error message"
                                            />
                                          )}
                                        />
                                      </div>
                                    </>
                                  );
                                }

                                if (
                                  (m.heading === "Validation" &&
                                    val?.name === "acceptSpecifiedEntryType" &&
                                    acceptSpecifiedEntryType) ||
                                  (val?.name === "accept_specified_entryType" &&
                                    acceptSpecifiedOnlyEntryType) ||
                                  (val?.name ===
                                    "acceptOnlySpecifiedEntryType" &&
                                    acceptOnlySpecifiedEntryValue) ||
                                  (val?.name ===
                                    "acceptSpecifiedEntryType_reference" &&
                                    acceptSpecifiedEntryType_reference)
                                ) {
                                  return (
                                    <>
                                      <div>
                                        <Controller
                                          key={"" + index}
                                          name={val?.name}
                                          control={control}
                                          render={({ field }) => (
                                            <Checkbox
                                              {...field}
                                              id={val?.value}
                                              checked={field.value}
                                              value={val?.value}
                                              label={val?.label}
                                              hint={val?.hint}
                                            />
                                          )}
                                        />
                                      </div>
                                      <div>
                                        <MultiDropdownFields
                                          data={[
                                            {
                                              heading: "General validations",
                                              options: multipleDropdownOptions,
                                            },
                                          ]}
                                          selectedValues={
                                            val?.name ===
                                            "acceptSpecifiedEntryType_reference"
                                              ? acceptSpecifiedEntryTypeSelectedValue
                                              : selectedValues
                                          }
                                          setSelectedValues={
                                            val?.name ===
                                            "acceptSpecifiedEntryType_reference"
                                              ? setAcceptSpecifiedEntryTypeSelectedValue
                                              : setSelectedValues
                                          }
                                          existValues={
                                            formData?.field?.validation
                                              ?.specifiedValues?.values
                                          }
                                        />
                                      </div>
                                      <div className={styles?.customWrapper}>
                                        <div className={styles?.customText}>
                                          <Controller
                                            name={
                                              val?.name ===
                                              "acceptSpecifiedEntryType_reference"
                                                ? "customText_entryType_reference"
                                                : "customText"
                                            }
                                            control={control}
                                            render={({ field }) => (
                                              <TextField
                                                {...field}
                                                label="Custom error message"
                                              />
                                            )}
                                          />
                                        </div>
                                      </div>
                                    </>
                                  );
                                }

                                if (
                                  m.heading === "Validation" &&
                                  val?.name === "matchSpecificPattern" &&
                                  matchSpecificPattern
                                ) {
                                  return (
                                    <>
                                      <div>
                                        <Controller
                                          key={"" + index}
                                          name={val?.name}
                                          control={control}
                                          render={({ field }) => (
                                            <Checkbox
                                              {...field}
                                              id={val?.value}
                                              checked={field.value}
                                              value={val?.value}
                                              label={val?.label}
                                              hint={val?.hint}
                                            />
                                          )}
                                        />
                                      </div>
                                      <div
                                        className={styles?.matchSpecificPattern}
                                      >
                                        <div
                                          className={
                                            styles?.matchPatternDropdown
                                          }
                                        >
                                          <DropdownField
                                            data={SELETE_SPECIFIC_PATTERN}
                                            selectedvalue={
                                              selectedSpecificPattern
                                            }
                                            setSelectedValue={
                                              setSelectedSpecificPattern
                                            }
                                          />
                                        </div>
                                        <div
                                          className={styles?.matchPatternInput}
                                        >
                                          <TextField
                                            value={
                                              selectedSpecificPattern?.value
                                            }
                                          />
                                        </div>
                                      </div>

                                      <div className={styles?.matchPatternFlag}>
                                        <Controller
                                          name="flagtext"
                                          control={control}
                                          render={({ field }) => (
                                            <TextField
                                              {...field}
                                              label="Flag"
                                            />
                                          )}
                                        />
                                      </div>
                                      <div className={styles?.customWrapper}>
                                        <div
                                          className={
                                            styles?.matchPattern_customText
                                          }
                                        >
                                          <Controller
                                            name="customText_matchPattern"
                                            control={control}
                                            render={({ field }) => (
                                              <TextField
                                                {...field}
                                                label="Custom error message"
                                              />
                                            )}
                                          />
                                        </div>
                                      </div>
                                    </>
                                  );
                                }

                                if (
                                  m.heading === "Validation" &&
                                  val?.name === "prohibitSpecificPattern" &&
                                  prohibitSpecificPattern
                                ) {
                                  return (
                                    <>
                                      <div>
                                        <Controller
                                          key={"" + index}
                                          name={val?.name}
                                          control={control}
                                          render={({ field }) => (
                                            <Checkbox
                                              {...field}
                                              id={val?.value}
                                              checked={field.value}
                                              value={val?.value}
                                              label={val?.label}
                                              hint={val?.hint}
                                            />
                                          )}
                                        />
                                      </div>
                                      <div className={styles?.prohibitPattern}>
                                        <Controller
                                          name="prohibittext"
                                          control={control}
                                          render={({ field }) => (
                                            <TextField
                                              {...field}
                                              placeholder="foo|bar[baz]"
                                            />
                                          )}
                                        />
                                      </div>

                                      <div className={styles?.matchPatternFlag}>
                                        <Controller
                                          name="flagtext_prohibit"
                                          control={control}
                                          render={({ field }) => (
                                            <TextField
                                              {...field}
                                              label="Flag"
                                            />
                                          )}
                                        />
                                      </div>
                                      <div className={styles?.customWrapper}>
                                        <div className={styles?.customText}>
                                          <Controller
                                            name="customText_prohibit"
                                            control={control}
                                            render={({ field }) => (
                                              <TextField
                                                {...field}
                                                label="Custom error message"
                                              />
                                            )}
                                          />
                                        </div>
                                      </div>
                                    </>
                                  );
                                }

                                if (
                                  (m.heading === "Validation" &&
                                    val?.name === "acceptOnlySpecificValues" &&
                                    acceptOnlySpecificPattern) ||
                                  (val?.name ===
                                    "acceptOnlySpecificValues_number" &&
                                    acceptSpecifiedValuesNumberChecked) ||
                                  (val?.name ===
                                    "acceptOnlySpecificValues_text" &&
                                    acceptSpecifiedValuesTextChecked)
                                ) {
                                  return (
                                    <>
                                      <div>
                                        <Controller
                                          key={"" + index}
                                          name={val?.name}
                                          control={control}
                                          render={({ field }) => (
                                            <Checkbox
                                              {...field}
                                              id={val?.value}
                                              checked={field.value}
                                              value={val?.value}
                                              label={val?.label}
                                              hint={val?.hint}
                                            />
                                          )}
                                        />
                                      </div>
                                      <div
                                        className={
                                          styles?.acceptOnlySpecificPattern
                                        }
                                      >
                                        <p>
                                          Predefined values work best with the
                                          checkbox editor.
                                        </p>
                                        <p>
                                          To select either, go to the
                                          “Appearance” tab. Learn more about{" "}
                                          <Link href="#">
                                            predefined values
                                          </Link>
                                          .
                                        </p>
                                        <input
                                          type={
                                            val?.name ===
                                            "acceptOnlySpecificValues_number"
                                              ? "number"
                                              : "text"
                                          }
                                          value={inputValue}
                                          onChange={handleInputChange}
                                          onKeyDown={handleInputEnter}
                                          placeholder="Hit enter to add a value"
                                        />
                                        {specificPatternSelectedValues?.length >
                                          0 && (
                                          <div>
                                            <ul>
                                              {specificPatternSelectedValues?.map(
                                                (value, index) => (
                                                  <li key={index}>
                                                    {value}{" "}
                                                    <AiOutlineClose
                                                      onClick={() =>
                                                        handleRemoveValue(value)
                                                      }
                                                    />
                                                  </li>
                                                )
                                              )}
                                            </ul>
                                          </div>
                                        )}
                                      </div>

                                      <div className={styles?.customWrapper}>
                                        <div className={styles?.customText}>
                                          <Controller
                                            name={
                                              val?.name ===
                                              "acceptOnlySpecificValues_number"
                                                ? "customText_accept_specified_number_value"
                                                : val?.name ===
                                                    "acceptOnlySpecificValues_text"
                                                  ? "customText_accept_specified_text_value"
                                                  : "customText"
                                            }
                                            control={control}
                                            render={({ field }) => (
                                              <TextField
                                                {...field}
                                                label="Custom error message"
                                              />
                                            )}
                                          />
                                        </div>
                                      </div>
                                    </>
                                  );
                                }

                                if (
                                  m.heading === "Validation" &&
                                  val?.name === "acceptSpecificFileSize" &&
                                  acceptSpecificFileSize
                                ) {
                                  return (
                                    <>
                                      <div>
                                        <Controller
                                          key={"" + index}
                                          name={val?.name}
                                          control={control}
                                          render={({ field }) => (
                                            <Checkbox
                                              {...field}
                                              id={val?.value}
                                              checked={field.value}
                                              value={val?.value}
                                              label={val?.label}
                                              hint={val?.hint}
                                            />
                                          )}
                                        />
                                      </div>
                                      <div>
                                        <AcceptSpecificFileSize
                                          minValue={
                                            minValueLimitNumberProperties
                                          }
                                          setMinValue={
                                            setMinValueLimitNumberProperties
                                          }
                                          maxValue={
                                            maxValueLimitNumberProperties
                                          }
                                          setMaxValue={
                                            setMaxValueLimitNumberProperties
                                          }
                                          selectedLimitCharacter={
                                            selectedLimitNumberProperties
                                          }
                                          setSelectedLimitCharacter={
                                            setSelectedLimitNumberProperties
                                          }
                                          minSizeType={minSizeType}
                                          setMinSizeType={setMinSizeType}
                                          maxSizeType={maxSizeType}
                                          setMaxSizeType={setMaxSizeType}
                                          existValues={formData?.field}
                                        />
                                      </div>
                                      <div
                                        className={
                                          styles?.limitCount_customText
                                        }
                                      >
                                        <Controller
                                          name="customText_acceptSpecificFileSize"
                                          control={control}
                                          render={({ field }) => (
                                            <TextField
                                              {...field}
                                              label="Custom error message"
                                            />
                                          )}
                                        />
                                      </div>
                                    </>
                                  );
                                }

                                if (
                                  m.heading === "Validation" &&
                                  val?.name === "acceptSpecifiedFileType" &&
                                  acceptSpecificFileType
                                ) {
                                  return (
                                    <>
                                      <div>
                                        <Controller
                                          key={"" + index}
                                          name={val?.name}
                                          control={control}
                                          render={({ field }) => (
                                            <Checkbox
                                              {...field}
                                              id={val?.value}
                                              checked={field.value}
                                              value={val?.value}
                                              label={val?.label}
                                              hint={val?.hint}
                                            />
                                          )}
                                        />
                                      </div>
                                      <div>
                                        <AcceptSpecificFileType
                                          data={SELETE_FILE_TYPE}
                                          selectedValues={selectedFileType}
                                          setSelectedValues={
                                            setSelectedFileType
                                          }
                                          existValues={formData.field}
                                        />
                                      </div>
                                      <div
                                        className={
                                          styles?.limitCount_customText
                                        }
                                      >
                                        <Controller
                                          name="customText_selectedFileType"
                                          control={control}
                                          render={({ field }) => (
                                            <TextField
                                              {...field}
                                              label="Custom error message"
                                            />
                                          )}
                                        />
                                      </div>
                                    </>
                                  );
                                }

                                if (
                                  m.heading === "Validation" &&
                                  val?.name ===
                                    "acceptSpecifiedImageDimension" &&
                                  acceptSpecificImageDimension
                                ) {
                                  return (
                                    <>
                                      <div>
                                        <Controller
                                          key={"" + index}
                                          name={val?.name}
                                          control={control}
                                          render={({ field }) => (
                                            <Checkbox
                                              {...field}
                                              id={val?.value}
                                              checked={field.value}
                                              value={val?.value}
                                              label={val?.label}
                                              hint={val?.hint}
                                            />
                                          )}
                                        />
                                      </div>
                                      <div>
                                        <AcceptSpecificImageDimension
                                          data={[
                                            {
                                              options: [
                                                {
                                                  id: 1,
                                                  value: "width",
                                                  label: "Width",
                                                  checked: isWidthEnabled,
                                                },
                                                {
                                                  id: 2,
                                                  value: "height",
                                                  label: "Height",
                                                  checked: isHeightEnabled,
                                                },
                                              ],
                                            },
                                          ]}
                                          selectedValues={
                                            selectedImageDimension
                                          }
                                          setSelectedValues={
                                            setSelectedImageDimension
                                          }
                                          setSelectedImageDimensionValues={
                                            setSelectedImageDimensionValues
                                          }
                                          existValues={formData?.field}
                                        />
                                      </div>
                                      <div
                                        className={
                                          styles?.limitCount_customText
                                        }
                                      >
                                        <Controller
                                          name="customText_acceptSpecifiedImageDimension"
                                          control={control}
                                          render={({ field }) => (
                                            <TextField
                                              {...field}
                                              label="Custom error message"
                                            />
                                          )}
                                        />
                                      </div>
                                    </>
                                  );
                                }

                                if (
                                  m.heading === "Validation" &&
                                  val?.name === "acceptSpecificDateRange" &&
                                  acceptSpecificDateRange
                                ) {
                                  return (
                                    <>
                                      <div>
                                        <Controller
                                          key={"" + index}
                                          name={val?.name}
                                          control={control}
                                          render={({ field }) => (
                                            <Checkbox
                                              {...field}
                                              id={val?.value}
                                              checked={field.value}
                                              value={val?.value}
                                              label={val?.label}
                                              hint={val?.hint}
                                            />
                                          )}
                                        />
                                      </div>
                                      <div>
                                        <AcceptSpecificDateRange
                                          data={[
                                            {
                                              options: [
                                                {
                                                  id: 1,
                                                  value: "later_than",
                                                  label: "Later than",
                                                  checked: isLaterThan,
                                                },
                                                {
                                                  id: 2,
                                                  value: "earlier_than",
                                                  label: "Earlier than",
                                                  checked: isEarlierThan,
                                                },
                                              ],
                                            },
                                          ]}
                                          selectedValues={selectedDateRange}
                                          setSelectedValues={
                                            setSelectedDateRange
                                          }
                                          setSelectedDateRangeValues={
                                            setSelectedDateRangeValues
                                          }
                                          customText_datetime={watch(
                                            "customText_datetime"
                                          )}
                                          existValues={formData?.field}
                                        />
                                      </div>
                                      <div
                                        className={
                                          styles?.limitCount_customText
                                        }
                                      >
                                        <Controller
                                          name="customText_datetime"
                                          control={control}
                                          render={({ field }) => (
                                            <TextField
                                              {...field}
                                              label="Custom error message"
                                            />
                                          )}
                                        />
                                      </div>
                                    </>
                                  );
                                }

                                if (val?.type === "input") {
                                  return (
                                    <Controller
                                      key={"" + index}
                                      name={val?.name}
                                      control={control}
                                      render={({ field }) => (
                                        <TextField
                                          {...field}
                                          label={val?.label + "mango"}
                                          error={
                                            errors && errors[val?.name]?.message
                                          }
                                        />
                                      )}
                                    />
                                  );
                                } else if (val?.name === "formatting") {
                                  return (
                                    <div key={val?.name}>
                                      <label className={styles.label}>
                                        {val?.label}
                                      </label>
                                      <div className={styles?.formating}>
                                        {val?.value.map(
                                          (option, optionIndex) => (
                                            <div
                                              key={optionIndex}
                                              className={
                                                styles.formattingOption
                                              }
                                            >
                                              <button
                                                onClick={(e) => {
                                                  e.preventDefault();
                                                }}
                                              >
                                                {option}
                                              </button>
                                            </div>
                                          )
                                        )}
                                      </div>
                                    </div>
                                  );
                                } else if (val?.name === "allow_hyperlinks") {
                                  return (
                                    <div key={val?.name}>
                                      <label className={styles.label}>
                                        {val?.label}
                                      </label>
                                      <div className={styles?.formating}>
                                        {val?.value.map(
                                          (option, optionIndex) => (
                                            <div
                                              key={optionIndex}
                                              className={
                                                styles.formattingOption
                                              }
                                            >
                                              <button>{option}</button>
                                            </div>
                                          )
                                        )}
                                      </div>
                                    </div>
                                  );
                                } else if (
                                  val?.name === "allow_embedded_entries_assets"
                                ) {
                                  return (
                                    <div key={val?.name}>
                                      <label className={styles.label}>
                                        {val?.label}
                                      </label>
                                      <div className={styles?.formating}>
                                        {val?.value.map(
                                          (option, optionIndex) => (
                                            <div
                                              key={optionIndex}
                                              className={
                                                styles.formattingOption
                                              }
                                            >
                                              <button>{option}</button>
                                            </div>
                                          )
                                        )}
                                      </div>
                                    </div>
                                  );
                                } else {
                                  return (
                                    <Controller
                                      key={"" + index}
                                      name={val?.name}
                                      control={control}
                                      render={({ field }) => (
                                        <Checkbox
                                          {...field}
                                          id={val?.value}
                                          checked={field.value}
                                          value={val?.value}
                                          label={val?.label}
                                          hint={val?.hint}
                                        />
                                      )}
                                    />
                                  );
                                }
                              })}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}

              {formData.field.fieldType !== "BOOLEAN" && (
                <div className={cn(styles["default-value-container"], "mb-5")}>
                  <div
                    id="DefaultValue"
                    className={cn(
                      styles["field-heading"],
                      "field-heading",
                      "font-weight-semi-bold",
                      "mb-5"
                    )}
                  >
                    Default Value
                  </div>

                  {showDefaultMessage && (
                    <div className={cn(styles["default-content"])}>
                      <FcInfo className={styles["info-icon"]} />
                      <div className={styles.message}>
                        {haveDefaultValue ? (
                          <p>
                            This setting allows you to set a default value for
                            this field, which will be automatically inserted to
                            new content entries. It can help editors avoid
                            content entry altogether, or just give them a
                            helpful prompt for how to structure their content.
                          </p>
                        ) : (
                          <>
                            <p>
                              <span
                                className={cn(
                                  "text-body1",
                                  "font-weight-semi-bold"
                                )}
                              >
                                Not available for this field type
                              </span>{" "}
                              <br />
                              <br />
                              You can only set a default value for the text,
                              boolean, date and time, and number field types.
                            </p>
                          </>
                        )}
                      </div>
                      {haveDefaultValue && (
                        <IoClose
                          onClick={() => setShowDefaultMessage(false)}
                          className={styles.close}
                        />
                      )}
                    </div>
                  )}
                  {haveDefaultValue && (
                    <>
                      {formData.field.fieldType === "DATETIME" ? (
                        localized ? (
                          <>
                            {allLocales?.content.map((item) => {
                              return (
                                <Controller
                                  name={`default_value - ${item.languageCode}`}
                                  control={control}
                                  render={({ field }) => (
                                    <CustomDateField
                                      {...field}
                                      showOnlyLocaleLabel
                                      details={{
                                        format,
                                        utcFormat,
                                        timeInput,
                                        time_mode,
                                        date,
                                      }}
                                      label={item.languageCode}
                                      localized
                                      language={getLocaleByCode(
                                        item?.languageCode
                                      )}
                                    />
                                  )}
                                />
                              );
                            })}
                          </>
                        ) : (
                          <Controller
                            name="default_value"
                            control={control}
                            render={({ field }) => (
                              <CustomDateField
                                {...field}
                                details={{
                                  format,
                                  utcFormat,
                                  timeInput,
                                  time_mode,
                                  date,
                                }}
                              />
                            )}
                          />
                        )
                      ) : (
                        <>
                          {localized ? (
                            <>
                              {allLocales?.content.map((item) => {
                                return (
                                  <Controller
                                    name={
                                      item?.languageCode === "en-US"
                                        ? "default_value"
                                        : `default_value - ${item.languageCode}`
                                    }
                                    control={control}
                                    render={({ field }) => (
                                      <TextField
                                        {...field}
                                        showOnlyLocaleLabel
                                        label={item.languageCode}
                                        localized
                                        type={
                                          formData.field.fieldType === "NUMBER"
                                            ? "number"
                                            : formData.field.fieldType ===
                                                "DATETIME"
                                              ? "date"
                                              : "text"
                                        }
                                        maxLength={
                                          formData.field.fieldType === "TEXT"
                                            ? 256
                                            : undefined
                                        }
                                        hint={
                                          formData?.field?.fieldType === "TEXT"
                                            ? `${
                                                field?.value
                                                  ? field?.value?.length
                                                  : 0
                                              } Characters`
                                            : undefined
                                        }
                                        error={errors?.default_value?.message}
                                        language={getLocaleByCode(
                                          item?.languageCode
                                        )}
                                      />
                                    )}
                                  />
                                );
                              })}
                            </>
                          ) : (
                            <>
                              {formData?.field?.fieldType !== "BOOLEAN" && (
                                <Controller
                                  name="default_value"
                                  control={control}
                                  render={({ field }) => (
                                    <TextField
                                      {...field}
                                      type={
                                        formData.field.fieldType === "NUMBER"
                                          ? "number"
                                          : formData.field.fieldType ===
                                              "DATETIME"
                                            ? "date"
                                            : "text"
                                      }
                                      maxLength={
                                        formData.field.fieldType === "TEXT"
                                          ? 256
                                          : undefined
                                      }
                                      hint={
                                        formData.field.fieldType === "TEXT"
                                          ? `${field.value.length} Characters`
                                          : undefined
                                      }
                                      error={errors?.default_value?.message}
                                      onEnterPress={handleEnterPress}
                                      enteredValues={enteredValues}
                                      setEnteredValues={setEnteredValues}
                                      fieldValues
                                      formData={formData}
                                    />
                                  )}
                                />
                              )}
                            </>
                          )}
                          {/* {allLocales?.content?.length} */}
                        </>
                      )}
                    </>
                  )}
                </div>
              )}
              {/* <TextField
                // {...field}
                label={item.name}
                required={item.required}
                type="number"
                // value={item.value}
                error={errors[item.id]?.message}
                hint={item.helpText}
                localized={item.localized}
                language={getLocaleByCode(item?.languageCode)}
              /> */}
              {formData.field.fieldType === "REFERENCE" && (
                <>
                  <Divider />
                  <div className="mb-5">
                    {REF_SETTINGS.map((m, index) => (
                      <RadioItem
                        className="mb-3"
                        key={m.name}
                        trueConditionLabel={m.trueConditionLabel}
                        falseConditionLabel={m.falseConditionLabel}
                        name={m.name}
                        label={m.label}
                        hint={m.hint}
                        onChange={() =>
                          handleEntries(index ? "link" : "create")
                        }
                        value={enteries[index ? "link" : "create"]}
                        hideClearButton
                      />
                    ))}
                  </div>
                </>
              )}
              {formData.field.fieldType === "BOOLEAN" ? (
                <BooleanValidationsElm
                  showDefaultMessage={showDefaultMessage}
                  setShowDefaultMessage={setShowDefaultMessage}
                  errors={errors}
                  localized={localized}
                  allLocales={allLocales}
                  id="DefaultValue"
                  showOnlyLocaleLabel
                />
              ) : (
                ""
              )}
              <p
                className={cn(
                  styles["field-heading"],
                  "field-heading",
                  "font-weight-semi-bold",
                  "mb-5"
                )}
              >
                Appearance
              </p>
              <Controller
                name="helpText"
                control={control}
                render={({ field }) => (
                  <TextField
                    {...field}
                    label="Help Text"
                    required
                    maxLength={255}
                    error={errors?.api_identifier?.message}
                    hint={"This help text will show up below the field"}
                    mb0
                  />
                )}
              />
              {formData.field.fieldType === "DATETIME" && (
                <AppearanceDateTime />
              )}
            </div>
          </div>

          <div className={styles.actions}>
            <Button
              className={styles.actionButton}
              disabled={
                Boolean(errors?.api_identifier?.message) ||
                Boolean(errors?.name?.message) ||
                Boolean(errors?.time_mode?.message) ||
                Boolean(errors?.format?.message)
              }
              text="Save"
              type="submit"
            />
          </div>
        </form>
      </FormProvider>
    </>
  );
};

export default FieldSettingsForm;
