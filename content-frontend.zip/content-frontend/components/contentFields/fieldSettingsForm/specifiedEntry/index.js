"use client";

import React, { useState } from "react";
import styles from "./specifiedEntry.module.scss";
import { Checkbox, TextField } from "@/components/theme/form-inputs";
import Chips from "@/components/theme/chips";
import cn from "classnames";

export default function SpecifiedEntry({ id, value, label, hint, ...rest }) {
  const [specifiedValuesdata, setSpecifiedValues] = useState([]);
  const [showInputToAddData, setShowInputToAddData] = useState(false);
  const [newValue, setNewValue] = useState("");

  const handleKeyPress = (event) => {
    if (event.key === "Enter") {
      if (newValue || parseInt(newValue) === 0) {
        let updateData = [...specifiedValuesdata];
        updateData.push(parseInt(newValue));
        setSpecifiedValues(updateData);
        setNewValue("");
        event.preventDefault();
        event.stopPropagation();
      }
    }
  };

  const handleDelete = (index) => {
    let updateData = [...specifiedValuesdata];
    updateData = updateData.filter((_, i) => index !== i)
    setSpecifiedValues(updateData);
  };

  return (
    <>
      <Checkbox
        {...rest}
        id={id}
        onChange={(e) => setShowInputToAddData(e.target.checked)}
        value={value}
        label={label}
        hint={hint}
      />
      {showInputToAddData && (
        <>
          <p className="mt-3 text-body2 pl-8 color-gray-700">
            Predefined values work best with the dropdown list or radio button
            list. <br />
            To select either, go to the "Appearance" tab. Learn more about{" "}
            <span className="color-blue-700">predefined values</span>.
          </p>
          <div className="ml-8">
            <TextField
              value={newValue}
              type="number"
              onChange={(e) => setNewValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Hit enter to add a value"
            />
          </div>
          <div className={cn(styles["chips-container"], "ml-8")}>
            {specifiedValuesdata.map((number, index) => (
              <Chips
                handleDelete={() => handleDelete(index)}
                key={index}
                value={number}
              />
            ))}
          </div>
        </>
      )}
    </>
  );
}
