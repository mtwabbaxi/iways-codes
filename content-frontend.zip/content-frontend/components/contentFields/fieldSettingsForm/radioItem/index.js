import { Radio } from "@/components/theme/form-inputs";
import { useFormContext, Controller } from "react-hook-form";
import cn from "classnames";
import styles from "./radioItem.module.scss";

const RadioItem = ({
  name,
  label,
  hint,
  className = "",
  trueConditionLabel,
  falseConditionLabel,
  onChange = () => {},
  value,
  hideClearButton = false,
  localized,
  language = "English (United States) (en-US)",
  showOnlyLocaleLabel = false,
}) => {
  console.log("🚀 ~ value:", value);
  const { control } = useFormContext() || {};
  return (
    <div className={className}>
      <div className="text-body2 font-weight-semi-bold color-2900 mb-1">
        <label className={cn("font-weight-medium")}>
          {!showOnlyLocaleLabel && label}
          <span className="font-weight-regular color-gray-1100">
            {language}
          </span>
        </label>
      </div>

      <div className={styles["input-container"]}>
        <Controller
          name={name}
          control={control}
          render={({ field }) => {
            return (
              <Radio
                {...field}
                id={`${name}-yes`}
                label={trueConditionLabel}
                value={value === true}
                checked={value === true}
                onChange={() => onChange(true)}
              />
            );
          }}
        />

        <Controller
          name={name}
          control={control}
          render={({ field }) => {
            return (
              <Radio
                {...field}
                id={`${name}-no`}
                label={falseConditionLabel}
                value={value === false}
                checked={value === false}
                onChange={() => onChange(false)}
              />
            );
          }}
        />
        {!hideClearButton && (
          <p
            onClick={() => onChange()}
            className={cn(
              styles["clear-button"],
              "text-body2",
              "color-blueViolet-100",
              "font-weight-medium"
            )}
          >
            Clear
          </p>
        )}
      </div>

      <div className="text-body2 color-2900 mb-3">{hint}</div>
    </div>
  );
};

export default RadioItem;
