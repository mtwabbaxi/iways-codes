import React, { useEffect } from "react";
import { Controller, useFormContext } from "react-hook-form";
import styles from "./appearanceDateTime.module.scss";
import cn from "classnames";
import SelectDropdown from "@/components/sharedComponents/selectDropdown";
import { formatOptions, timeModeOptions } from "@/utils/constants";

export default function AppearanceDateTime() {
  const {
    control,
    watch,
    setValue,
    formState: { errors, touchedFields },
  } = useFormContext();

  const { format } = watch();

  useEffect(() => {
    if (parseInt(format) <= 1) {
      setValue("time_mode", "1");
    }
  }, [format]);

  return (
    <div className={styles["container"]}>
      <div className={styles.fields}>
        <Controller
          name="format"
          control={control}
          render={({ field }) => (
            <SelectDropdown
              {...field}
              label="Format"
              required
              options={formatOptions.map((f) => ({
                name: f.name,
                value: f.id,
              }))}
              error={errors?.format?.message}
            />
          )}
        />
        {parseInt(format) > 1 && (
          <Controller
            name="time_mode"
            control={control}
            render={({ field }) => (
              <SelectDropdown
                {...field}
                options={timeModeOptions.map((t) => ({
                  name: t.name,
                  value: t.id,
                }))}
                label="Time mode"
                required
                error={errors?.time_mode?.message}
              />
            )}
          />
        )}
      </div>
    </div>
  );
}
