import { useState, useEffect } from "react";
import DropdownField from "@/components/shared/dropdownfield/dropdownfield";
import { TextField } from "@/components/theme/form-inputs";
import styles from "./allowedImageDimension.module.scss";

const AllowedImageDimension = ({ checked, values, onChange }) => {
  const [selectedLimitCharacter, setSelectedLimitCharacter] = useState({
    value: "ATLEAST",
  });

  const handleChange = (type, value) => {
    onChange(type, value);
  };

  const SELETE_LIMIT_CHARACTER = [
    {
      id: 1,
      children: [
        { id: 1, title: "At Least", value: "ATLEAST" },
        { id: 2, title: "At most", value: "NOT_MORE_THAN" },
        { id: 3, title: "Between", value: "BETWEEN" },
        { id: 4, title: "Exactly", value: "EXACTLY" },
      ],
    },
  ];

  useEffect(() => {
    handleChange("isActive", checked);
  }, [checked]);

  useEffect(() => {
    if (Boolean(selectedLimitCharacter?.value)) {
      handleChange("limitType", selectedLimitCharacter?.value);
    }
  }, [selectedLimitCharacter]);

  useEffect(() => {
    if (values?.limitType) {
      const isLimitType = SELETE_LIMIT_CHARACTER[0].children.find(
        (item) => item.value === values?.limitType
      );
      setSelectedLimitCharacter(isLimitType);
    }
  }, [values?.limitType]);

  return (
    <div
      className={
        selectedLimitCharacter?.value === "BETWEEN"
          ? styles.wrapper_limitCount
          : selectedLimitCharacter?.value === "ATLEAST"
            ? styles.wrapper_min_limitCount
            : selectedLimitCharacter?.value === "NOT_MORE_THAN"
              ? styles.wrapper_max_limitCount
              : styles.wrapper_limitCount
      }
    >
      <div className={styles.dropdown}>
        <DropdownField
          data={SELETE_LIMIT_CHARACTER}
          selectedvalue={selectedLimitCharacter}
          setSelectedValue={setSelectedLimitCharacter}
          disabled={!checked}
        />
      </div>

      {selectedLimitCharacter?.value === "EXACTLY" ? (
        <>
          <div>
            <TextField
              value={values?.exactly}
              type="number"
              onChange={(e) => handleChange("exactly", e.target.value)}
              placeholder="Exactly"
              disabled={!checked}
            />
          </div>
        </>
      ) : selectedLimitCharacter?.value === "NOT_MORE_THAN" ? (
        <>
          <div>
            <TextField
              value={values?.maximum}
              type="number"
              onChange={(e) => handleChange("maximum", e.target.value)}
              placeholder="Max"
              disabled={!checked}
            />
          </div>
        </>
      ) : selectedLimitCharacter?.value === "BETWEEN" ? (
        <>
          <div>
            <TextField
              value={values?.minimum}
              type="number"
              onChange={(e) => handleChange("minimum", e.target.value)}
              placeholder="Min"
              disabled={!checked}
            />
          </div>
          <div>
            <p>and</p>
          </div>

          <div>
            <TextField
              value={values?.maximum}
              type="number"
              onChange={(e) => handleChange("maximum", e.target.value)}
              placeholder="Max"
              disabled={!checked}
            />
          </div>
        </>
      ) : (
        <>
          <div>
            <TextField
              value={values?.minimum}
              type="number"
              onChange={(e) => handleChange("minimum", e.target.value)}
              placeholder="Min"
              disabled={!checked}
            />
          </div>
        </>
      )}
    </div>
  );
};

export default AllowedImageDimension;
