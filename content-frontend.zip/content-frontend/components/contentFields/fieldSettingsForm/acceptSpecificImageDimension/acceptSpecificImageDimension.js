import { useState, useEffect } from "react";
import styles from "./acceptSpecificImageDimension.module.scss";
import { AiOutlineUp, AiOutlineDown } from "react-icons/ai";
import AllowedImageDimension from "./allowedImageDimension";

const AcceptSpecificImageDimension = ({
  data,
  selectedValues,
  setSelectedValues,
  setSelectedImageDimensionValues,
  existValues,
}) => {
  if (!data) {
    return false;
  }

  const [widthValues, setWidthValues] = useState({
    minimum: "",
    maximum: "",
    exactly: "",
    limitType: "",
    isActive: false,
  });

  const [heightValues, setHeightValues] = useState({
    minimum: "",
    maximum: "",
    exactly: "",
    limitType: "",
    isActive: false,
  });

  if (!data) {
    return false;
  }

  const onWidthChangeHandler = (type, value) => {
    setWidthValues({ ...widthValues, [type]: value });
  };

  const onHeightChangeHandler = (type, value) => {
    setHeightValues({ ...heightValues, [type]: value });
  };

  const onChangeHandler = (selectedOption) => {
    const updatedValues = [...selectedValues];

    if (updatedValues.includes(selectedOption)) {
      updatedValues.splice(updatedValues.indexOf(selectedOption), 1);
    } else {
      updatedValues.push(selectedOption);
    }

    setSelectedValues(updatedValues);
  };

  useEffect(() => {
    const seletedData = [
      {
        title: "width",
        values: widthValues,
      },
      {
        title: "height",
        values: heightValues,
      },
    ];
    setSelectedImageDimensionValues(seletedData);
  }, [widthValues, heightValues]);

  useEffect(() => {
    const isWidthExistData =
      existValues &&
      existValues?.specifiedDimensionsValues?.dimensions?.find(
        (dimension) => dimension.type === "width"
      );
    const isHeightExistData =
      existValues &&
      existValues?.specifiedDimensionsValues?.dimensions?.find(
        (dimension) => dimension.type === "height"
      );
    if (isWidthExistData || isHeightExistData) {
      setSelectedValues([
        Boolean(isWidthExistData) && "width",
        Boolean(isHeightExistData) && "height",
      ]);

      setWidthValues(isWidthExistData);
      setHeightValues(isHeightExistData);
    }
  }, [existValues?.specifiedDimensionsValues?.dimensions]);

  return (
    <>
      <div className={styles.container}>
        <div className={styles.wrapper}>
          <div className={styles.checkboxContainer}>
            {data?.map((group, groupIndex) => (
              <div key={groupIndex} className={styles.groupContainer}>
                {group?.options?.map((option, optionIndex) => (
                  <div key={optionIndex} className={styles.checkboxOption}>
                    <input
                      type="checkbox"
                      id={option?.id}
                      value={option?.value}
                      checked={selectedValues.includes(option?.value)}
                      onChange={() => onChangeHandler(option?.value)}
                    />
                    <label htmlFor={option?.id}>{option?.label}</label>
                    <AllowedImageDimension
                      checked={option?.checked}
                      values={
                        option?.value === "width" ? widthValues : heightValues
                      }
                      onChange={
                        option?.value === "width"
                          ? onWidthChangeHandler
                          : onHeightChangeHandler
                      }
                    />
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default AcceptSpecificImageDimension;
