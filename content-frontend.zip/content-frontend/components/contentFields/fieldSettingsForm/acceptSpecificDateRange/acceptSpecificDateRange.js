import { useState, useEffect } from "react";
import styles from "./acceptSpecificDateRange.module.scss";
import DateTime_Selector from "./dateTimeSelector";

const AcceptSpecificDateRange = ({
  data,
  selectedValues,
  setSelectedValues,
  setSelectedDateRangeValues,
  customText_datetime,
  existValues,
}) => {
  const [laterThanValues, setLaterThanValues] = useState({
    date: "",
    time: "",
    timezone: "",
    isActive: false,
  });

  const [earlierThanValues, setEarlierThanValues] = useState({
    date: "",
    time: "",
    timezone: "",
    isActive: false,
  });

  if (!data) {
    return false;
  }

  const onLaterThanChangeHandler = (type, value) => {
    setLaterThanValues({ ...laterThanValues, [type]: value });
  };

  const onEarlierThanChangeHandler = (type, value) => {
    setEarlierThanValues({ ...earlierThanValues, [type]: value });
  };

  useEffect(() => {
    setSelectedValues(() => {
      if (existValues && existValues?.dateLimitValidation) {
        const { limitType } = existValues?.dateLimitValidation;

        if (limitType === "BETWEEN") {
          return ["later_than", "earlier_than"];
        } else if (limitType === "LATER_THAN") {
          return ["later_than"];
        } else if (limitType === "EARLIER_THAN") {
          return ["earlier_than"];
        }
      }

      return []; // Return an empty array if no valid limit type is found
    });
    if (existValues?.dateLimitValidation?.limitType === "LATER_THAN") {
      const { minimum } = existValues.dateLimitValidation;
      if (minimum) {
        const [date, time] = minimum.split("T");
        const [timeWithoutTimeZone] = time.split("+"); // Remove the time zone if present
        const [hour, minute, second] = timeWithoutTimeZone.split(":");

        setLaterThanValues({
          date: date,
          time: `${hour}:${minute}:${second}`,
          timezone: "",
          isActive: true,
        });
      }
    }
    if (existValues?.dateLimitValidation?.limitType === "EARLIER_THAN") {
      const { maximum } = existValues.dateLimitValidation;
      if (maximum) {
        const [date, time] = maximum.split("T");
        const [timeWithoutTimeZone] = time.split("+"); // Remove the time zone if present
        const [hour, minute, second] = timeWithoutTimeZone.split(":");

        setEarlierThanValues({
          date: date,
          time: `${hour}:${minute}:${second}`,
          timezone: "",
          isActive: true,
        });
      }
    }
    if (existValues?.dateLimitValidation?.limitType === "BETWEEN") {
      const { minimum, maximum } = existValues.dateLimitValidation;
      if (minimum) {
        const [mindate, mintime] = minimum.split("T");
        const [timeWithoutTimeZone] = mintime.split("+"); // Remove the time zone if present
        const [hour, minute, second] = timeWithoutTimeZone.split(":");

        setLaterThanValues({
          date: mindate,
          time: `${hour}:${minute}:${second}`,
          timezone: "",
          isActive: true,
        });
      }

      if (maximum) {
        const [maxdate, maxtime] = maximum.split("T");
        const [maxTimeWithoutTimeZone] = maxtime.split("+"); // Remove the time zone if present
        const [hour_max, minute_max, second_max] =
          maxTimeWithoutTimeZone.split(":");

        setEarlierThanValues({
          date: maxdate,
          time: `${hour_max}:${minute_max}:${second_max}`,
          timezone: "",
          isActive: true,
        });
      }
    }
  }, [existValues]);

  useEffect(() => {
    let dateTimeValidation =
      laterThanValues?.isActive || earlierThanValues?.isActive ? true : false;
    let dateLimitValidation = {};

    // Get today's date in the format yyyy-MM-dd
    const todayDate = new Date().toISOString().slice(0, 10);
    const dateTime_later =
      `${laterThanValues?.date ? laterThanValues?.date : todayDate}` +
      `${laterThanValues?.time && "T"}` +
      `${laterThanValues?.time ? laterThanValues?.time : "T00:00:00"}`;

    const dateTime_earlier =
      `${earlierThanValues?.date ? earlierThanValues?.date : todayDate}` +
      `${earlierThanValues?.time && "T"}` +
      `${earlierThanValues?.time ? earlierThanValues?.time : "T00:00:00"}`;

    // Check if both laterThanValues and earlierThanValues are active
    if (laterThanValues?.isActive && earlierThanValues?.isActive) {
      dateLimitValidation = {
        limitType: "BETWEEN",
        minimum: laterThanValues?.isActive ? dateTime_later : "",
        maximum: earlierThanValues?.isActive ? dateTime_earlier : "",
        customErrorMessage: customText_datetime,
      };
    } else if (laterThanValues?.isActive) {
      dateLimitValidation = {
        limitType: "LATER_THAN",
        minimum: laterThanValues?.isActive ? dateTime_later : "",
        maximum: earlierThanValues?.isActive ? dateTime_earlier : "",
        customErrorMessage: customText_datetime,
      };
    } else if (earlierThanValues?.isActive) {
      dateLimitValidation = {
        limitType: "EARLIER_THAN",
        minimum: laterThanValues?.isActive ? dateTime_later : "",
        maximum: earlierThanValues?.isActive ? dateTime_earlier : "",
        customErrorMessage: customText_datetime,
      };
    } else {
      dateLimitValidation = {};
    }

    setSelectedDateRangeValues({ dateTimeValidation, dateLimitValidation });
  }, [laterThanValues, earlierThanValues, customText_datetime]);

  const onChangeHandler = (selectedOption) => {
    const updatedValues = [...selectedValues];

    if (updatedValues.includes(selectedOption)) {
      updatedValues.splice(updatedValues.indexOf(selectedOption), 1);
    } else {
      updatedValues.push(selectedOption);
    }

    setSelectedValues(updatedValues);
  };

  return (
    <>
      <div className={styles.container}>
        <div className={styles.wrapper}>
          <div className={styles.checkboxContainer}>
            {data?.map((group, groupIndex) => (
              <div key={groupIndex} className={styles.groupContainer}>
                {group?.options?.map((option, optionIndex) => (
                  <div key={optionIndex} className={styles.checkboxOption}>
                    <input
                      type="checkbox"
                      id={option?.id}
                      value={option?.value}
                      checked={selectedValues.includes(option?.value)}
                      onChange={() => onChangeHandler(option?.value)}
                    />
                    <label className={styles?.heading} htmlFor={option?.id}>
                      {option?.label}
                    </label>
                    <DateTime_Selector
                      checked={option?.checked}
                      valuesSelected={
                        option?.value === "later_than"
                          ? laterThanValues
                          : earlierThanValues
                      }
                      onChange={
                        option?.value === "later_than"
                          ? onLaterThanChangeHandler
                          : onEarlierThanChangeHandler
                      }
                    />
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default AcceptSpecificDateRange;
