import React, { useEffect, useMemo, useState } from "react";
import { format, parseISO, parse, addMinutes, setHours } from "date-fns";
import "./index.modules.scss";
import cn from "classnames";
import ErrorEl from "@/components/shared/error";
import { timeOptions, timeZoneOptions } from "@/utils/constants";
import { Controller, useFormContext } from "react-hook-form";
import SelectDropdown from "@/components/sharedComponents/selectDropdown";
import FieldNameForm from "@/components/contentFields/fieldNameForm/fieldNameForm";
import { TextField } from "@/components/theme/form-inputs";

const DateTime_Selector = ({
  label,
  required,
  size = "md",
  hint,
  error,
  value,
  localized = false,
  language = "English (United States) (en-US)",
  name = "default_value",
  contentEntry = false,
  details = {},
  checked,
  valuesSelected,
  onChange,
  ...rest
}) => {
  const [formattedValue, setFormattedValue] = useState("");
  const [timeInput, setTimeInput] = useState("");
  const [utcFormat, setUtcFormat] = useState("");
  const {
    setValue = () => {},
    clearErrors = () => {},
    watch = () => {},
  } = useFormContext() || {};

  // const values = watch() || {};
  const { time_mode, format: formatFieldValue } = details;

  const handleChange = (type, value) => {
    onChange(type, value);
  };

  useEffect(() => {
    if (checked) {
      setFormattedValue(valuesSelected?.date);
      setTimeInput(valuesSelected?.time);
    }
  }, [valuesSelected]);

  useEffect(() => {
    if (formattedValue !== "") {
      handleChange("date", formattedValue);
    }
  }, [formattedValue]);

  useEffect(() => {
    if (timeInput !== "") {
      handleChange("time", timeInput);
    }
  }, [timeInput]);

  useEffect(() => {
    if (utcFormat !== "") {
      handleChange("timezone", utcFormat);
    }
  }, [utcFormat]);

  useEffect(() => {
    handleChange("isActive", checked);
  }, [checked]);

  function convertToAMPM(timeString) {
    if (!timeString) {
      setTimeInput("");
      return "";
    }
    // Validate input time format
    const timeRegex = /^([01]?\d|2[0-3]):([0-5]\d)(?: ([APMapm]{2}))?$/; // HH:mm or HH:mm AM/PM format
    const match = timeString.match(timeRegex);

    if (!match) {
      console.error(
        "Invalid time format. Please use the HH:mm or HH:mm AM/PM format."
      );
      setTimeInput("12:00 AM");
      return null;
    }

    // Extract hours, minutes, and AM/PM from the input
    const [hours, minutes, ampm] = match.slice(1);

    // Convert to 12-hour format
    let hours12 = parseInt(hours, 10);
    const isPM = ampm && ampm.toLowerCase() === "pm";

    if (hours12 === 12 || hours12 === 0) {
      // Handle midnight and noon
      hours12 = 12;
    } else if (isPM) {
      // Handle PM hours (after noon)
      hours12 += 12;
    }

    // Determine AM or PM
    let resultAMPM = hours12 > 12 ? "PM" : "AM";
    if (hours12 === 12 && isPM) {
      resultAMPM = "PM";
    }

    // Convert to 12-hour format
    const formattedHours = hours12 % 12 || 12;

    // Return the time in AM/PM format
    setTimeInput(`${formattedHours}:${minutes} ${resultAMPM}`);
  }

  function convertTo24HoursFormat(timeString, set = true) {
    if (!timeString) {
      if (set) {
        setTimeInput("");
      }
      return "";
    }
    const regexWithMeridiem = /^(0?[1-9]|1[0-2]):[0-5]\d\s?[APMapm]{2}$/;
    const regexWithoutMeridiem = /^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5]\d$/;

    const matchWithMeridiem = timeString.match(regexWithMeridiem);
    const matchWithoutMeridiem = timeString.match(regexWithoutMeridiem);

    if (matchWithMeridiem) {
      const [time, meridiem] = matchWithMeridiem[0].split(/\s+/);
      const [hours, minutes] = time.split(":");
      let formattedHours;

      if (meridiem?.toLowerCase() === "am" && hours === "12") {
        formattedHours = "00";
      } else if (meridiem?.toLowerCase() === "pm" && hours !== "12") {
        formattedHours = String(Number(hours) + 12);
      } else {
        formattedHours = hours.padStart(2, "0");
      }

      const formattedTime = `${formattedHours}:${minutes}`;
      if (set) {
        setTimeInput(formattedTime);
      } else {
        return formattedTime;
      }
    } else if (matchWithoutMeridiem) {
      const [hours, minutes] = matchWithoutMeridiem[0].split(":");
      const formattedTime = `${hours.padStart(2, "0")}:${minutes}`;
      if (set) {
        setTimeInput(formattedTime);
      } else {
        return formattedTime;
      }
    } else {
      if (set) {
        setTimeInput("00:00");
      } else {
        return "00:00";
      }
    }
  }

  function isValidTimeFormat(input) {
    const timeRegex = /^(0?[1-9]|1[0-9]|2[0-3]):[0-5][0-9]( [APap][mM])?$/;
    return timeRegex.test(input);
  }

  useEffect(() => {
    if (!formattedValue) {
      setValue(name, "");
      return;
    }

    // Parse date
    const inputDate = new Date(parse(formattedValue, "yyyy-MM-dd", new Date()));

    let combinedDateTime = new Date(
      inputDate.getFullYear(),
      inputDate.getMonth(),
      inputDate.getDate()
    );

    // Check if time is provided
    if (timeInput && isValidTimeFormat(timeInput)) {
      const timeString24 = convertTo24HoursFormat(timeInput, false);
      const [hours, minutes] = timeString24.split(":").map((n) => n);
      combinedDateTime = new Date(combinedDateTime);
      combinedDateTime.setHours(hours, minutes, 0);
    }

    // Check if UTC is provided
    if (utcFormat) {
      const inputUTC = parseInt(utcFormat, 10);
      // Adjust for the UTC offset
      combinedDateTime = addMinutes(combinedDateTime, -inputUTC);
      if (!timeInput) {
        combinedDateTime.setHours(0, 0, 0);
      }
    }

    const field = contentEntry ? name + " - details" : "details";

    if (!utcFormat && !timeInput) {
      const onlyDate = format(combinedDateTime, "yyyy-MM-dd");
      setValue(name, onlyDate);
      clearErrors(name);
      setValue(field, {
        ...details,
        utcFormat: "",
        timeInput: "",
        date: formattedValue,
      });
    } else {
      setValue(name, combinedDateTime);
      setValue(field, {
        ...details,
        utcFormat,
        timeInput,
        date: formattedValue,
      });
      clearErrors(name);
    }
  }, [formattedValue, utcFormat, timeInput]);

  useEffect(() => {
    if (!contentEntry) {
      //whenever time mode is changed empty the time field
      setTimeInput("");
    }
  }, [time_mode, contentEntry]);

  useEffect(() => {
    if (
      details?.timeInput &&
      parseInt(details?.format) > 1 &&
      details?.time_mode
    ) {
      if (details?.time_mode === "1") {
        convertToAMPM(details?.timeInput);
      } else if (time_mode === "2") {
        convertTo24HoursFormat(details?.timeInput);
      }
    }

    if (details?.utcFormat && details?.format === "3") {
      setUtcFormat(details?.utcFormat);
    }
    if (details?.date) {
      setFormattedValue(details?.date);
    }
  }, [details?.timeInput, details?.utcFormat, details?.date]);

  return (
    <div className="custom-date-field-wrapper">
      <div className="input-container">
        <div>
          <label className={cn("font-weight-medium")}>Date</label>
          <input
            {...rest}
            type="date"
            value={formattedValue}
            onChange={(e) => setFormattedValue(e.target.value)}
            className={cn("date-input", !checked && "disabled")}
            disabled={!checked}
          />
        </div>

        {/* <div className={cn(!checked && "disabled")}>
          <TextField
            type="text"
            onBlur={() => convertToAMPM(timeInput)}
            onChange={(e) => setTimeInput(e.target.value)}
            value={timeInput}
            placeholder="12:00 AM"
            label="Time"
            disabled={!checked}
          />
        </div> */}

        <SelectDropdown
          aria-label="Select time"
          className={cn("utc-select", !checked && "disabled")}
          value={timeInput}
          onChange={(e) => setTimeInput(e.target.value)}
          options={timeOptions.map((option) => ({
            value: option.value,
            name: option.label,
          }))}
          label="Time"
          disabled={!checked}
        />

        <SelectDropdown
          aria-label="Select timezone"
          className={cn("utc-select", !checked && "disabled")}
          value={utcFormat}
          onChange={(e) => setUtcFormat(e.target.value)}
          options={timeZoneOptions.map((option) => ({
            value: option.value,
            name: option.label,
          }))}
          label="Timezone"
          disabled={!checked}
        />
      </div>
    </div>
  );
};

export default DateTime_Selector;
