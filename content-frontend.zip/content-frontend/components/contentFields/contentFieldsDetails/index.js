import TableFields from "@/components/contentModel/tableFields";

export default function ContentFieldsDetails() {
  const data = [
    {
      name: "Title",
      fieldType: "Short text",
      entryTitle: true,
    },
    {
      name: "Description",
      fieldType: "Rich text",
    },
    {
      name: "Image",
      fieldType: "Media, many files",
    },
    {
      name: "dropdown",
      fieldType: "Short text",
    },
  ];
  return (
    <>
      <TableFields header="testing" data={data} />
    </>
  );
}
