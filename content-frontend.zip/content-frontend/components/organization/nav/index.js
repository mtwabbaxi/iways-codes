import React from "react";
import styles from "./nav.module.scss";
import cn from "classnames";

export default function Nav({ icon: Icon, title, actions }) {
  return (
    <div className={styles["nav-container"]}>
      <div className={styles["title-container"]}>
        {Icon && <Icon size="20px" />}
        <p className={cn("font-weight-semi-bold")}>{title}</p>
      </div>
      {actions && <div className={styles.actions}>{actions}</div>}
    </div>
  );
}
