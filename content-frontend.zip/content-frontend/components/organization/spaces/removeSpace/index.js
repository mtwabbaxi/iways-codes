import React, { useState } from "react";
import cn from "classnames";
import styles from "./removeSpace.module.scss";
import { TextField } from "@/components/theme/form-inputs";
import { Button } from "@/components/theme/buttons";
import { useDispatch } from "react-redux";
import { deleteSpace, fetchAllSpaces } from "@/store/actions/spaces";
import { useToast } from "@/context/toastContext";

export default function RemoveSpace({ data = {}, onClose = () => {} }) {
  const [spaceName, setSpaceName] = useState("");
  const dispatch = useDispatch();
  const { addToast } = useToast();
  const [loading, setLoading] = useState(false);

  const handleDelete = async () => {
    setLoading(true);
    const res = await dispatch(deleteSpace(data.spaceId));
    const {
      result: { body = {} },
    } = res || {};
    if (body?.responseCode === 200) {
      setLoading(false);
      dispatch(fetchAllSpaces());
      addToast(body.responseMessage);
      onClose();
    } else {
      setLoading(false);
      addToast(body?.responseMessage || "An unknown error occurred!", {
        type: "error",
      });
    }
  };

  return (
    <div className={styles["remove-space-container"]}>
      <p>
        You are about to remove the space{" "}
        <span className={cn("font-weight-semi-bold")}>{data.title}</span>.
      </p>
      <p className="mt-2">
        All space contents and the space itself will be removed. This operation
        cannot be undone.
      </p>
      <p className="mt-2">A Intro space license will become available.</p>
      <p className="mt-2">
        To confirm, type the name of the space in the field below:
      </p>
      <TextField
        value={spaceName}
        onChange={(e) => setSpaceName(e.target.value)}
      />
      <div className={styles.actions}>
        <Button
          disabled={loading}
          onClick={onClose}
          variant="default"
          text="Cancel"
        />
        <Button
          onClick={handleDelete}
          disabled={!(data.title === spaceName) || loading}
          variant="primary"
          text="Remove"
        />
      </div>
    </div>
  );
}
