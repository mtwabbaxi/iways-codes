"use client";
import { DataTable } from "@/components/theme/datatable";
import React, { useDebugValue, useEffect, useRef, useState } from "react";
import styles from "./details.module.scss";
import { IoIosSettings } from "react-icons/io";
import { RxDotsHorizontal } from "react-icons/rx";
import { useOutsideClick } from "@/hooks/useOutsideClick";
import Modal from "@/components/shared/modal";
import RemoveSpace from "../removeSpace";
import { useDispatch, useSelector } from "react-redux";
import { fetchAllSpaces } from "@/store/actions/spaces";
import { fetchAllSubscriptionPlan } from "@/store/actions/subscriptionplan";

const Actions = ({ data }) => {
  const [openMenu, setOpenMenu] = useState(false);
  const [openDeleteModal, setOpenDeleteModal] = useState(false);
  const ref = useRef();
  useOutsideClick(ref, () => setOpenMenu(false));

  const handleCloseDeleteModal = () => setOpenDeleteModal(false);
  const handleOpenDeleteModal = () => setOpenDeleteModal(true);

  return (
    <>
      <div ref={ref} className={styles["dropdown-container"]}>
        <RxDotsHorizontal onClick={() => setOpenMenu(!openMenu)} />
        {openMenu && (
          <div className={styles["option-container"]}>
            <p className={styles["single-option"]}>Detailed usage</p>
            <p
              onClick={handleOpenDeleteModal}
              className={styles["single-option"]}
            >
              Delete
            </p>
          </div>
        )}
      </div>
      {openDeleteModal && (
        <Modal heading="Remove space" onClose={handleCloseDeleteModal}>
          <RemoveSpace onClose={handleCloseDeleteModal} data={data} />
        </Modal>
      )}
    </>
  );
};

export default function Details() {
  const dispatch = useDispatch();

  const { allSpaces } = useSelector((state) => state.spaces);
  const { allSubscriptionPlans = [] } =
    useSelector((state) => state.subscriptionPlans) || {};
  const [subscribedDetails, setSubscribedDetails] = useState({});

  useEffect(() => {
    if (allSpaces?.content?.length && allSubscriptionPlans?.content?.length) {
      const details = allSubscriptionPlans?.content?.find(
        (s) => s.subscriptionPlanId === allSpaces?.content[0].subscriptionId
      );

      setSubscribedDetails(details);
    } else {
      setSubscribedDetails({});
    }
  }, [allSpaces, allSubscriptionPlans]);

  useEffect(() => {
    if (dispatch) {
      dispatch(fetchAllSpaces());
      dispatch(fetchAllSubscriptionPlan());
    }
  }, [dispatch]);

  const columns = [
    {
      title: "Name",
      key: "Name",
      styles: {
        paddingLeft: "0.5rem",
        width: "1%",
      },
      render: (data) => <p>{data?.title || ""}</p>,
    },
    {
      title: "License type",
      key: "License type",
      styles: {
        paddingLeft: "0.5rem",
        width: "1%",
      },
      render: (data) => <p>{subscribedDetails?.name || ""}</p>,
    },
    {
      title: "Environments",
      key: "Environments",
      styles: {
        paddingLeft: "0.5rem",
        width: "1%",
      },
      render: (data) => (
        <p>
          {data?.usage?.spaceEnvironment || 0}/
          {data?.upperLimits?.spaceEnvironment || 0}
        </p>
      ),
    },
    {
      title: "Content types",
      key: "Content types",
      styles: {
        paddingLeft: "0.5rem",
        width: "1%",
      },
      render: (data) => (
        <p>
          {data?.usage?.contentModel || 0}/
          {data?.upperLimits?.contentModel || 0}
        </p>
      ),
    },
    {
      title: "Records",
      key: "Records",
      styles: {
        paddingLeft: "0.5rem",
        width: "1%",
      },
      render: (data) => (
        <p>
          {(data?.usage?.mediaAsset || 0) + (data?.usage.contentEntry || 0)}/
          {(data?.upperLimits?.mediaAsset || 0) +
            (data?.upperLimits.contentEntry || 0)}
        </p>
      ),
    },
    {
      title: <IoIosSettings size="20px" />,
      key: "Records",
      styles: {
        paddingLeft: "0.5rem",
        width: "1%",
      },
      render: (data) => <Actions data={data} />,
    },
  ];

  return (
    <div className={styles.details}>
      <DataTable
        columns={columns}
        dataSource={allSpaces?.content?.length > 0 ? allSpaces?.content : []}
      />
    </div>
  );
}
