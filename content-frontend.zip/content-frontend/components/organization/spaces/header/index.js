"use client";
import React, { useState } from "react";
import styles from "./header.module.scss";
import cn from "classnames";
import Link from "next/link";
import Nav from "../../nav";
import { TiFolderOpen } from "react-icons/ti";
import { Button } from "@/components/theme/buttons";
import AddSpaceForm from "@/components/layout/topNav/addSpaceForm/addSpaceForm";
import Modal from "@/components/shared/modal";

export default function Header() {
  const [openModal, setOpenModal] = useState(false);

  const handleCloseModal = () => setOpenModal(false);
  const handleOpenModal = () => setOpenModal(true);

  return (
    <>
      <Nav
        icon={TiFolderOpen}
        title="Spaces"
        actions={
          <>
            <Button onClick={handleOpenModal} text="Add new space" />
          </>
        }
      />
      <div className={styles.container}>
        <p className={cn("font-weight-semi-bold", "text-h5")}>Space</p>
        <p className={cn("mt-5", styles.description)}>
          A Space is a workspace that contains all your Content Types, Entries,
          and Assets for a project. <br />
          Your organization is on Free Plan. To upgrade your Space to Medium
          Licenses, get{" "}
          <Link
            className={cn("color-blueViolet-100", "font-weight-semi-bold")}
            href="#"
          >
            Basic Plan now!
          </Link>
        </p>
      </div>
      {openModal && (
        <Modal heading="Add New Space" onClose={handleCloseModal}>
          <AddSpaceForm setAddSpacePopupOpen={handleCloseModal} />
        </Modal>
      )}
    </>
  );
}
