"use client";
import { DataTable } from "@/components/theme/datatable";
import React, { useEffect, useState } from "react";
import styles from "./details.module.scss";
import { useDispatch, useSelector } from "react-redux";
import { fetchAllSpaces } from "@/store/actions/spaces";
import { fetchAllSubscriptionPlan } from "@/store/actions/subscriptionplan";

export default function Details() {
  const dispatch = useDispatch();
  const columns = [
    {
      title: "License type",
      key: "License type",
      styles: {
        paddingLeft: "0.5rem",
        width: "1%",
      },
      render: (data) => <p>{data?.name}</p>,
    },
    {
      title: "Environments",
      key: "Environments",
      styles: {
        paddingLeft: "0.5rem",
        width: "1%",
      },
      render: (data) => <p>{data?.limits?.spaceEnvironment || 0}</p>,
    },
    {
      title: "Content types",
      key: "Content types",
      styles: {
        paddingLeft: "0.5rem",
        width: "1%",
      },
      render: (data) => <p>{data?.limits?.contentModel || 0}</p>,
    },
    {
      title: "Records",
      key: "Records",
      styles: {
        paddingLeft: "0.5rem",
        width: "1%",
      },
      render: (data) => (
        <p>
          {data?.limits?.mediaAsset || data?.limits?.contentEntry
            ? data?.limits?.mediaAsset + data?.limits?.contentEntry
            : 0}
        </p>
      ),
    },
    {
      title: "Monthly price",
      key: "Monthly price",
      styles: {
        paddingLeft: "0.5rem",
        width: "1%",
      },
      render: () => <p>0$</p>,
    },
    {
      title: "Assigned",
      key: "Assigned",
      styles: {
        paddingLeft: "0.5rem",
        width: "1%",
      },
      render: () => <p>1/1</p>,
    },
    {
      title: "Monthly total",
      key: "Monthly total",
      styles: {
        paddingLeft: "0.5rem",
        width: "1%",
      },
      render: () => <p>0$</p>,
    },
  ];
  const { allSpaces = [] } = useSelector((state) => state.spaces) || {};
  const { allSubscriptionPlans = [] } =
    useSelector((state) => state.subscriptionPlans) || {};
  const [subscribedDetails, setSubscribedDetails] = useState({});

  useEffect(() => {
    if (dispatch) {
      dispatch(fetchAllSpaces());
      dispatch(fetchAllSubscriptionPlan());
    }
  }, [dispatch]);

  useEffect(() => {
    if (allSpaces?.content?.length && allSubscriptionPlans?.content?.length) {
      const details = allSubscriptionPlans?.content?.find(
        (s) => s.subscriptionPlanId === allSpaces?.content[0].subscriptionId
      );

      setSubscribedDetails(details);
    } else {
      setSubscribedDetails({});
    }
  }, [allSpaces, allSubscriptionPlans]);

  return (
    <div className={styles.details}>
      <DataTable
        columns={columns}
        dataSource={
          Object.keys(subscribedDetails).length ? [subscribedDetails] : []
        }
      />
    </div>
  );
}
