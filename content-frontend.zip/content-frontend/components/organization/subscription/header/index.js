import React from "react";
import styles from "./header.module.scss";
import cn from "classnames";
import Link from "next/link";
import Nav from "../../nav";
import { MdOutlineAddShoppingCart } from "react-icons/md";
import { Button } from "@/components/theme/buttons";

export default function Header() {
  return (
    <>
      <Nav
        icon={MdOutlineAddShoppingCart}
        title="Subscription"
        actions={
          <div className={styles.actions}>
            <Button text="Contact us" />
            <Button text="Change Plan" />
          </div>
        }
      />
      <div className={styles.container}>
        <p className={cn("font-weight-semi-bold", "text-h5")}>Space licenses</p>
        <p className={cn("mt-5", styles.description)}>
          Buying a larger Space License expands the number of available content
          types, records, environments and others, for each{" "}
          <Link
            className={cn("color-blueViolet-100", "font-weight-semi-bold")}
            href="#"
          >
            Space
          </Link>{" "}
          in your organization. <br />
          To buy Medium and larger Space Licenses, please{" "}
          <Link
            className={cn("color-blueViolet-100", "font-weight-semi-bold")}
            href="#"
          >
            upgrade to Basic Plan.
          </Link>
        </p>
      </div>
    </>
  );
}
