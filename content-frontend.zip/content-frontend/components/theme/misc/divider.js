import styles from "./divider.module.scss";

const Divider = () => {
  return <div className={styles.divider} />;
};

export { Divider };
