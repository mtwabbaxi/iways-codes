"use client";

import { useState } from "react";
import styles from "./tabs.module.scss";
import { Button } from "@/components/theme/buttons";
import cn from "classnames";
import Link from "next/link";
import { APP_URLS, replaceUrlParams } from "@/utils/constants";
import { useParams } from "next/navigation";

const Tabs = ({ tabs = [], direction = "horizontal", onTabClick, ...rest }) => {
  const [activeIndex, setActiveIndex] = useState(0);

  const handleClick = (index) => {
    setActiveIndex(index);
    if (onTabClick) {
      onTabClick(index);
    }
  };

  return (
    <div className={cn(styles.container, styles[direction])}>
      {tabs.map((m, i) => {
        if (m.url) {
          return (
            <Link href={m.url}>
              <Button
                onClick={() => handleClick(i)}
                text={m.title}
                active={i === activeIndex}
                key={m.title}
                {...rest}
                fullWidth
                textAlign="left"
              />
            </Link>
          );
        }
        return (
          <Button
            onClick={() => handleClick(i)}
            text={
              Boolean(m.icon) ? (
                <>
                  <span className={styles.icon}>{m.icon}</span>
                  <span>{m.title}</span>
                </>
              ) : (
                m.title
              )
            }
            active={i === activeIndex}
            className={i === activeIndex ? styles.active : ""}
            key={m.title}
            {...rest}
          />
        );
      })}
    </div>
  );
};

export { Tabs };
