"use client";

import { useMemo } from "react";
import cn from "classnames";
import styles from "./alert.module.scss";
import {
  AiFillInfoCircle,
  AiFillWarning,
  AiFillCheckCircle,
} from "react-icons/ai";
import { BiSolidErrorCircle } from "react-icons/bi";

const Alert = ({
  text = "",
  variant = "info",
  heading = "",
  className = "",
}) => {
  const icon = useMemo(() => {
    switch (variant) {
      case "success":
        return (
          <AiFillCheckCircle size="1.2em" className="color-bluishGreen-500" />
        );
      case "warning":
        return <AiFillWarning size="1.2em" className="color-orange-400" />;
      case "error":
        return (
          <BiSolidErrorCircle size="1.2em" className="color-scarletRed-300" />
        );
      default:
      case "info":
        return <AiFillInfoCircle size="1.2em" className="color-blue-500" />;
    }
  }, [variant]);

  return (
    <article
      className={cn(
        styles.container,
        "text-body2 color-gray-2900",
        styles[variant],
        className
      )}
    >
      {icon}
      <div>
        {heading && (
          <div className="text-body1 color-gray-2900 font-weight-semi-bold mb-2">
            {heading}
          </div>
        )}
        <div>{text}</div>
      </div>
    </article>
  );
};

export { Alert };
