import React from "react";
import styles from "./chips.module.scss";
import { IoMdClose } from "react-icons/io";
import cn from "classnames";

export default function Chips({
  value,
  handleDelete = () => {},
  noIcon = false,
}) {
  return (
    <div className={styles.container}>
      <div className={styles.main}>
        <span
          className={cn("text-body2", styles.value, {
            [styles["no-border"]]: noIcon,
          })}
        >
          {value}
        </span>
        {!noIcon && (
          <span className={styles.close}>
            <IoMdClose onClick={handleDelete} />
          </span>
        )}
      </div>
    </div>
  );
}
