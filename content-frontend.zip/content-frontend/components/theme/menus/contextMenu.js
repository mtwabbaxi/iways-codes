"use client";

import { useState, useCallback, useRef } from "react";
import styles from "./contextMenu.module.scss";
import { IconButton, Button } from "@/components/theme/buttons";
import { FaEllipsis } from "react-icons/fa6";
import { useOutsideClick } from "@/hooks/useOutsideClick";
import cn from "classnames";

const ContextMenu = ({ variant = "default", options = [], align = "left" }) => {
  const [open, setOpen] = useState(false);

  const handleToggle = useCallback(() => {
    setOpen((o) => !o);
  }, []);
  const handleClose = useCallback(() => {
    setOpen(false);
  }, []);

  const ref = useRef(null);
  useOutsideClick(ref, handleClose);

  return (
    <div className={styles.container} ref={ref}>
      <IconButton icon={FaEllipsis} variant={variant} onClick={handleToggle} />
      {open && (
        <div className={cn(styles.dropdown, styles[align])}>
          {options.map((m) => (
            <Button
              key={m.id}
              variant={variant}
              text={m.title}
              onClick={() => {
                if (m.onClick) {
                  m.onClick();
                  if (!m.keepOnOnClick) {
                    setOpen(false);
                  }
                }
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export { ContextMenu };
