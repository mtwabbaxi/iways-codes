import { Label } from "./label";

export { Label };
