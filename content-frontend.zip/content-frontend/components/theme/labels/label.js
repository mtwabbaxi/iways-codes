import { useMemo } from "react";
import cn from "classnames";
import styles from "./label.module.scss";

const Label = ({ text, size = "sm", variant = "default" }) => {
  const fontClass = useMemo(() => {
    switch (size) {
      case "sm":
      default:
        return "text-caption font-weight-semi-bold";
    }
  }, [size]);
  return (
    <span
      className={cn(fontClass, styles.label, styles[variant], styles[size])}
    >
      {text}
    </span>
  );
};

export { Label };
