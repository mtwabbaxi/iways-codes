import React, { useState } from "react";
import styles from "./toolTip.module.scss";
import cn from "classnames";

const ToolTip = ({
  text,
  direction = "top",
  children,
  className,
  textClassName = "",
}) => {
  return (
    <div
      className={cn(styles["tooltip-container"], {
        [styles["direction-right"]]: direction === "right",
      })}
    >
      <div
        className={cn(
          styles["tooltip-text"],
          [styles[direction]],
          "text-caption",
          textClassName
        )}
      >
        {text}
      </div>

      {children}
    </div>
  );
};

export default ToolTip;
