"use client";

import React, { useState, useEffect } from "react";
import styles from "./datatable.module.scss";
import TablePlaceholder from "./placeholder";
import Loader from "@/components/shared/skeletonLoading";
import { useSelector } from "react-redux";

const getData = (key, keyIndex, row, rowIndex) => {
  if (key.dataIndex) {
    if (key.dataIndex.indexOf(".") > -1) {
      const properties = key.dataIndex.split(".");
      let actualValue = row;
      properties.map((property) => {
        if (actualValue && actualValue[property]) {
          return (actualValue = actualValue[property]);
        } else {
          return (actualValue = null);
        }
      });
      return actualValue;
    } else {
      return row[key.dataIndex];
    }
  } else {
    return key.render(row);
  }
};

const DataTable = (props) => {
  const {
    headerLinks,
    title,
    rowClickHandler = () => {},
    noHeader,
    link = "",
  } = props;
  const [state, setState] = useState({
    dataSource: [],
    columns: [],
  });
  const { loading } = useSelector((state) => state.contentModel);
  useEffect(() => {
    setState({ columns: props.columns, dataSource: props.dataSource });
  }, [props]);
  const { columns, dataSource = [] } = state;

  if (loading) {
    return <Loader />;
  }

  return (
    <div className={`${styles.wrapper}`}>
      <table className={styles.table}>
        <thead>
          <tr>
            {columns.map((col, colIndex) => (
              <th
                className="text-caption color-gray-1500 font-weight-semi-bold"
                style={col.styles ? { ...col.styles } : {}}
                key={`col-${colIndex}`}
              >
                {col.title}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {dataSource.map((row, rowIndex) => (
            <tr
              className={`${props.rowClickHandler ? styles.clickable : ""}`}
              key={`row-${rowIndex}`}
            >
              {columns.map((col, colIndex) => {
                if (col.key === "actions") {
                  return (
                    <td
                      className="text-body2"
                      style={col.styles ? { ...col.styles } : {}}
                      key={`row-${rowIndex}-col-${colIndex}`}
                    >
                      {getData(col, colIndex, row, rowIndex)}
                    </td>
                  );
                } else {
                  return (
                    <td
                      className="text-body2"
                      style={col.styles ? { ...col.styles } : {}}
                      key={`row-${rowIndex}-col-${colIndex}`}
                      onClick={
                        rowClickHandler
                          ? () => rowClickHandler(row, rowIndex)
                          : () => {}
                      }
                    >
                      {getData(col, colIndex, row, rowIndex)}
                    </td>
                  );
                }
              })}
            </tr>
          ))}
        </tbody>
      </table>
      {!dataSource || !dataSource.length ? <TablePlaceholder /> : null}
    </div>
  );
};

export { DataTable };
