import cn from "classnames";
import { TbTableFilled } from "react-icons/tb";
import styles from "./placeholder.module.scss";

const TablePlaceholder = () => {
  return (
    <div className={cn(styles.placeholder, "color-gray-700")}>
      <TbTableFilled size="3em" className={styles.icon} />
      <p className="text-body2">No data</p>
    </div>
  );
};

export default TablePlaceholder;
