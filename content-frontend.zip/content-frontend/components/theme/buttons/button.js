import { useMemo } from "react";
import cn from "classnames";
import styles from "./button.module.scss";

const Button = ({
  text,
  type = "button",
  size = "md",
  variant = "secondary",
  className = "",
  active,
  startIcon: StartIcon,
  endIcon: EndIcon,
  fullWidth,
  disabled,
  textAlign = "center",
  loading,
  ...rest
}) => {
  const fontClass = useMemo(() => {
    switch (size) {
      case "sm":
        return "text-caption";
      case "lg":
        return "text-body1";
      case "md":
      default:
        return "text-body2";
    }
  });

  return (
    <button
      type={type}
      className={cn(
        styles.button,
        styles[size],
        styles[variant],
        styles[`text-${textAlign}`],
        fontClass,
        {
          [styles.active]: active,
          [styles["full-width"]]: fullWidth,
        },
        className
      )}
      {...rest}
      disabled={disabled || loading}
    >
      {StartIcon && (
        <span className={cn(styles["start-icon"], styles.icon)}>
          {<StartIcon />}
        </span>
      )}
      {loading ? "Please wait ..." : text}
      {EndIcon && (
        <span className={cn(styles["end-icon"], styles.icon)}>
          {<EndIcon />}
        </span>
      )}
    </button>
  );
};

const IconButton = ({
  icon: Icon,
  type = "button",
  size = "sm",
  variant = "primary",
  className = "",
  active,
  ...rest
}) => {
  return (
    <button
      type={type}
      className={cn(
        className,
        styles.button,
        styles["icon-button"],
        styles[size],
        styles[variant],
        {
          [styles.active]: active,
        }
      )}
      {...rest}
    >
      {<Icon />}
    </button>
  );
};

export { IconButton, Button };
