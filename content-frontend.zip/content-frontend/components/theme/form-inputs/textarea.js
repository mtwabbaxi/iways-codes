import { useMemo } from "react";
import cn from "classnames";
import styles from "./textarea.module.scss";
import { BiSolidErrorCircle } from "react-icons/bi";

const TextArea = ({
  size = "md",
  label,
  hint,
  required,
  error,
  maxLength,
  rows = 4,
  ...rest
}) => {
  const value = rest.value;
  const fontClass = useMemo(() => {
    switch (size) {
      case "sm":
        return "text-caption";
      case "lg":
        return "text-body1";
      case "md":
      default:
        return "text-body2";
    }
  });

  const inputLength = useMemo(() => {
    return value?.length ?? 0;
  }, [value]);

  const errorEl = (
    <span
      className={cn("d-block color-scarletRed-500 text-body2", styles.error)}
    >
      <BiSolidErrorCircle size="1.2em" className="color-scarletRed-300" />{" "}
      {error}
    </span>
  );

  return (
    <div className={styles.container}>
      {label && (
        <label className={cn("font-weight-medium", fontClass)}>
          {label}{" "}
          {required && (
            <span
              className={cn(fontClass, "color-gray-1100 font-weight-regular")}
            >
              (required)
            </span>
          )}
        </label>
      )}
      <div
        className={cn(styles["input-container"], styles[size], {
          [styles["has-error"]]: Boolean(error),
        })}
      >
        <textarea
          rows={rows}
          value={value}
          className={cn(styles.input, fontClass)}
          {...rest}
        />
      </div>
      <div className={cn(styles.info, { "mb-3": Boolean(hint) })}>
        {hint && (
          <span className="d-block color-gray-1200 text-body2">{hint}</span>
        )}
        {error && !hint && errorEl}

        {Boolean(maxLength) && (
          <span
            className={cn(
              "text-body2 color-gray-2900 font-weight-medium",
              styles["max-chars"],
            )}
          >{`${inputLength} / ${maxLength}`}</span>
        )}
      </div>
      {error && hint && errorEl}
    </div>
  );
};

export { TextArea };
