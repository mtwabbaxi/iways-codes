import styles from "./radio.module.scss";
import cn from "classnames";

const Radio = ({ label, hint, id, checked, ...rest }) => {
  return (
    <div className={styles.container}>
      <div>
        <input
          {...rest}
          type="radio"
          className={styles.radio}
          checked={checked}
          id={id}
        />
        <label
          className={cn(styles.indicator, { [styles.checked]: checked })}
          htmlFor={id}
        ></label>
      </div>
      <div className={styles.labels}>
        {label && (
          <label
            htmlFor={id}
            className={cn("text-body2 font-weight-medium color-gray-2900")}
          >
            {label}
          </label>
        )}
        {hint && (
          <label className="text-body2 color-gray-700" htmlFor={id}>
            {hint}
          </label>
        )}
      </div>
    </div>
  );
};

export { Radio };
