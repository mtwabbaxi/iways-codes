"use client";
import { useMemo } from "react";
import cn from "classnames";
import styles from "./textField.module.scss";
import { BiSolidErrorCircle } from "react-icons/bi";
import { useDispatch, useSelector } from "react-redux";
import {
  fetchAllContentEntries,
  filterContentStatus,
  removeContentEntryFilter,
} from "@/store/actions/contentEntry";

import { useParams } from "next/navigation";
import Chips from "../chips";

const TextField = ({
  size = "md",
  label,
  hint,
  required,
  error,
  maxLength,
  disabled,
  applyLimit,
  icon: Icon,
  iconRight = false,
  localized = false,
  language = "English (United States) (en-US)",
  onIconClick = () => {},
  mb0 = false,
  showOnlyLocaleLabel = false,
  onEnterPress = () => {},
  fieldValues,
  enteredValues,
  setEnteredValues,
  formData,
  ...rest
}) => {
  const dispatch = useDispatch();
  const { spaceId = "", spaceEnvironmentId = "" } = useParams();
  const value = rest.value;
  const { selectedStatus, filters, sortBy } = useSelector(
    (state) => state.contentEntries
  );

  const fontClass = useMemo(() => {
    switch (size) {
      case "sm":
        return "text-caption";
      case "lg":
        return "text-body1";
      case "md":
      default:
        return "text-body2";
    }
  });

  const inputLength = useMemo(() => {
    return value?.length ?? 0;
  }, [value]);
  const handleRemoveChips = (indexToRemove) => {
    const updatedValues = [...enteredValues];
    updatedValues.splice(indexToRemove, 1);
    setEnteredValues(updatedValues);
  };

  const handleKeyDown = (e) => {
    if (formData?.list && fieldValues && e.key === "Enter") {
      // Call the provided onEnterPress function with the current value
      onEnterPress(rest.value);
      if (rest.value.trim() !== "") {
        // setEnteredValues((prevValues) => [...prevValues, enteredValue]);
        setEnteredValues((prevValues) => [...prevValues, rest.value]);
      }
      rest.onChange("");
    }
    if (
      (e.key === "Backspace" &&
        Array.isArray(value) &&
        value.length === 0 &&
        selectedStatus) ||
      filters?.lastUpdatedBy ||
      filters?.createdBy
    ) {
      const data = {
        sortBy,
        filters,
      };
      dispatch(filterContentStatus(""));
      dispatch(removeContentEntryFilter("status"));
      dispatch(removeContentEntryFilter("lastUpdatedBy"));
      dispatch(removeContentEntryFilter("createdBy"));

      dispatch(
        fetchAllContentEntries(spaceId, spaceEnvironmentId, { ...data })
      );
    }
  };

  const errorEl = (
    <span
      className={cn("d-block color-scarletRed-500 text-body2", styles.error)}
    >
      <BiSolidErrorCircle size="1.2em" className="color-scarletRed-300" />{" "}
      {error}
    </span>
  );

  return (
    <div className={styles.container}>
      {label && !showOnlyLocaleLabel && (
        <label className={cn("font-weight-medium", fontClass)}>
          {label}&nbsp;
          {required && (
            <span
              className={cn(fontClass, "color-gray-1100 font-weight-regular")}
            >
              (required)&nbsp;
            </span>
          )}
          {localized && (
            <span className="font-weight-regular color-gray-1100">
              | {language}
            </span>
          )}
        </label>
      )}
      {localized && showOnlyLocaleLabel && (
        <label className={cn("font-weight-medium", fontClass)}>
          <span className="font-weight-regular color-gray-1100">
            {language}
          </span>
        </label>
      )}
      <div
        className={cn(styles["input-container"], styles[size], {
          [styles["has-error"]]: Boolean(error),
          [styles["has-icon-right"]]: Boolean(iconRight),
          [styles["disabled"]]: disabled,
        })}
        type="textField"
      >
        <input
          className={cn(styles.input, fontClass)}
          disabled={disabled}
          {...rest}
          value={rest.value || ""}
          onKeyDown={handleKeyDown}
          placeholder={
            formData?.list && fieldValues ? "Type the value and hit enter" : ""
          }
        />
        {iconRight && (
          <div className={styles["right-icon"]} onClick={onIconClick}>
            <Icon />
          </div>
        )}
      </div>
      {applyLimit ? (
        <div className={cn(styles["additional-info"])}>
          <span className={cn(styles["characters-limit"])}>
            {value ? value.length : 0} characters
          </span>
          <span className={cn(styles["characters-message"])}>
            Maximum 256 characters
          </span>
        </div>
      ) : (
        ""
      )}
      {(hint || error || maxLength) && (
        <div className={cn(styles.info, { "mb-3": Boolean(hint && !mb0) })}>
          {hint && (
            <span className="d-block color-gray-1200 italic text-body2">
              {hint}
            </span>
          )}
          {error && !hint && errorEl}

          {Boolean(maxLength) && (
            <span
              className={cn(
                "text-body2 color-gray-2900 font-weight-medium",
                styles["max-chars"]
              )}
            >{`${inputLength} / ${maxLength}`}</span>
          )}
        </div>
      )}
      {formData?.list &&
        enteredValues?.map((value, index) => (
          <span className={styles.chips_main} key={`${value}-${index}`}>
            <Chips
              key={index}
              index={index}
              value={value}
              handleDelete={() => handleRemoveChips(index)}
            />
          </span>
        ))}
      {error && hint && errorEl}
    </div>
  );
};

export { TextField };
