import { BiSolidErrorCircle } from "react-icons/bi";
import styles from "./checkbox.module.scss";
import cn from "classnames";

const Checkbox = ({
  label,
  hint,
  className = "",
  iconBeforeLabel: StartIcon,
  error,
  ...rest
}) => {
  return (
    <>
      <div className={cn(styles.container, className)}>
        <div>
          <input {...rest} type="checkbox" className={styles.checkbox} />
          <label
            className={cn(styles.indicator, {
              [styles.disabled]: rest?.disabled,
            })}
            htmlFor={rest.id}
          ></label>
        </div>
        <div
          className={cn(styles.labels, {
            [styles.icon]: StartIcon,
          })}
        >
          {StartIcon && <StartIcon />}
          {label && (
            <label
              htmlFor={rest.id}
              className={cn("text-body2 font-weight-medium color-gray-2900")}
            >
              {label}
            </label>
          )}
          {hint && (
            <label className="text-body2 color-gray-700" htmlFor={rest.id}>
              {hint}
            </label>
          )}
        </div>
      </div>
      {error && (
        <span
          className={cn(
            "d-block color-scarletRed-500 text-body2 mt-3",
            styles.error
          )}
        >
          <BiSolidErrorCircle size="1.2em" className="color-scarletRed-300" />{" "}
          {error}
        </span>
      )}
    </>
  );
};

export { Checkbox };
