import {useState} from "react"
import styles from "./confirmPopup.module.scss"
import {TextField} from "@/components/theme/form-inputs"
import {AiFillExclamationCircle} from "react-icons/ai"

const ConfirmPopup = ({
	setIsContentDeletePopupOpen,
	setisDeleteConfirmed,
	message,
	currRow,
}) => {
	const [envName, setEnvName] = useState("")
	const handleOverlayClick = (e) => {
		if (!e.target.closest(`.${styles.deleteConfirmPopup}`)) {
			setIsContentDeletePopupOpen(false)
		}
	}

	return (
		<div className={styles.container}>
			<div
				className={`${styles.overlay} ${styles.isContentDeletePopupOpen}`}
				onClick={handleOverlayClick}
			>
				<div className={styles.deleteConfirmPopup}>
					<div className={styles.header}>
						<h1>Delete environment</h1>
					</div>
					<hr />
					<div className={styles.content}>
						<p>
							You are about to delete the environment <b>{currRow?.name}</b>.
							All of the environment data, including the environment itself,
							will be deleted.
						</p>
						<div className={styles.inputValue}>
							<TextField
								label="To confirm, type the name of the environment in the field below:"
								onChange={(e) => {
									setEnvName(e.target.value)
								}}
							/>
						</div>
						<div className={styles.info}>
							<AiFillExclamationCircle />
							<p>Note that this operation cannot be undone.</p>
						</div>
						<div className={styles.buttonGroup}>
							<button
								className={styles.cancelButton}
								onClick={() => setIsContentDeletePopupOpen(false)}
							>
								Cancel
							</button>
							<button
								className={
									currRow?.name === envName
										? styles.confirmButton
										: `${styles.confirmButton} ${styles.disabled}`
								}
								onClick={() => setisDeleteConfirmed(true)}
								disabled={currRow?.name === envName ? false : true}
							>
								Delete Environment
							</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	)
}

export default ConfirmPopup
