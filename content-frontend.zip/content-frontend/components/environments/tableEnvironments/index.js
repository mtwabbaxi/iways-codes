"use client"

import {useState, useEffect} from "react"
import Header from "@/components/contentModel/header"
import {DataTable} from "@/components/theme/datatable"
import {useParams, useRouter} from "next/navigation"
import {APP_URLS, replaceUrlParams} from "@/utils/constants"
import NoSearchedData from "@/components/contentModel/tableContentModel/NoSearchedData"
import {deleteField, fetchAllContentModels} from "@/store/actions/contentModel"
import {useDispatch, useSelector} from "react-redux"
import styles from "./tableEnvironments.module.scss"
import {format, formatDistance, formatRelative, subDays} from "date-fns"
import {
	FaChevronLeft,
	FaChevronRight,
	FaChevronUp,
	FaChevronDown,
} from "react-icons/fa"

import {deleteEnvironment} from "@/store/actions/environments"

import {fetchAllEnvironments} from "@/store/actions/environments"
import {ContextMenu} from "@/components/theme/menus"
import {useToast} from "@/context/toastContext"
import ConfirmPopup from "../confirmPopup/confirmPopup"

export default function TableEnvironments() {
	const dispatch = useDispatch()
	const router = useRouter()
	const {addToast} = useToast()
	const [filteredData, setFilteredData] = useState([])
	const [searchText, setSearchText] = useState("")
	const [currentPage, setCurrentPage] = useState(1)
	const itemsPerPage = 50
	const {searchNameContent} = useSelector((state) => state.contentModel)
	const {spaceId, spaceEnvironmentId} = useParams()
	const [sortOrder, setSortOrder] = useState("asc")
	const [isContentDeletePopupOpen, setIsContentDeletePopupOpen] =
		useState(false)
	const [currRow, setCurrRow] = useState("")
	const [isDeleteConfirmed, setisDeleteConfirmed] = useState(false)
	const {allEnvironments, filterValue} = useSelector(
		(state) => state.environments
	)

	const startIdx = (currentPage - 1) * itemsPerPage
	const endIdx = startIdx + itemsPerPage
	const displayedData = filteredData?.slice(startIdx, endIdx)

	const totalPages = Math.ceil(filteredData?.length / itemsPerPage)

	useEffect(() => {
		dispatch(fetchAllEnvironments(spaceId, spaceEnvironmentId))
		dispatch(fetchAllContentModels(spaceId, spaceEnvironmentId))
	}, [])
	const handleSort = (key) => {
		const newSortOrder = sortOrder === "asc" ? "desc" : "asc"
		setSortOrder(newSortOrder)
		setFilteredData((prevData) => {
			const sortedData = [...prevData]
			sortedData.sort((a, b) => {
				if (newSortOrder === "asc") {
					return a[key] > b[key] ? 1 : -1
				} else {
					return b[key] > a[key] ? 1 : -1
				}
			})
			return sortedData
		})
	}

	const handleNextPage = () => {
		if (currentPage < totalPages) {
			setCurrentPage(currentPage + 1)
		}
	}

	const handleDelete = async (row) => {
		try {
			let res = null
			const data = {
				spaceEnvironmentId: row.spaceEnvironmentId,
			}
			res = await dispatch(deleteEnvironment(data))
			const {
				result: {body},
			} = res
			if (body.responseCode === 200) {
				addToast(body.responseMessage)
				dispatch(fetchAllEnvironments(spaceId, spaceEnvironmentId))
			} else {
				addToast(body?.responseMessage || "An unknown error occured!", {
					type: "error",
				})
			}
		} catch (err) {
			console.log("error: ", err)
		} finally {
			setIsContentDeletePopupOpen(false)
			setCurrRow("")
			setisDeleteConfirmed(false)
		}
	}

	const handleDeleteConfirmPopup = async (row) => {
		setIsContentDeletePopupOpen(true)
		setCurrRow(row)
	}

	const columns = [
		{
			title: "Environment ID",
			key: "name",
			styles: {
				paddingLeft: "1.5rem",
				width: "50%",
			},
			render: (allEnvironments) => {
				return (
					<div className={styles.name}>
						<div className="font-weight-medium">{allEnvironments.name}</div>
					</div>
				)
			},
		},
		{
			title: (
				<div
					className={styles.sortableColumn}
					onClick={() => handleSort("lastModifiedDate")}
				>
					Created
					{/* {sortOrder === "asc" && <FaChevronUp className={styles.sortIcon} />}
					{sortOrder === "desc" && (
						<FaChevronDown className={styles.sortIcon} />
					)} */}
				</div>
			),
			key: "lastModifiedDate",
			render: (data) => {
				return (
					<div>
						{formatDistance(
							subDays(new Date(data.lastModifiedDate), 0),
							new Date(),
							{addSuffix: true}
						)}
					</div>
				)
			},
		},
		{
			title: "Status",
			key: "status",
			render: (allEnvironments) => {
				const currStatus = allEnvironments?.spaceEnvironmentStatus.toLowerCase()
				return (
					<div className={`${styles[currStatus]}`}>
						{allEnvironments.spaceEnvironmentStatus}
					</div>
				)
			},
		},
		{
			title: "",
			key: "actions",
			render: (row) => {
				return (
					<div className={styles["col-actions"]}>
						<button
							className={styles.delete_btn}
							onClick={() => handleDeleteConfirmPopup(row)}
						>
							Delete
						</button>
					</div>
				)
			},
		},
	]

	const handlePrevPage = () => {
		if (currentPage > 1) {
			setCurrentPage(currentPage - 1)
		}
	}

	const handlePageChange = (page) => {
		if (page >= 1 && page <= totalPages) {
			setCurrentPage(page)
		}
	}

	useEffect(() => {
		if (searchNameContent?.data?.length > 0) {
			setSearchText(searchNameContent.data)
			setFilteredData(
				allEnvironments?.content?.filter(
					(f) =>
						f?.name
							?.toLowerCase()
							.indexOf(searchNameContent.data.toLowerCase()) !== -1
				)
			)
		} else if (allEnvironments?.content?.length) {
			setFilteredData(allEnvironments?.content)
		} else {
			setFilteredData(allEnvironments?.content)
		}
	}, [allEnvironments, searchNameContent])

	const rowClickHandler = (row) => {
		if (row.contentModelId) {
			router.push(
				replaceUrlParams(APP_URLS.CONTENT.UPDATE, {
					spaceId: spaceId,
					spaceEnvironmentId: spaceEnvironmentId,
					contentModelId: row.contentModelId,
					contentEntryId: row.contentEntryId,
				})
			)
		}
	}

	useEffect(() => {
		// Initialize filteredData with allEnvironments.content
		setFilteredData(allEnvironments?.content)

		if (filterValue) {
			// If there is a filter value, update filteredData
			// Add your filtering logic here based on the filterValue
			setFilteredData((prevData) =>
				prevData.filter(
					(entry) => entry.contentModelId === filterValue
					// Add your filter condition here, e.g., entry.property === filterValue
				)
			)
		}

		// Set search text to empty when there is no filter or when filterValue is empty
		setSearchText("")
	}, [allEnvironments, filterValue])

	useEffect(() => {
		if (isDeleteConfirmed) {
			handleDelete(currRow)
		} else {
			setIsContentDeletePopupOpen(false)
			setCurrRow("")
		}
	}, [isDeleteConfirmed])

	return (
		<>
			{/* <Header searchText={searchText} onSearchChange={handleSearchChange} /> */}

			{Boolean(!displayedData?.length) && <NoSearchedData />}

			{Boolean(displayedData?.length) && (
				<>
					<DataTable
						rowClickHandler={rowClickHandler}
						columns={columns}
						dataSource={displayedData}
					/>
					<div className={styles.pagination}>
						<span>{`${startIdx + 1} - ${startIdx + displayedData.length} of ${
							filteredData.length
						} items`}</span>
						{filteredData.length > itemsPerPage && (
							<>
								<button onClick={handlePrevPage} disabled={currentPage === 1}>
									<FaChevronLeft />
								</button>
								<button
									onClick={handleNextPage}
									disabled={currentPage === totalPages}
								>
									<FaChevronRight />
								</button>
							</>
						)}
					</div>
				</>
			)}

			{isContentDeletePopupOpen && (
				<ConfirmPopup
					setIsContentDeletePopupOpen={setIsContentDeletePopupOpen}
					setisDeleteConfirmed={setisDeleteConfirmed}
					message={"Are you sure you want to delete this environment?"}
					currRow={currRow}
				/>
			)}
		</>
	)
}
