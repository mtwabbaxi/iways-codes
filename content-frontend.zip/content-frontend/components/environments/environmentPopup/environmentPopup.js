import {useState, useCallback, useMemo, useEffect} from "react"
import styles from "./environmentPopup.module.scss"
import {IoMdClose} from "react-icons/io"
import {Controller, FormProvider, useForm} from "react-hook-form"
import * as yup from "yup"
import {useDispatch, useSelector} from "react-redux"
import {yupResolver} from "@hookform/resolvers/yup"
import {TextField} from "@/components/theme/form-inputs"
import {Button} from "@/components/theme/buttons"
import {useParams} from "next/navigation"
import {
	fetchAllEnvironments,
	addEnvironment,
} from "@/store/actions/environments"
import {useToast} from "@/context/toastContext"

const schema = yup.object({
	title: yup
		.string()
		.required("ID is required")
		.max(40, "ID must be at most 40 characters long"),
})

const EnvironmentCreatePopup = ({
	createEnvironment, // Function to handle environment creation
	setIsPopupOpen,
}) => {
	const [selectedEnvironment, setSelectedEnvironment] = useState("")
	const {spaceId, spaceEnvironmentId} = useParams()
	const {allEnvironments} = useSelector((state) => state.environments)
	const [titleCharCount, setTitleCharCount] = useState(0)
	const {addToast} = useToast()
	const dispatch = useDispatch()
	const methods = useForm({
		defaultValues: {
			title: "",
		},
		mode: "onChange",
		resolver: yupResolver(schema),
	})
	const {
		handleSubmit,
		control,
		formState: {errors},
	} = methods

	const onSubmit = async (values) => {
		let data = {
			name: values.title,
			spaceEnvironmentToBeClone:
				selectedEnvironment?.id ||
				allEnvironments?.content[0]?.spaceEnvironmentId,
			spaceId: spaceId,
		}

		try {
			let res = await dispatch(addEnvironment(data))
			const {
				result: {body},
			} = res
			if (body.responseCode === 200) {
				addToast(body.responseMessage)
				dispatch(fetchAllEnvironments(spaceId, spaceEnvironmentId))
			} else {
				addToast(body?.responseMessage || "An unknown error occured!", {
					type: "error",
				})
			}
			;``
		} catch (err) {
			console.log("error: ", err)
		} finally {
			setIsPopupOpen(false)
		}
	}

	const All_ENVIRONMENTS = [
		{
			id: 1,
			children:
				allEnvironments?.content?.map((env) => ({
					id: env.spaceEnvironmentId,
					title:
						env.spaceEnvironmentId === spaceEnvironmentId
							? `${env.name} (current)`
							: env.name,
				})) || [],
		},
	]

	const handleOverlayClick = (e) => {
		if (!e.target.closest(`.${styles.createEnvironmentPopup}`)) {
			setIsPopupOpen(false)
		}
	}

	const onChangeEnvHandler = (val) => {
		setSelectedEnvironment(val)
	}

	return (
		<div className={styles.container}>
			<div
				className={`${styles.overlay} ${styles.isEnvironmentCreatePopupOpen}`}
				onClick={handleOverlayClick}
			>
				<div className={styles.createEnvironmentPopup}>
					<div className={styles.header}>
						<h1>Add environment</h1>
						<button
							className={styles.closeIcon}
							onClick={() => setIsPopupOpen(false)}
						>
							<IoMdClose />
						</button>
					</div>
					<hr />
					<div className={styles.content}>
						<FormProvider {...methods}>
							<form
								onSubmit={handleSubmit(onSubmit)}
								className={styles["publish-form"]}
							>
								<Controller
									control={control}
									name="title"
									render={({field}) => (
										<>
											<TextField
												{...field}
												label="ID"
												error={errors?.title?.message}
												required
												hint={
													<div className={styles.helptexts}>
														<p>
															The environment ID represents how it is referred
															to in the API
														</p>
														<p>{titleCharCount} / 40</p>
													</div>
												}
												onChange={(e) => {
													field.onChange(e)
													setTitleCharCount(e.target.value.length)
												}}
											/>
										</>
									)}
								/>
								<div className={styles.selectEnv}>
									<label htmlFor="env" className={styles.selectLabel}>
										Clone new environment from <span>(required)</span>
									</label>
									<div className={styles.dropdown}>
										<select
											name="env"
											value={selectedEnvironment?.title}
											onChange={(e) => {
												const selectedOption =
													All_ENVIRONMENTS[0].children.find(
														(option) => option.title === e.target.value
													)

												if (selectedOption) {
													onChangeEnvHandler(selectedOption)
												}
											}}
										>
											{All_ENVIRONMENTS[0].children?.map((val) => (
												<option key={val.id} value={val.title}>
													{val.title}
												</option>
											))}
										</select>
									</div>
								</div>

								<div className={styles.buttonGroup}>
									<Button
										size="md"
										id="submit-media-button"
										className={styles.createButton}
										text="Add environment"
										textAlign="center"
										type="submit"
									/>
									<Button
										size="md"
										id="cancel-button"
										className={styles.cancelButton}
										text="Cancel"
										textAlign="center"
										onClick={() => setIsPopupOpen(false)}
									/>
								</div>
							</form>
						</FormProvider>
					</div>
				</div>
			</div>
		</div>
	)
}

export default EnvironmentCreatePopup
