import React, {useState} from "react"
import styles from "./sidebar.module.scss"
import {Tabs} from "@/components/theme/tabs"
import {APP_URLS} from "@/utils/constants"
import {AiFillExclamationCircle} from "react-icons/ai"
import EnvironmentPopup from "../environmentPopup/environmentPopup"
import {useSelector} from "react-redux"

export default function Sidebar_Right({media = false}) {
	const [activeContentTab, setActiveContentTab] = useState(0)
	const [isPopupOpen, setIsPopupOpen] = useState(false)

	const {allEnvironments} = useSelector((state) => state.environments)

	const handleTabClick = (index) => {
		setActiveContentTab(index)
	}

	return (
		<>
			<div className={styles.container}>
				<div className={styles.sidebar}>
					<div className={styles.usage}>
						<h2>ENVIRONMENT USAGE</h2>
					</div>
					<p>
						You are using {allEnvironments && allEnvironments?.content?.length}{" "}
						out of 3 environments available in this space.{" "}
						<span
							className={styles.tooltip}
							data-tooltip="This space type includes 2 sandbox environments additional to the master environment"
						>
							<AiFillExclamationCircle />
						</span>
					</p>
					<button
						className={styles.add_env}
						onClick={() => setIsPopupOpen(true)}
					>
						Add environment
					</button>
				</div>
			</div>

			{isPopupOpen && <EnvironmentPopup setIsPopupOpen={setIsPopupOpen} />}
		</>
	)
}
