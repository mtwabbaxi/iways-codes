"use client"
import styles from "./header.module.scss"
import {AiOutlineSetting} from "react-icons/ai"

export default function Header({}) {
	return (
		<>
			<div className={styles.container}>
				<div className={styles.heading}>
					<AiOutlineSetting />
					<h3 className="text-body1 font-weight-semi-bold">Environments</h3>
				</div>
			</div>
		</>
	)
}
