import React, { useEffect, useState } from "react";
import styles from "./sidebar.module.scss";
import { IoIosArrowDown, IoMdClose } from "react-icons/io";
import {
  AiFillPlusCircle,
  AiFillSetting,
  AiOutlineShareAlt,
} from "react-icons/ai";
import { useDispatch, useSelector } from "react-redux";
import { useParams, useRouter } from "next/navigation";
import { APP_URLS, replaceUrlParams } from "@/utils/constants";
import AddSpaceForm from "../addSpaceForm/addSpaceForm";
import { fetchEnvironmentBySpaceId } from "@/store/actions/spaces";
import Link from "next/link";

const sidebar = ({
  sidebarRef,
  getMenus = () => {},
  setDesktopToggleOpen,
  setSelectedSpace,
  selectedSpace,
  spaceId,
}) => {
  const { allSpaces, environment } = useSelector((state) => state.spaces);
  const [isAddSpacePopupOpen, setAddSpacePopupOpen] = useState(false);
  const dispatch = useDispatch();
  const router = useRouter();
  const onChangeSpaceHandler = (title, spaceId) => {
    dispatch(fetchEnvironmentBySpaceId(spaceId));
  };

  const onChangeEnvironmentHandler = (spaceId, spaceEnvironmentId, name) => {
    setSelectedSpace(name.toLowerCase());
    router.push(
      `${replaceUrlParams(APP_URLS.CONTENT_MODELS.LIST, {
        spaceId: spaceId,
        spaceEnvironmentId: spaceEnvironmentId,
      })}`
    );
    setDesktopToggleOpen(false);
  };
  const addSpaceHandler = () => {
    setAddSpacePopupOpen(true);
  };

  const params = useParams();
  const { spaceEnvironmentId } = params || {};

  const handleOrganization = () => {
    router.push(
      replaceUrlParams(APP_URLS.ORGANIZATION.SUBSCRIPTION, {
        spaceId,
        spaceEnvironmentId,
      })
    );
  };

  const SIDEBAR_TOP_MENU = [
    {
      id: 5,
      title: "Project",
      icon: <IoIosArrowDown />,
      isMenuOpen: true,
      children:
        allSpaces &&
        allSpaces.content.map((item, index) => {
          let matchingValues;
          if (environment && environment.content.length) {
            matchingValues = environment.content.filter(
              (value) => value.spaceId === item.spaceId
            );
          }
          return {
            id: index,
            title: (
              <>
                <span
                  onClick={() => onChangeSpaceHandler(item.title, item.spaceId)}
                >
                  <IoIosArrowDown />
                  {item.title}
                </span>
                {matchingValues && (
                  <div className={styles.environments}>
                    {matchingValues.map((value, valueIndex) => {
                      return (
                        <>
                          <span
                            onClick={() =>
                              onChangeEnvironmentHandler(
                                value.spaceId,
                                value.spaceEnvironmentId,
                                value.name
                              )
                            }
                            className={
                              value.name === selectedSpace &&
                              value.spaceId === spaceId &&
                              styles.active_env
                            }
                          >
                            <AiOutlineShareAlt />
                            {value.name}
                          </span>
                        </>
                      );
                    })}
                  </div>
                )}
              </>
            ),
          };
        }),
    },
  ];

  const SIDEBAR_BOTTOM_MENU = [
    {
      id: 1,
      title: <span onClick={addSpaceHandler}>Add Space</span>,
      icon: <AiFillPlusCircle />,
    },
    {
      id: 2,
      title: (
        <span onClick={handleOrganization}>
          Organization settings & subscriptions
        </span>
      ),
      icon: <AiFillSetting />,
    },
  ];

  const SELECT_SPACE = [
    {
      id: 5,
      title: (
        <p>
          <span className={styles.spaceName}>PO</span> Power Software Solutions
        </p>
      ),
      children: [
        { id: 6, title: "master" },
        { id: 7, title: "live" },
      ],
    },
  ];

  useEffect(() => {
    const dropdownElement = document.querySelector(
      ".menuDropdown_container__tx5Ka .menuDropdown_dropdown__69WHH"
    );

    if (dropdownElement) {
      const maxHeight = 400;
      const contentHeight = dropdownElement.scrollHeight;

      if (contentHeight > maxHeight) {
        dropdownElement.style.height = `${maxHeight}px`;
        dropdownElement.style.overflowY = "scroll";
      } else {
        dropdownElement.style.height = "auto";
        dropdownElement.style.overflowY = "visible";
      }
    }
  }, [allSpaces]);

  useEffect(() => {}, [environment]);
  return (
    <div className={styles.overlayOpen} ref={sidebarRef}>
      <div className={styles.sidebar}>
        <div className={styles.topMenuOptions}>
          <div className={styles.selectSpace}>{getMenus(SELECT_SPACE)}</div>
          <br />
          <h3 className={styles.heading}>Spaces</h3>
          <div className={`${styles.projectMenu} ${styles[selectedSpace]}`}>
            {getMenus(SIDEBAR_TOP_MENU)}
          </div>
        </div>
        <div className={styles.bottomMenuOptions}>
          {getMenus(SIDEBAR_BOTTOM_MENU)}
        </div>
        {/* Add Space Popup */}
        {isAddSpacePopupOpen && (
          <div className={styles.addSpacePopup}>
            <button
              className={styles.closeIcon}
              onClick={() => setAddSpacePopupOpen(false)}
            >
              <IoMdClose />
            </button>
            <div>
              <AddSpaceForm
                setAddSpacePopupOpen={setAddSpacePopupOpen}
                setDesktopToggleOpen={setDesktopToggleOpen}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default sidebar;
