import { useState, useCallback, useMemo, useRef, useEffect } from "react";
import cn from "classnames";
import styles from "./topNav.module.scss";
import MenuItem from "../secondaryNav/menuItem";
import MenuDropdown from "../secondaryNav/menuDropdown";
import Auth from "@/utils/auth";

//icons
import {
  AiFillHome,
  AiOutlineClose,
  AiTwotoneAppstore,
  AiFillQuestionCircle,
  AiOutlineShareAlt,
} from "react-icons/ai";
import { RxHamburgerMenu } from "react-icons/rx";
import { BiSolidWrench, BiSolidPen, BiSearch } from "react-icons/bi";
import { BsImageFill } from "react-icons/bs";
import { APP_URLS, replaceUrlParams } from "@/utils/constants";
import Sidebar from "./sidebar/sidebar";
import { useDispatch, useSelector } from "react-redux";
import {
  fetchAllSpaces,
  fetchEnvironmentBySpaceId,
} from "@/store/actions/spaces";
import { useParams } from "next/navigation";

const TopNav = () => {
  const [open, setOpen] = useState(false);
  const [desktopToggleOpen, setDesktopToggleOpen] = useState(false);
  const [selectedSpace, setSelectedSpace] = useState("");
  const auth = new Auth();
  const dispatch = useDispatch();
  const sidebarRef = useRef(null);
  const { allSpaces, environment } = useSelector((state) => state.spaces);
  const { user } = useSelector((state) => state.user);
  const { spaceId, spaceEnvironmentId } = useParams();
  const logOut = () => {
    auth.removeAuth();
  };

  const ITEMS = [
    {
      id: 1,
      title: "Home",
      icon: <AiFillHome />,
      url: replaceUrlParams(APP_URLS.HOME, {
        spaceId: spaceId,
        spaceEnvironmentId: spaceEnvironmentId,
      }),
    },
    {
      id: 2,
      title: "Content Model",
      icon: <BiSolidWrench />,
      url: replaceUrlParams(APP_URLS.CONTENT_MODELS.LIST, {
        spaceId: spaceId,
        spaceEnvironmentId: spaceEnvironmentId,
      }),
    },
    {
      id: 3,
      title: "Content",
      icon: <BiSolidPen />,
      url: replaceUrlParams(APP_URLS.CONTENT.LIST, {
        spaceId: spaceId,
        spaceEnvironmentId: spaceEnvironmentId,
      }),
    },
    {
      id: 4,
      title: "Media",
      icon: <BsImageFill />,
      url: replaceUrlParams(APP_URLS.MEDIA.LIST, {
        spaceId: spaceId,
        spaceEnvironmentId: spaceEnvironmentId,
      }),
    },
    {
      id: 5,
      title: "Apps",
      icon: <AiTwotoneAppstore />,
      children: [
        { id: 6, title: "Marketplace" },
        { id: 7, title: "Installed Apps" },
        { id: 8, title: "Custom Apps" },
        { id: 9, title: "Share marketplace feedback" },
      ],
    },
  ];
  const ITEMS_RIGHT = [
    {
      id: 10,
      title: <span className={styles.help}>Help</span>,
      align: "left",
      icon: <AiFillQuestionCircle />,
      children: [
        { id: 6, title: "Help Center" },
        { id: 7, title: "Developer Docs" },
        { id: 8, title: "Learning Cneter" },
        { id: 9, title: "Get Support" },
      ],
    },
    {
      id: 11,
      title: (
        <span className={styles.userName}>
          {user?.firstName?.charAt(0).toUpperCase()}
          {user?.lastName?.charAt(0).toUpperCase()}
        </span>
      ),
      align: "left",
      children: [
        {
          id: 12,
          title: "Account Settings",
        },
        {
          id: 13,
          title: "Talk to us",
        },
        {
          id: 14,
          title: (
            <span className={styles.logout} onClick={() => logOut()}>
              Logout
            </span>
          ),
        },
      ],
    },
  ];

  const handleToggleMenu = useCallback(() => {
    setOpen((open) => !open);
  }, []);
  const handleCloseMenu = useCallback(() => {
    setOpen(false);
  }, []);

  const desktopToggleMenu = useCallback(() => {
    if (!allSpaces) {
      dispatch(fetchAllSpaces());
    }
    setDesktopToggleOpen((desktopToggleOpen) => !desktopToggleOpen);
  }, [allSpaces]);

  const handleSidebarClick = useCallback(
    (event) => {
      if (
        desktopToggleOpen &&
        sidebarRef.current &&
        !sidebarRef.current.contains(event.target)
      ) {
        setDesktopToggleOpen(false);
      }
    },
    [desktopToggleOpen]
  );

  useEffect(() => {
    // Add a click event listener to the document
    document.addEventListener("click", handleSidebarClick);

    // Clean up the event listener when the component unmounts
    return () => {
      document.removeEventListener("click", handleSidebarClick);
    };
  }, [handleSidebarClick]);

  const MenuIcon = useMemo(() => {
    return open ? AiOutlineClose : RxHamburgerMenu;
  }, [open]);

  const getMenus = useCallback((items) => {
    return items.map((item) => {
      if (item.children?.length) {
        return (
          <MenuDropdown
            key={item.id}
            title={item.title}
            icon={item.icon}
            children={item.children}
            align={item.align}
            isMenuOpen={item.isMenuOpen}
          />
        );
      } else {
        return (
          <MenuItem
            key={item.id}
            text={item.title}
            icon={item.icon}
            url={item.url}
            children={item.children}
          />
        );
      }
    });
  }, []);

  const mobileMenus = ITEMS.map((item) => (
    <MenuItem
      key={item.title}
      text={item.title}
      icon={item.icon}
      url={item.url}
      children={item.children}
      onClick={handleCloseMenu}
    />
  ));

  const destopMenu = ITEMS_RIGHT.map((item) => (
    <MenuItem
      key={item.title}
      text={item.title}
      icon={item.icon}
      url={item.url}
      children={item.children}
      onClick={handleCloseMenu}
    />
  ));

  useEffect(() => {
    if (spaceId) {
      dispatch(fetchEnvironmentBySpaceId(spaceId));
    }
  }, [spaceId]);

  useEffect(() => {
    if (environment?.content?.length) {
      const environments = environment?.content;
      const filterEnvironments = environments?.find(
        (e) => e?.spaceEnvironmentId === spaceEnvironmentId
      );
      setSelectedSpace(filterEnvironments?.name);
    }
  }, [environment]);

  return (
    <>
      {/* for desktop */}
      {desktopToggleOpen && <div className={styles.overlay}></div>}
      {desktopToggleOpen && (
        <Sidebar
          sidebarRef={sidebarRef}
          getMenus={getMenus}
          setSelectedSpace={setSelectedSpace}
          selectedSpace={selectedSpace}
          setDesktopToggleOpen={setDesktopToggleOpen}
          spaceId={spaceId}
        />
      )}
      <div className={cn(styles.container, styles.desktop, "bg-gray-2900")}>
        <div className={styles.left}>
          {/* Add Contentful icon SVG */}
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 256 289"
          >
            <path
              fill="#FAE501"
              d="M87.333 200.777c-15.306-14.406-24.309-34.213-24.309-56.722s9.003-42.316 23.409-56.722c12.605-12.604 12.605-32.412 0-45.017c-12.605-12.605-32.412-12.605-45.017 0C16.206 68.426 0 104.44 0 144.055s16.206 75.629 42.316 101.739c12.605 12.605 32.413 12.605 45.017 0c11.705-12.605 11.705-32.413 0-45.017Z"
            />
            <path
              fill="#4FB5E1"
              d="M87.333 87.333c14.406-15.306 34.213-24.309 56.722-24.309s42.316 9.003 56.722 23.409c12.604 12.605 32.412 12.605 45.017 0c12.605-12.605 12.605-32.412 0-45.017C219.684 16.206 183.67 0 144.055 0S68.426 16.206 42.316 42.316c-12.605 12.605-12.605 32.413 0 45.017c12.605 11.705 32.413 11.705 45.017 0Z"
            />
            <path
              fill="#F05751"
              d="M200.777 200.777c-14.406 15.305-34.213 24.309-56.722 24.309s-42.316-9.004-56.722-23.41c-12.604-12.604-32.412-12.604-45.017 0c-12.605 12.606-12.605 32.413 0 45.018c26.11 25.21 62.124 41.416 101.739 41.416s75.629-16.206 101.739-42.316c12.605-12.605 12.605-32.413 0-45.017c-12.605-11.705-32.413-11.705-45.017 0Z"
            />
            <circle cx="64.825" cy="64.825" r="31.512" fill="#0681B6" />
            <circle cx="64.825" cy="223.285" r="31.512" fill="#CD4739" />
          </svg>

          <div className={styles.toggleMenu} onClick={desktopToggleMenu}>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
            >
              <path
                fill="white"
                d="M4 17.27v-1h16v1H4Zm0-4.77v-1h16v1H4Zm0-4.77v-1h16v1H4Z"
              />
            </svg>
          </div>

          <ul className={styles.env_list} onClick={desktopToggleMenu}>
            <li>PO</li>
            <li>Project</li>
            <li>
              <span>
                <AiOutlineShareAlt />
              </span>
              {selectedSpace}
            </li>
          </ul>
        </div>

        <div className={styles.right}>
          <div className={cn(styles.search)}>
            <BiSearch />
          </div>
          <div className={styles.dropMenu}>{getMenus(ITEMS_RIGHT)}</div>
        </div>
      </div>
      {/* for mobile */}
      <div
        className={cn(styles.container, styles.mobile, "bg-gray-2900", {
          [styles.open]: open,
        })}
      >
        <MenuIcon
          onClick={handleToggleMenu}
          className={cn(styles["menu-toggler"], "color-gray-100")}
        />
        {open && mobileMenus}
      </div>
    </>
  );
};

export default TopNav;
