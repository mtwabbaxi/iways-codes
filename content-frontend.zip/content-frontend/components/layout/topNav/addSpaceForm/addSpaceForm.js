"use client";

import React, { useState } from "react";
import styles from "./addSpaceForm.module.scss";
import { TextField, TextArea } from "@/components/theme/form-inputs";
import { Button } from "@/components/theme/buttons";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { Controller, FormProvider, useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { useToast } from "@/context/toastContext";
import { fetchAllSpaces, addSpace } from "@/store/actions/spaces";

const schema = yup.object({
  title: yup
    .string()
    .required("Title is required")
    .max(30, "Title must be at most 20 characters long"),
  description: yup
    .string()
    .required("Description is required")
    .max(5000, "Description must be at most 5000 characters long"),
});

export default function AddSpaceForm({
  isEditMode,
  setAddSpacePopupOpen,
  setDesktopToggleOpen,
}) {
  const [titleCharCount, settitleCharCount] = useState(0);
  const [descriptionCharCount, setDescriptionCharCount] = useState(0);

  const methods = useForm({
    defaultValues: {
      title: "",
      description: "",
      file: null,
    },
    mode: "onChange",
    resolver: yupResolver(schema),
  });

  const {
    handleSubmit,
    control,
    formState: { errors },
  } = methods;

  const dispatch = useDispatch();
  const { addToast } = useToast();

  const onSubmit = async (values) => {
    let data;
    if (isEditMode) {
      data = {
        title: values.title,
        description: values.description,
      };
    } else {
      data = {
        title: values.title,
        description: values.description,
      };
    }

    try {
      let res;
      res = await dispatch(addSpace(data));
      const {
        result: { body },
      } = res;
      if (body.responseCode === 200) {
        addToast(body.responseMessage);
        dispatch(fetchAllSpaces());
      } else {
        addToast(body?.responseMessage || "An unknown error occured!", {
          type: "error",
        });
      }
      ``;
    } catch (err) {
      console.log("error: ", err);
    } finally {
      setAddSpacePopupOpen(false);
      setDesktopToggleOpen(false);
    }
  };

  return (
    <>
      <div className={styles.wrapper}>
        <div className={styles.container}>
          <FormProvider {...methods}>
            <form
              onSubmit={handleSubmit(onSubmit)}
              className={styles["publish-form"]}
            >
              <Controller
                control={control}
                name="title"
                render={({ field }) => (
                  <TextField
                    {...field}
                    required
                    label="Title"
                    error={errors?.title?.message}
                    hint={titleCharCount + " characters"}
                    onChange={(e) => {
                      field.onChange(e);
                      settitleCharCount(e.target.value.length);
                    }}
                  />
                )}
              />
              <Controller
                control={control}
                name="description"
                render={({ field }) => (
                  <TextArea
                    {...field}
                    required
                    label="Description"
                    className="textarea"
                    error={errors?.description?.message}
                    hint={descriptionCharCount + " characters"}
                    onChange={(e) => {
                      field.onChange(e);
                      setDescriptionCharCount(e.target.value.length);
                    }}
                  />
                )}
              />
              <Button
                size="md"
                id="submit-media-button"
                className={styles["submit-button"]}
                text="Submit"
                textAlign="center"
                type="submit"
              />
            </form>
          </FormProvider>
        </div>
      </div>
    </>
  );
}
