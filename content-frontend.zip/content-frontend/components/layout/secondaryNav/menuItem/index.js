import cn from "classnames";
import styles from "./menuItem.module.scss";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useMemo } from "react";

import { BiSolidDownArrow } from "react-icons/bi";

const MenuItem = ({
  text,
  icon,
  url = null,
  onClick = () => {},
  isDropdown,
  title = "",
  open,
  isSideBar,
  count,
  topBar,
}) => {
  const pathname = usePathname();

  const active = useMemo(() => {
    if (!url || !pathname) {
      return false;
    }

    // Check if the current pathname matches the URL or its base path
    return pathname === url;
  }, [pathname, url]);
  const iconStyle = {
    transform: open ? "rotate(360deg)" : "rotate(-90deg)",
  };
  const truncatedText =
    topBar && text.length > 10 ? text.substring(0, 10) + "..." : text;
  const truncatedTitle =
    topBar && title.length > 9 ? title.substring(0, 9) + "..." : title;
  const buttonEl = (
    <button
      onClick={onClick}
      className={cn(
        "font-weight-medium text-body2 color-gray-600",
        styles.menu,
        { [styles.active]: active }
      )}
    >
      {Boolean(icon) && (
        <span className={styles.icon} style={iconStyle}>
          {icon}
        </span>
      )}{" "}
      {topBar && (truncatedTitle ? truncatedTitle : truncatedText)}
      {!topBar && (title ? title : text)}
      {isDropdown && <BiSolidDownArrow size="0.5em" />}
      <span className={styles.count}>{isSideBar ? count : ""}</span>
    </button>
  );

  return url ? <Link href={url}>{buttonEl}</Link> : <>{buttonEl}</>;
};

export default MenuItem;
