import { useState, useCallback, useMemo } from "react";
import cn from "classnames";
import styles from "./secondaryNav.module.scss";
import MenuItem from "./menuItem";
import MenuDropdown from "./menuDropdown";

//icons
import { AiFillHome, AiOutlineClose, AiTwotoneAppstore } from "react-icons/ai";
import { RxHamburgerMenu } from "react-icons/rx";
import { BiSolidWrench, BiSolidPen } from "react-icons/bi";
import { BsImageFill } from "react-icons/bs";

import { APP_URLS, replaceUrlParams } from "@/utils/constants";
import { OPTION_TYPES } from "./menuDropdown/menuOption";
import { useParams, usePathname } from "next/navigation";

const SecondaryNav = () => {
  const [open, setOpen] = useState(false);
  const { spaceId, spaceEnvironmentId } = useParams();
  const pathname = usePathname();
  const isOnOrganizationPage = useMemo(() => {
    if (
      pathname.includes("organization/spaces") ||
      pathname.includes("organization/subscription")
    ) {
      return true;
    }
    return false;
  }, [pathname]);

  const ITEMS = [
    {
      id: 1,
      title: "Home",
      icon: <AiFillHome />,
      url: replaceUrlParams(APP_URLS.HOME, {
        spaceId: spaceId,
        spaceEnvironmentId: spaceEnvironmentId,
      }),
    },
    {
      id: 2,
      title: "Content Model",
      icon: <BiSolidWrench />,
      url: replaceUrlParams(APP_URLS.CONTENT_MODELS.LIST, {
        spaceId: spaceId,
        spaceEnvironmentId: spaceEnvironmentId,
      }),
    },
    {
      id: 3,
      title: "Content",
      icon: <BiSolidPen />,
      url: replaceUrlParams(APP_URLS.CONTENT.LIST, {
        spaceId: spaceId,
        spaceEnvironmentId: spaceEnvironmentId,
      }),
    },
    {
      id: 4,
      title: "Media",
      icon: <BsImageFill />,
      url: replaceUrlParams(APP_URLS.MEDIA.LIST, {
        spaceId: spaceId,
        spaceEnvironmentId: spaceEnvironmentId,
      }),
    },
    {
      id: 5,
      title: "Apps",
      icon: <AiTwotoneAppstore />,
      children: [
        { id: 6, title: "Marketplace" },
        { id: 7, title: "Installed Apps" },
        { id: 8, title: "Custom Apps" },
        { id: 9, title: "Share marketplace feedback" },
      ],
    },
  ];
  const ITEMS_RIGHT = [
    {
      id: 10,
      title: "Docs",
      children: [
        { id: 23, title: "Buttons", url: APP_URLS.THEME.BUTTONS },
        { id: 24, title: "Tabs", url: APP_URLS.THEME.TABS },
        { id: 25, title: "Alerts", url: APP_URLS.THEME.ALERTS },
        { id: 26, title: "Form Inputs", url: APP_URLS.THEME.FORM_INPUTS },
        { id: 27, title: "Data Tables", url: APP_URLS.THEME.DATA_TABLES },
        { id: 28, title: "Menus", url: APP_URLS.THEME.MENUS },
        { id: 29, title: "Labels", url: APP_URLS.THEME.LABELS },
      ],
    },
    {
      id: 11,
      title: "Settings",
      align: "left",
      children: [
        {
          id: 12,
          type: OPTION_TYPES.SECTION_TITLE,
          title: "Environment Settings",
        },
        {
          id: 13,
          title: "Locales",
          url: replaceUrlParams(APP_URLS.SETTINGS.LOCALES.LIST, {
            spaceId: spaceId,
            spaceEnvironmentId: spaceEnvironmentId,
          }),
        },
        {
          id: 14,
          title: "Tags",
        },
        {
          id: 15,
          title: "Homes",
        },
        {
          id: 16,
          type: OPTION_TYPES.SECTION_TITLE,
          title: "Space Settings",
        },
        {
          id: 17,
          title: "General Settings",
        },
        {
          id: 18,
          title: "Users",
        },
        {
          id: 19,
          title: "Roles & permissions",
        },
        {
          id: 20,
          title: "Environments",
          url: replaceUrlParams(APP_URLS.SETTINGS.ENVIRONMENTS.LIST, {
            spaceId: spaceId,
            spaceEnvironmentId: spaceEnvironmentId,
          }),
        },
        {
          id: 21,
          title: "API Keys",
          url: replaceUrlParams(APP_URLS.API_KEYS, {
            spaceId: spaceId,
            spaceEnvironmentId: spaceEnvironmentId,
          }),
        },
        {
          id: 22,
          title: "CMA Tokens",
        },
      ],
    },
  ];
  const ITEMS_ORGANIZATIONS = [
    {
      id: 1,
      title: "Subscription",
      url: replaceUrlParams(APP_URLS.ORGANIZATION.SUBSCRIPTION, {
        spaceId: spaceId,
        spaceEnvironmentId: spaceEnvironmentId,
      }),
    },
    {
      id: 2,
      title: "Spaces",
      url: replaceUrlParams(APP_URLS.ORGANIZATION.SPACES, {
        spaceId: spaceId,
        spaceEnvironmentId: spaceEnvironmentId,
      }),
    },
  ];

  const handleToggleMenu = useCallback(() => {
    setOpen((open) => !open);
  }, []);
  const handleCloseMenu = useCallback(() => {
    setOpen(false);
  }, []);

  const MenuIcon = useMemo(() => {
    return open ? AiOutlineClose : RxHamburgerMenu;
  }, [open]);

  const getMenus = useCallback((items) => {
    return items.map((item) => {
      if (item.children?.length) {
        return (
          <MenuDropdown
            key={item.id}
            title={item.title}
            icon={item.icon}
            children={item.children}
            align={item.align}
            dontAddInFilter
          />
        );
      } else {
        return (
          <MenuItem
            key={item.id}
            text={item.title}
            icon={item.icon}
            url={item.url}
            children={item.children}
          />
        );
      }
    });
  }, []);

  const mobileMenus = ITEMS.map((item) => (
    <MenuItem
      key={item.title}
      text={item.title}
      icon={item.icon}
      url={item.url}
      children={item.children}
      onClick={handleCloseMenu}
    />
  ));

  return (
    <>
      {/* for desktop */}
      <div className={cn(styles.container, styles.desktop)}>
        <div className={styles.left}>
          {!isOnOrganizationPage
            ? getMenus(ITEMS)
            : getMenus(ITEMS_ORGANIZATIONS)}
        </div>
        {!isOnOrganizationPage && (
          <div className={styles.left}>{getMenus(ITEMS_RIGHT)}</div>
        )}
      </div>

      {/* for mobile */}
      <div
        className={cn(styles.container, styles.mobile, "bg-gray-2900", {
          [styles.open]: open,
        })}
      >
        <MenuIcon
          onClick={handleToggleMenu}
          className={cn(styles["menu-toggler"], "color-gray-100")}
        />
        {open && mobileMenus}
      </div>
    </>
  );
};

export default SecondaryNav;
