import styles from "./menuDropdown.module.scss";
import { useState, useCallback, useRef, useEffect } from "react";
import MenuItem from "../menuItem";
import { useOutsideClick } from "@/hooks/useOutsideClick";
import MenuOption from "./menuOption";
import cn from "classnames";
import {
  addFilterUdatedByMeContentEntry,
  addFiltersContentEntry,
  addSortingContentEntry,
  filterContentStatus,
  filterContentTable,
  removeContentEntryFilter,
} from "@/store/actions/contentEntry";
import { useDispatch, useSelector } from "react-redux";
import { useParams, useRouter } from "next/navigation";
import { APP_URLS, replaceUrlParams } from "@/utils/constants";
import {
  addMediaFilters,
  fetchAllMediaAsset,
  removeMediaFilter,
} from "@/store/actions/media";

const MenuDropdown = ({
  children,
  icon,
  align,
  isMenuOpen,
  isSideBar,
  pageType,
  title = "",
  dropdown_status_sidebar,
  count,
  topBar,
  dontAddInFilter = false,
  isMedia = false,
}) => {
  const menuOpen = isMenuOpen ? isMenuOpen : false;
  const dispatch = useDispatch();
  const { spaceId, spaceEnvironmentId } = useParams();
  const router = useRouter();
  const { user } = useSelector((state) => state.user);
  const [open, setOpen] = useState(menuOpen);
  const {
    selectedModel,
    selectedStatus,
    filters: contentEntryFilters,
    sortBy,
    filterValue,
  } = useSelector((state) => state.contentEntries);

  const { filters = {} } = useSelector((state) => state.media);

  const toggleDropdown = useCallback(() => {
    setOpen((open) => !open);
  });

  const handleMedia = (data) => {
    if (!isMedia) return;
    if (data?.isFilterFileType) {
      if (filters?.mediaType === data.title) {
        dispatch(removeMediaFilter("mediaType"));
      } else {
        dispatch(addMediaFilters("mediaType", data.title));
      }
    } else {
      if (filters?.status === data.title.toUpperCase()) {
        dispatch(removeMediaFilter("status"));
      } else {
        dispatch(addMediaFilters("status", data.title.toUpperCase()));
      }
    }
  };

  const handleContent = (m) => {
    if (m.addEntry && pageType === "content") {
      const contentModelId = m.data.contentModelId;
      router.push(
        replaceUrlParams(APP_URLS.CONTENT.CREATE, {
          spaceId: spaceId,
          spaceEnvironmentId: spaceEnvironmentId,
          contentModelId: contentModelId,
        })
      );
    }
    if (!topBar && dontAddInFilter) return;

    if (pageType === "content" && m.data) {
      const contentModelId = m.data.contentModelId;
      dispatch(filterContentStatus(selectedStatus));
      if (contentModelId === "Any") {
        if (selectedStatus) {
          dispatch(
            addFiltersContentEntry("status", selectedStatus.toUpperCase())
          );
          dispatch(removeContentEntryFilter("lastUpdatedBy"));
        }

        dispatch(removeContentEntryFilter("contentModelId"));
        dispatch(filterContentTable(null, contentModelId));
      } else {
        dispatch(addFiltersContentEntry("contentModelId", contentModelId));
        if (selectedStatus) {
          dispatch(
            addFiltersContentEntry("status", selectedStatus.toUpperCase())
          );
          dispatch(removeContentEntryFilter("lastUpdatedBy"));
          dispatch(removeContentEntryFilter("createdBy"));
        }
        if (contentEntryFilters?.lastUpdatedBy) {
          dispatch(
            addFiltersContentEntry(
              "lastUpdatedBy",
              contentEntryFilters.lastUpdatedBy
            )
          );
          dispatch(removeContentEntryFilter("status"));
          dispatch(filterContentStatus(""));
        }
        if (contentEntryFilters?.createdBy) {
          dispatch(
            addFiltersContentEntry("createdBy", contentEntryFilters.createdBy)
          );
          dispatch(removeContentEntryFilter("status"));
          dispatch(filterContentStatus(""));
        }

        dispatch(filterContentTable(contentModelId, m.title));
      }
    } else if (pageType === "content") {
      if (m?.title && m?.createdBy) {
        dispatch(addFiltersContentEntry("createdBy", m?.title));
        dispatch(removeContentEntryFilter("status"));
        dispatch(filterContentStatus(""));
      } else if (m?.title && m?.lastUpdatedBy) {
        dispatch(addFiltersContentEntry("lastUpdatedBy", m?.title));
        dispatch(removeContentEntryFilter("status"));
        dispatch(filterContentStatus(""));
      } else {
        dispatch(addFiltersContentEntry("status", m.title.toUpperCase()));
        dispatch(filterContentStatus(m.title));
        dispatch(removeContentEntryFilter("lastUpdatedBy"));
        dispatch(removeContentEntryFilter("createdBy"));
      }
    }
  };

  const menuRef = useRef(null);
  const onChangeHandler = (m) => {
    handleContent(m);
    handleMedia(m);
    closeDropdown();
  };

  const closeDropdown = () => {
    if (!isSideBar) {
      setOpen(false);
    }
  };

  useOutsideClick(menuRef, closeDropdown);
  const dropdownClass = cn(styles.dropdown, styles[align], {
    [styles.sideBarDropdown]: dropdown_status_sidebar,
    [styles.dropdownHeight]: topBar,
  });

  return (
    <div className={styles.container} ref={menuRef}>
      <MenuItem
        text={selectedModel}
        icon={icon}
        isDropdown
        onClick={toggleDropdown}
        title={title}
        open={open}
        isSideBar={isSideBar}
        count={count}
        topBar={topBar}
      />

      {open && (
        <div className={dropdownClass}>
          {children.map((m, index) => {
            return (
              <MenuOption
                onClick={() => onChangeHandler(m)}
                key={m.id + index}
                url={m.url}
                title={m?.title}
                type={m.type}
                isActive={
                  Boolean(filters?.mediaType === m?.title && isMedia) || isMedia
                    ? Boolean(filters?.status === m?.title?.toUpperCase())
                    : false
                }
              />
            );
          })}
        </div>
      )}
    </div>
  );
};

export default MenuDropdown;
