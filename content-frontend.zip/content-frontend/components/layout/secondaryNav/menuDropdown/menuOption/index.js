import cn from "classnames";
import styles from "./menuOption.module.scss";
import Link from "next/link";
import { useSelector } from "react-redux";

export const OPTION_TYPES = {
  SECTION_TITLE: "section title",
};

const MenuOption = ({
  title,
  type,
  url,
  onClick = () => {},
  isActive = false,
}) => {
  const { filters = {} } = useSelector((state) => state?.media);

  if (type === OPTION_TYPES.SECTION_TITLE) {
    return (
      <label
        className={cn(
          "text-caption color-gray-1300 p-2",
          styles["section-title"]
        )}
      >
        {title}
      </label>
    );
  }

  const buttonEl = (
    <button
      onClick={onClick}
      type="button"
      className={cn(styles.option, "text-body2 color-gray-2900", {
        [styles.active]: isActive,
      })}
    >
      {title}
    </button>
  );

  return url ? <Link href={url}>{buttonEl}</Link> : <>{buttonEl}</>;
};

export default MenuOption;
