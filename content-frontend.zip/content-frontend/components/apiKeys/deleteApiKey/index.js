import { Button } from "@/components/theme/buttons";
import React from "react";
import styles from "./deleteApiKey.module.scss";
import cn from "classnames";
import { useSelector } from "react-redux";

export default function DeleteAPIKey({
  onCancel = () => {},
  onDelete = () => {},
}) {
  const { apiKeysLoading } = useSelector((state) => state.apiKeys);

  return (
    <>
      <p>Are you sure you want to delete this API Key?</p>
      <div className={styles.actions}>
        <Button
          disabled={apiKeysLoading}
          className="font-weight-bold"
          onClick={onCancel}
          text="Don't Delete"
          variant="default"
          type="button"
        />
        <Button
          disabled={apiKeysLoading}
          className="font-weight-bold"
          onClick={onDelete}
          text="Delete"
          variant="primary"
          type="button"
        />
      </div>
    </>
  );
}
