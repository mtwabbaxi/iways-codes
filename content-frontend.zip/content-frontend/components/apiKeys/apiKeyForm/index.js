import { Button } from "@/components/theme/buttons";
import { TextArea, TextField } from "@/components/theme/form-inputs";
import React from "react";
import styles from "./apiKeyForm.module.scss";
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { Controller, FormProvider, useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import {
  createAPIKey,
  getAllAPIKeys,
  setAPIKeyLoadingTrue,
} from "@/store/actions/apiKeys";
import { useParams } from "next/navigation";
import { useToast } from "@/context/toastContext";

const schema = yup.object().shape({
  name: yup
    .string()
    .required("Name is required")
    .max(65, "Name must be at most 65 characters"),
  description: yup
    .string()
    .max(255, "Description must be at most 255 characters"),
});

export default function APIKeyForm({ onCancel = () => {} }) {
  const dispatch = useDispatch();
  const { apiKeysLoading } = useSelector((state) => state.apiKeys);

  const methods = useForm({
    defaultValues: {},
    mode: "onChange",
    resolver: yupResolver(schema),
  });

  const {
    handleSubmit,
    control,
    watch,
    formState: { errors },
  } = methods;

  const params = useParams();
  const { spaceId = "", spaceEnvironmentId = "" } = params || {};

  const { addToast } = useToast();

  const onSubmit = async (values) => {
    try {
      dispatch(setAPIKeyLoadingTrue());
      const { name, description } = values;
      const res = await dispatch(
        createAPIKey({
          spaceId,
          spaceEnvironmentIds: Array(spaceEnvironmentId),
          name,
          description,
        })
      );
      const {
        result: { body },
      } = res;
      if (body.responseCode === 200) {
        addToast(body.responseMessage);
        onCancel();
        dispatch(getAllAPIKeys({ spaceId, spaceEnvironmentId }));
      } else {
        addToast(body.responseMessage || "An unknown error occured!", {
          type: "error",
        });
        onCancel();
      }
    } catch (err) {
      console.log("error: ", err);
    } finally {
    }
  };
  return (
    <FormProvider {...methods}>
      <form className={styles.container} onSubmit={handleSubmit(onSubmit)}>
        <Controller
          name="name"
          control={control}
          render={({ field }) => (
            <TextField
              {...field}
              label="Name"
              required
              hint="Can be platform or device specific names (i.e. marketing website, tablet, VR app)"
              error={errors?.name?.message}
              maxLength={65}
            />
          )}
        />
        <Controller
          name="description"
          control={control}
          render={({ field }) => (
            <TextArea
              {...field}
              label="Description"
              hint="You can provide an optional description for reference in the future"
              error={errors?.description?.message}
              maxLength={255}
            />
          )}
        />

        <div className={styles.actions}>
          <Button
            disabled={apiKeysLoading}
            variant="default"
            type="button"
            text="Cancel"
            onClick={onCancel}
          />
          <Button
            disabled={
              apiKeysLoading ||
              errors?.description?.message ||
              errors.name?.message
            }
            variant="primary"
            type="submit"
            text="Submit"
          />
        </div>
      </form>
    </FormProvider>
  );
}
