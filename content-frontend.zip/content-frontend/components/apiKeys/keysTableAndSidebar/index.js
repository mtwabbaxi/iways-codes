"use client";

import React, { useEffect } from "react";
import styles from "./keysTableAndSidebar.module.scss";
import { APP_URLS, replaceUrlParams } from "@/utils/constants";
import { useParams } from "next/navigation";
import Link from "next/link";
import { useDispatch, useSelector } from "react-redux";
import { getAllAPIKeys } from "@/store/actions/apiKeys";

export default function KeysTableAndSidebar() {
  const params = useParams();
  const { spaceId = "", spaceEnvironmentId = "" } = params || {};
  const dispatch = useDispatch();
  const { allApiKeys } = useSelector((state) => state.apiKeys);

  useEffect(() => {
    if (dispatch) {
      dispatch(
        getAllAPIKeys({
          spaceId,
        })
      );
    }
  }, [dispatch]);

  return (
    <div className={styles.container}>
      <div className={styles["table-container"]}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th className="text-caption">Name</th>
              <th className="text-caption">Description</th>
            </tr>
          </thead>
          <tbody>
            {allApiKeys?.length > 0 &&
              allApiKeys?.map((apiKey, index) => (
                <tr key={apiKey?.apiKeyId || index}>
                  <td className="text-body2 color-blueViolet-100">
                    <Link
                      href={replaceUrlParams(APP_URLS.API_KEY_DETAILS, {
                        spaceId,
                        spaceEnvironmentId,
                        apiKeyId: apiKey?.apiKeyId,
                      })}
                    >
                      {apiKey?.name}
                    </Link>
                  </td>
                  <td className="text-body2">{apiKey?.description}</td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
      <div className={styles["sidebar-container"]}></div>
    </div>
  );
}
