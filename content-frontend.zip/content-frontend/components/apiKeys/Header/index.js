"use client";

import React, { useState } from "react";
import styles from "./header.module.scss";
import { RiArrowUpDownLine } from "react-icons/ri";
import { BsArrowLeft, BsQuestion } from "react-icons/bs";
import cn from "classnames";
import { Button } from "@/components/theme/buttons";
import { FiPlusCircle } from "react-icons/fi";
import Modal from "@/components/shared/modal";
import APIKeyForm from "../apiKeyForm";
import { useRouter, useParams } from "next/navigation";
import { APP_URLS, replaceUrlParams } from "@/utils/constants";
import Link from "next/link";
import DeleteAPIKey from "../deleteApiKey";
import { useDispatch, useSelector } from "react-redux";
import {
  deleteAPIKeyById,
  getAllAPIKeys,
  setAPIKeyLoadingTrue,
} from "@/store/actions/apiKeys";
import { useToast } from "@/context/toastContext";

export default function Header({ goBack = false, name = "APIs", errors = {} }) {
  const dispatch = useDispatch();
  const { addToast } = useToast();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [openDeleteModal, setOpenDeleteModal] = useState(false);
  const { allApiKeys = [], apiKeysLoading } = useSelector(
    (state) => state.apiKeys
  );

  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const handleOpenDeleteModal = () => setOpenDeleteModal(true);
  const handleCloseDeleteModal = () => setOpenDeleteModal(false);

  const params = useParams();
  const { spaceId = "", spaceEnvironmentId = "", apiKeyId = "" } = params || {};

  const handleDeleteApiKey = async () => {
    try {
      dispatch(setAPIKeyLoadingTrue());
      if (spaceId && spaceEnvironmentId && apiKeyId) {
        const res = await dispatch(
          deleteAPIKeyById({
            spaceId,
            spaceEnvironmentId,
            apiKeyId,
          })
        );

        const {
          result: { body = {} },
        } = res;

        if (body?.responseCode === 200) {
          addToast(body?.responseMessage);
          dispatch(getAllAPIKeys({ spaceId }));
          handleCloseDeleteModal();
          router.push(
            replaceUrlParams(APP_URLS.API_KEYS, { spaceId, spaceEnvironmentId })
          );
        } else {
          addToast(body?.responseMessage || "An unkown error occurred!", {
            type: "error",
          });
          handleCloseDeleteModal();
        }
      }
    } catch (err) {
      console.error("error: ", err);
    }
  };

  return (
    <div className={styles["header-container"]}>
      <div className={styles["first-column"]}>
        {goBack && (
          <>
            <Link
              href={replaceUrlParams(APP_URLS.API_KEYS, {
                spaceId,
                spaceEnvironmentId,
              })}
              className={styles.back}
            >
              <BsArrowLeft />
            </Link>
            <p className={cn("color-gray-500", "text-body1", styles.slash)}>
              /
            </p>
          </>
        )}
        <RiArrowUpDownLine />
        <p className="font-weight-medium">{name}</p>
        <BsQuestion className={cn(styles["question-icon"])} />
        {!goBack && (
          <p className={styles.message}>
            Your space is using {allApiKeys?.length} API keys.
          </p>
        )}
      </div>
      <div className={styles["second-column"]}>
        {!goBack ? (
          <Button
            onClick={handleOpen}
            text="Add API key"
            startIcon={FiPlusCircle}
          />
        ) : (
          <div className={styles.actions}>
            <Button
              disabled={apiKeysLoading}
              onClick={handleOpenDeleteModal}
              variant="default"
              text="Delete"
              type="button"
            />
            <Button
              disabled={
                apiKeysLoading ||
                errors?.name?.message ||
                errors?.spaceEnvironmentIds?.message ||
                errors?.description?.message
              }
              type="submit"
              variant="primary"
              text="Save"
            />
          </div>
        )}
      </div>

      {open && (
        <Modal heading="Create API Key" onClose={handleClose}>
          <APIKeyForm onCancel={handleClose} />
        </Modal>
      )}
      {openDeleteModal && (
        <Modal heading="Delete API Key" onClose={handleCloseDeleteModal}>
          <DeleteAPIKey
            onCancel={handleCloseDeleteModal}
            onDelete={handleDeleteApiKey}
          />
        </Modal>
      )}
    </div>
  );
}
