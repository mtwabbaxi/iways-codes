import React, {useState, useCallback, useMemo, useEffect} from "react"
import {useDropzone} from "react-dropzone"
import ReactPlayer from "react-player"
import styles from "./index.module.scss"
import cn from "classnames"
import {AiFillFileAdd, AiTwotoneDelete, AiTwotoneEdit} from "react-icons/ai"
import {deleteMedia, setCurrUploadFile} from "@/store/actions/media"
import ConfirmPopup from "@/components/content/confirmPopup/confirmPopup"
import {useDispatch} from "react-redux"

const MediaUpload = ({
	onMediaChange,
	setUploadedFile,
	setFileRequiredMessage,
	isContentExisitPopupOpen,
	label,
	size = "md",
	required,
	isEditMode,
	...rest
}) => {
	const [media, setMedia] = useState(null)
	const [mediaType, setMediaType] = useState("") // Separate state for media type
	const [mediaDimensions, setMediaDimensions] = useState(null)
	const [existUrl, setExistUrl] = useState("")
	const [isDeleteConfirmed, setisDeleteConfirmed] = useState(false)
	const [loading, setLoading] = useState(false)
	const [isConfirmPopupOpen, setIsConfirmPopupOpen] = useState(false)
	const dispatch = useDispatch()
	const fontClass = useMemo(() => {
		switch (size) {
			case "sm":
				return "text-caption"
			case "lg":
				return "text-body1"
			case "md":
			default:
				return "text-body2"
		}
	})
	const onDrop = useCallback(
		async (acceptedFiles) => {
			const file = acceptedFiles[0]
			let dimensions = null
			let type = file.type

			const maxSizeInBytes = 10 * 1024 * 1024
			const acceptedFormats = [
				"image/jpeg",
				"image/png",
				"image/gif",
				"image/jpg",
			]

			if (file.size > maxSizeInBytes) {
				console.error("File size exceeds the maximum limit of 10MB.")
			} else if (!acceptedFormats.includes(file.type)) {
				console.error(
					"Invalid file format. Only jpg, png, gif, and tiff are allowed."
				)
			} else {
				try {
					setLoading(true) // Set loading to true when starting the upload
					const res = await dispatch(
						uploadMedia(file, mediaType, mediaDimensions)
					)
					const {
						result: {body},
					} = res

					if (body.responseCode === 200) {
						addToast(body.responseMessage)
					} else {
						addToast(body?.responseMessage || "An unknown error occurred!", {
							type: "error",
						})
					}
				} catch (err) {
					console.error("Error uploading file:", err)
				} finally {
					setLoading(false) // Set loading to false when upload is complete
				}

				setMedia(file)
			}
			if (
				file.type.startsWith("video") ||
				/\.(mp4|webm|ogg)$/i.test(file.name)
			) {
				setMediaType("video")
			} else {
				setMediaType("image")
			}
			if (acceptedFormats.some((format) => file.type.startsWith(format))) {
				const image = new Image()
				image.src = URL.createObjectURL(file)
				image.onload = () => {
					dimensions = {
						width: image.width,
						height: image.height,
					}
					setMediaDimensions(dimensions) // Set dimensions in state
					onMediaChange(file, type, dimensions) // Call onMediaChange with dimensions
				}
			} else {
				// setMedia(file)
				setMediaType(type)
				setMediaDimensions(null)
				onMediaChange(file, type, dimensions) // Call onMediaChange without dimensions
			}
		},
		[onMediaChange]
	)

	const {getRootProps, getInputProps} = useDropzone({
		onDrop,
	})

	const onDeleteFile = () => {
		// dispatch(deleteMedia(media.name))
		setExistUrl("")
		setMedia(null)
		dispatch(setCurrUploadFile(""))
		setIsConfirmPopupOpen(false)
		setUploadedFile(null)
		setFileRequiredMessage("Required")
		setisDeleteConfirmed(false)
	}

	const deleteMediaHandler = () => {
		setIsConfirmPopupOpen(true)
	}

	useEffect(() => {
		setExistUrl(rest?.value)
	}, [rest.value])

	useEffect(() => {
		if (isDeleteConfirmed) {
			onDeleteFile()
		} else {
			setIsConfirmPopupOpen(false)
		}
	}, [isDeleteConfirmed])

	return (
		<div className={styles.container}>
			{label && (
				<label className={cn("font-weight-medium", fontClass)}>
					{label}{" "}
					{required && (
						<span
							className={cn(fontClass, "color-gray-1100 font-weight-regular")}
						>
							(required)
						</span>
					)}
				</label>
			)}
			<div {...getRootProps()} className="dropzone">
				<div className={styles.fileUpload_container}>
					{media || existUrl ? (
						<div className={styles.media_preview}>
							{loading ? (
								<div>Loading...</div>
							) : mediaType === "video" ? (
								<ReactPlayer
									url={
										isEditMode && !media ? existUrl : URL.createObjectURL(media)
									}
									controls
									width="100%"
								/>
							) : (
								<>
									<img
										src={
											isEditMode && !media
												? existUrl
												: URL.createObjectURL(media)
										}
										alt="Media Preview"
									/>
									{mediaDimensions && (
										<p>
											Dimensions: {mediaDimensions.width} x{" "}
											{mediaDimensions.height}
										</p>
									)}
								</>
							)}
						</div>
					) : (
						<div className={styles.file_upload}>
							<input {...getInputProps()} />
							<div className={styles.fileIcon}>
								<AiFillFileAdd />
							</div>
							<h1>Select Files to Upload</h1>
							<p>or Drag and Drop, Copy and Paste Files</p>
						</div>
					)}
				</div>
			</div>
			{(existUrl || Boolean(media)) && (
				<div className={styles.uploadedFile_icons}>
					<span
						className={styles.delete}
						onClick={() =>
							isContentExisitPopupOpen ? onDeleteFile() : deleteMediaHandler()
						}
					>
						<AiTwotoneDelete />
					</span>
					{/* <span>
						<AiTwotoneEdit />
					</span> */}
				</div>
			)}

			{isConfirmPopupOpen && (
				<ConfirmPopup
					setIsContentDeletePopupOpen={setIsConfirmPopupOpen}
					setisDeleteConfirmed={setisDeleteConfirmed}
					message="Are you sure you want to delete this media?"
				/>
			)}
		</div>
	)
}

export default MediaUpload
