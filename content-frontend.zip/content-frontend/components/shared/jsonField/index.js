import React, { useEffect, useState } from "react";
import ErrorEl from "@/components/shared/error";
import cn from "classnames";
import "./index.scss";

const JsonField = ({
  label,
  value,
  required,
  onChange,
  hint,
  error,
  localized = false,
  language = "English (United States) (en-US)",
}) => {
  const [isValid, setIsValid] = useState(true);
  const [textareaValue, setTextareaValue] = useState(value);
  const [history, setHistory] = useState([value]);
  const [currentHistoryIndex, setCurrentHistoryIndex] = useState(0);

  const handleChange = (event) => {
    const inputValue = event.target.value;
    setTextareaValue(inputValue);
    onChange(inputValue);

    try {
      JSON.parse(inputValue); // Attempt to parse the input as JSON
      setIsValid(true); // If successful, set isValid to true
    } catch (error) {
      setIsValid(false); // If parsing fails, set isValid to false
    }

    // Store the current value in the history
    setHistory((prevHistory) => [
      ...prevHistory.slice(0, currentHistoryIndex + 1),
      inputValue,
    ]);
    setCurrentHistoryIndex((prevIndex) => prevIndex + 1);
  };

  const handleUndo = () => {
    if (currentHistoryIndex > 0) {
      const prevValue = history[currentHistoryIndex - 1];
      setTextareaValue(prevValue);
      onChange(prevValue);
      setCurrentHistoryIndex((prevIndex) => prevIndex - 1);
    }
  };

  const handleRedo = () => {
    if (currentHistoryIndex < history.length - 1) {
      const nextValue = history[currentHistoryIndex + 1];
      setTextareaValue(nextValue);
      onChange(nextValue);
      setCurrentHistoryIndex((prevIndex) => prevIndex + 1);
    }
  };

  return (
    <div className="json-field-container">
      {label && (
        <label className={cn("font-weight-medium")}>
          {label}&nbsp;
          {required && (
            <span className={cn("color-gray-1100 font-weight-regular")}>
              (required)&nbsp;
            </span>
          )}
          {localized && (
            <span className="font-weight-regular color-gray-1100">
              | {language}
            </span>
          )}
        </label>
      )}
      <div className="json-field-top-bar">
        <div className="title">JSON Editor</div>
        <div className="json-field-buttons">
          <button onClick={handleUndo} disabled={currentHistoryIndex === 0}>
            Undo
          </button>
          <button
            onClick={handleRedo}
            disabled={currentHistoryIndex === history.length - 1}
          >
            Redo
          </button>
        </div>
      </div>
      <div className="input-container">
        <textarea value={value} onChange={handleChange} rows={6} cols={50} />
      </div>
      {hint && (
        <span className="d-block color-gray-1200 mt-3 italic text-body2">
          {hint}
        </span>
      )}
      {error && <ErrorEl error={error} />}
    </div>
  );
};

export default JsonField;
