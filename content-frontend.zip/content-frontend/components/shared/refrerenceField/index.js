import React, { useEffect, useMemo, useState } from "react";
import "./index.modules.scss";
import cn from "classnames";
import {
  fetchAllContentModels,
  getContentModelByIdForReference,
} from "@/store/actions/contentModel";
import { useDispatch, useSelector } from "react-redux"; // Import your CSS for styling
import Modal from "@/components/shared/modal";
import ErrorEl from "@/components/shared/error";
import { useParams } from "next/navigation";
import AllFieldsCell from "@/components/allFieldsCell";
import FieldNameForm from "@/components/contentFields/fieldNameForm/fieldNameForm";
import FieldSettingsForm from "@/components/contentFields/fieldSettingsForm/fieldSettingsForm";
import { de } from "date-fns/locale";
import Link from "next/link";
import { APP_URLS } from "@/utils/constants";
import { MdDeleteOutline } from "react-icons/md";
import Sidebar_Right from "@/components/media/sidebar_right";
import ContentForm from "@/components/content/contentForm/contentForm";
import ReferenceForm from "@/components/content/refrenceFormPopup/referenceForm";
import {
  setContentSubmitButton,
  setReferenceContentSubmitButton,
} from "@/store/actions/contentEntry";
import { useFormContext } from "react-hook-form";

const ReferenceField = ({
  label,
  required,
  contentEntries,
  hint,
  onChange,
  defaultValue,
  error,
  localized = false,
  language = "English (United States) (en-US)",
  type = "",
  referenceFieldForMedia = false,
}) => {
  const [showPopup, setShowPopup] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const [addExistingContentPopup, setAddExistingContentPopup] = useState(false);
  const [addNewContentPopup, setAddNewContentPopup] = useState(false);
  const [ReferenceContentModelId, setReferenceContentModelId] = useState();

  console.log("ReferenceContentModelId", ReferenceContentModelId);

  const [selectedEntries, setSelectedEntries] = useState([]);
  const dispatch = useDispatch();
  const { data } = useSelector((state) => state.contentModel);

  const params = useParams();
  const { spaceEnvironmentId = "", spaceId = "" } = params || {};

  const toggleDropdown = () => {
    setShowDropdown(!showDropdown);
  };

  const togglePopup = () => {
    setShowPopup(!showPopup);
  };

  const handleReferenceField = (entry) => {
    if (type === "MANY") {
      setSelectedEntries((prevEntries) => [...prevEntries, entry]);
      onChange([...selectedEntries, entry]);
    } else {
      setSelectedEntries([entry]);
      onChange([entry]);
    }
    setAddExistingContentPopup(false);
  };

  const removeSelectedEntry = (entryId) => {
    // Remove the selected entry by its ID
    setSelectedEntries((prevEntries) =>
      prevEntries.filter((entry) => entry.contentEntryId !== entryId)
    );
    onChange(
      selectedEntries.filter((entry) => entry.contentEntryId !== entryId)
    );
  };

  useEffect(() => {
    if (defaultValue?.length) {
      if (defaultValue?.length) {
        setSelectedEntries(defaultValue);
      } else {
        setSelectedEntries([]);
      }
    }
  }, [defaultValue]);

  // OPEN A NEW POPUP WITH SELECTED CONTENT MODEL
  const handleOpenEntryModel = (item) => {
    setAddNewContentPopup(true);
    setReferenceContentModelId(item?.contentModelId);
  };

  // useEffect(() => {
  //   const getContentModel = async () => {
  //     const res = await dispatch(
  //       getContentModelByIdForReference(
  //         ReferenceContentModelId,
  //         spaceId,
  //         spaceEnvironmentId
  //       )
  //     );
  //   };

  //   if (ReferenceContentModelId) {
  //     getContentModel();
  //   }
  // }, [ReferenceContentModelId]);

  const availableContentEntries = useMemo(() => {
    if (contentEntries?.content?.length) {
      return contentEntries.content.filter(
        (entry) =>
          !selectedEntries.some(
            (selected) => selected.contentEntryId === entry.contentEntryId
          )
      );
    } else {
      return [];
    }
  }, [contentEntries, selectedEntries]);
  const handleClose = () => {
    dispatch(setReferenceContentSubmitButton(false));
    setAddNewContentPopup(false);
  };
  return (
    <div className="reference-module">
      {label && (
        <label className={cn("font-weight-medium")}>
          {label}&nbsp;
          {required && (
            <span className={cn("color-gray-1100 font-weight-regular")}>
              (required)&nbsp;
            </span>
          )}
          {localized && (
            <span className="font-weight-regular color-gray-1100">
              | {language}
            </span>
          )}
        </label>
      )}

      <div className="reference-entries">
        {selectedEntries &&
          selectedEntries.map((entry, index) => {
            const { contentEntryId = "", contentModelId = "" } = entry || {};

            return (
              <div className="entry-container">
                <Link
                  href={APP_URLS.CONTENT_ENTRY.DETAIL({
                    spaceId,
                    spaceEnvironmentId,
                    contentEntryId,
                    contentModelId,
                  })}
                  target="_blank"
                >
                  <div className="content-model">
                    {entry.contentModelName}
                    <div className="status">{entry.status}</div>
                  </div>
                  <div className="title">{entry.name}</div>
                </Link>
                <div className="remove-button">
                  <MdDeleteOutline
                    size="2em"
                    onClick={() => removeSelectedEntry(entry.contentEntryId)}
                  />
                </div>
              </div>
            );
          })}
        {((type === "ONE" && selectedEntries?.length === 0) ||
          type === "MANY") && (
          <div className="dashed-border">
            <div className="dropdown-container">
              <div
                className="dropdown-button"
                type="button"
                onClick={toggleDropdown}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  fill="currentColor"
                  className="bi bi-plus"
                  viewBox="0 0 16 16"
                >
                  <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                </svg>
                Add Reference
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  className="bi bi-chevron-down"
                  viewBox="0 0 16 16"
                >
                  <path
                    fillRule="evenodd"
                    d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"
                    fill="#000000"
                  ></path>
                </svg>
              </div>
              {showDropdown && (
                <div className="reference-list">
                  <button
                    className="content-models"
                    type="button"
                    onClick={() => {
                      setShowDropdown(!showDropdown);
                      setAddExistingContentPopup(!addExistingContentPopup);
                    }}
                  >
                    Add existing content
                  </button>
                  <hr className={"separator"} />
                  <div className="new-content">New content</div>
                  <div className="add-new">
                    {data &&
                      data.content.map((item, index) => {
                        return (
                          <button
                            className={"content-models"}
                            type="button"
                            onClick={() => handleOpenEntryModel(item)}
                          >
                            {item.name}
                          </button>
                        );
                      })}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
      {hint && (
        <span className="d-block color-gray-1200 mt-3 italic text-body2">
          {hint}
        </span>
      )}
      {error && <ErrorEl error={error} />}

      {addExistingContentPopup && (
        <Modal
          heading={"Add existing entries"}
          contentClassName={"h-100"}
          onClose={() => setAddExistingContentPopup(!addExistingContentPopup)}
          size={"md"}
        >
          {availableContentEntries &&
            availableContentEntries.map((entry, index) => {
              return (
                <div
                  className="entry-container"
                  onClick={() => handleReferenceField(entry)}
                >
                  <div className="content-model">
                    {entry.contentModelName}
                    <div className="status">{entry.status}</div>
                  </div>
                  <div className="title">{entry.name}</div>
                </div>
              );
            })}
        </Modal>
      )}

      {addNewContentPopup && (
        <Modal
          heading={"Create New"}
          contentClassNameMain={"createNewMediaMain"}
          contentClassName={"createNewMedia"}
          onClose={handleClose}
          size={"lg"}
        >
          {/* <div className={"create_page"}> */}
          <div className={"content"}>
            <ReferenceForm
              ReferenceContentModelId={ReferenceContentModelId}
              RefrenceContentModel
              handleClose={handleClose}
              handleCreateNewEntry={(entry) => handleReferenceField(entry)}
              type={type}
              referenceFieldForMedia={referenceFieldForMedia}
            />
          </div>
          {/* <div className={"create_sidebar_wrapper"}>
              <Sidebar_Right referenceSidebar />
            </div> */}
          {/* </div> */}
        </Modal>
      )}
    </div>
  );
};

export default ReferenceField;
