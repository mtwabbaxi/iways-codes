import cn from "classnames";
import styles from "./card.module.scss";
import Link from "next/link";

const Card = ({ data }) => {
  const { icon: Icon, title, linkText, description } = data;
  return (
    <article className={cn(styles.container, "bg-gray-100 p-5")}>
      <div>
        <h6 className="text-body1 font-weight-semi-bold color-gray-2900 mb-4">
          {title}
        </h6>
        <p className="text-body2 color-gray-1800 mb-3">{description}</p>
        <Link
          href="#"
          className={cn(
            "text-body2 color-blue-700 font-weight-medium",
            styles.link
          )}
        >
          {linkText}
        </Link>
      </div>
      <div>{<Icon size="2.5em" />}</div>
    </article>
  );
};

export default Card;
