import styles from "./dropdownfield.module.scss";
const DropdownField = ({
  data,
  selectedvalue,
  setSelectedValue,
  title,
  required,
  disabled,
}) => {
  const onChangeHandler = (val) => {
    setSelectedValue(val);
  };
  return (
    <>
      <div className={styles.container}>
        <div className={styles.wrapper}>
          <label htmlFor="env" className={styles.selectLabel}>
            {title} {required && <span>(required)</span>}
          </label>
          <div className={styles.dropdown}>
            <select
              name="env"
              value={selectedvalue?.title}
              onChange={(e) => {
                const selectedOption = data[0].children.find(
                  (option) => option.title === e.target.value
                );

                if (selectedOption) {
                  onChangeHandler(selectedOption);
                }
              }}
              className={disabled && styles.disabled}
              disabled={disabled}
            >
              {data[0].children?.map((val) => (
                <option key={val.id} value={val.title}>
                  {val.title}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </>
  );
};

export default DropdownField;
