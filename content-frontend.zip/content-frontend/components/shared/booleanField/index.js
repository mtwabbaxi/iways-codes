import { Radio } from "@/components/theme/form-inputs";
import "./index.modules.scss";
import React, { useEffect, useState } from "react";
import { BiSolidErrorCircle } from "react-icons/bi";
import { useFormContext } from "react-hook-form";

const BooleanField = ({
  name,
  options,
  onChange,
  hint,
  localized = false,
  language = "English (United States) (en-US)",
  defaultValue,
  isEditMode = false,
  ...rest
}) => {
  const [selectedValue, setSelectedValue] = useState();

  const setValueHandler = (value = undefined) => {
    setSelectedValue(value);
    onChange(value);
  };

  useEffect(() => {
    if (!isEditMode) {
      // reset value can be false
      if (typeof rest.value === "boolean") {
        setSelectedValue(rest.value);
      } else {
        setSelectedValue();
      }
    }
  }, [rest?.value, isEditMode]);

  useEffect(() => {
    if (isEditMode) {
      if (typeof defaultValue === "boolean") {
        setSelectedValue(defaultValue);
      } else {
        setSelectedValue();
      }
    }
  }, [defaultValue, isEditMode]);

  return (
    <>
      <div className="text-body1 font-weight-semi-bold mb-5">
        {name}&nbsp;
        {rest.required && (
          <span className="color-gray-1100 font-weight-regular">
            (required)&nbsp;
          </span>
        )}
        {localized && (
          <span className="font-weight-regular color-gray-1100">
            | {language}
          </span>
        )}
      </div>
      <div className="radio-options">
        <Radio
          {...rest.field}
          id={`${rest.id}-yes`}
          label={options.true_custom_label}
          value={selectedValue === true}
          checked={selectedValue === true}
          onChange={() => setValueHandler(true)}
        />
        <Radio
          {...rest.field}
          id={`${rest.id}-no`}
          label={options.false_custom_label}
          value={selectedValue === false}
          checked={selectedValue === false}
          onChange={() => setValueHandler(false)}
        />
        <button
          type={"button"}
          className={"clear-button"}
          onClick={() => setValueHandler()}
        >
          Clear
        </button>
      </div>
      {hint && (
        <span className="d-block color-gray-1200 mt-3 italic text-body2">
          {hint}
        </span>
      )}
      {rest?.error && (
        <div className="mt-3">
          <span className="color-scarletRed-500 text-body2 error-container">
            <BiSolidErrorCircle size="1.2em" className="color-scarletRed-300" />{" "}
            {rest.error}
          </span>
        </div>
      )}
    </>
  );
};

export default BooleanField;
