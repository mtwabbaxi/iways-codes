import { useCallback } from "react";
import styles from "./fieldCell.module.scss";
import cn from "classnames";

export default function FieldCell({
  icon: Icon,
  heading,
  subHeading,
  type,
  field,
  onClick = () => {},
  ...rest
}) {
  const handleClick = useCallback(() => {
    onClick({ field: field, fieldType: type });
  }, [type]);

  return (
    <div className={styles.container} {...rest} onClick={handleClick}>
      <span className={styles.icon}>
        <Icon />
      </span>
      <p className={cn("text-body2", "font-weight-medium")}>{heading}</p>
      <p className={cn("text-body2", "color-gray-1700")}>{subHeading}</p>
    </div>
  );
}
