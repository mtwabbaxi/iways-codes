import React, { useEffect, useRef, useState } from "react";
import "./index.modules.scss";
import cn from "classnames";
import Modal from "@/components/shared/modal"; // Import your CSS for styling
import ErrorEl from "@/components/shared/error";
import { useDispatch } from "react-redux";
import {
  setCreateMediaOpen,
  setExistingMediaOpen,
  fetchAllMediaAsset,
} from "@/store/actions/media";
import Layout from "@/app/spaces/[spaceId]/environment/[spaceEnvironmentId]/content-entry/[contentModelId]/layout";
import CreateForm from "@/components/media/createForm/createForm";
import Sidebar_Right from "@/components/media/sidebar_right";
import { useParams } from "next/navigation";
import { AiFillCloseCircle } from "react-icons/ai";
import { useFormContext } from "react-hook-form";
import { Button } from "@/components/theme/buttons";
import { setContentSubmitButton } from "@/store/actions/contentEntry";

const SelectFileModule = ({
  label,
  required,
  allAssets,
  defaultValue,
  hint,
  onChange,
  error,
  value,
  localized = false,
  language = "English (United States) (en-US)",
  type = "",
  fieldId = "",
  referenceFieldForMedia = false,
  referenceImage = false,
}) => {
  const { clearErrors = () => {} } = useFormContext() || {};
  const [showPopup, setShowPopup] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const [showAsset, setShowAssets] = useState(false);
  const [showCreateAsset, setShowCreateAssets] = useState(false);
  const [showExistAsset, setShowExistAsset] = useState(false);
  const [existAsset, setExistAsset] = useState([]);
  const [selectedAssets, setSelectedAssets] = useState([]);
  const [selectingAssets, setSelectingAssets] = useState([]);
  const [newAsset, setNewAsset] = useState([]);
  const [newMedia, setNewMedia] = useState([]);
  const dispatch = useDispatch();
  const params = useParams();
  const { spaceId, spaceEnvironmentId } = params;

  const toggleDropdown = () => {
    setShowDropdown(!showDropdown);
  };

  const handleOptionClick = (option) => {
    if (option === "createNew") {
      setShowCreateAssets(!showCreateAsset);
    } else {
      setShowAssets(!showAsset);
    }
  };
  const togglePopup = () => {
    setShowPopup(!showPopup);
  };
  const handleSelectingAssets = (entry) => {
    // Check if the entry already exists in selectedEntries
    const entryIndex = selectingAssets.findIndex(
      (selectedEntry) => selectedEntry.assetId === entry.assetId
    );

    if (entryIndex !== -1) {
      // If the entry exists, remove it from selectedEntries
      const updatedEntries = [...selectingAssets];
      updatedEntries.splice(entryIndex, 1);
      setSelectingAssets(updatedEntries);
    } else {
      if (type === "ONE" && selectedAssets.length == 0) {
        setSelectingAssets([entry]);
        setSelectedAssets([entry]);
        setShowAssets(false);
      } else if (type === "MANY") {
        setSelectingAssets((prevSelectedAssets) => [
          ...prevSelectedAssets,
          entry,
        ]);
      }
    }
  };

  const handleSelectMediaFile = (entry) => {
    setShowExistAsset(true);
    setExistAsset(entry);
  };

  const handleSaveSelectedImages = () => {
    setSelectedAssets([...selectingAssets]);
    setShowAssets(false);
  };

  const handleClearSelected = () => {
    setSelectedAssets([]);
    setSelectingAssets([]);
    setShowAssets(false);
  };

  useEffect(() => {
    if (required && !selectedAssets.length) {
      onChange(undefined);
    } else {
      onChange(selectedAssets);
      if (fieldId && selectedAssets.length && clearErrors && required) {
        clearErrors(fieldId);
      }
    }
  }, [selectedAssets, allAssets]);

  useEffect(() => {
    if (defaultValue && type === "MANY") {
      // Set the default values when provided (for editing)

      const updatedSelectedAssets = defaultValue.map((selectedAsset) => {
        const matchingAsset = allAssets.content.find(
          (asset) => asset.assetId === selectedAsset.assetId
        );

        if (matchingAsset) {
          return {
            ...selectedAsset,
            ...matchingAsset,
          };
        }
        return selectedAsset;
      });

      setSelectingAssets(updatedSelectedAssets);
      setSelectedAssets(updatedSelectedAssets);
    } else if (defaultValue && type === "ONE") {
      setSelectingAssets(defaultValue);
      setSelectedAssets(defaultValue);
    }
  }, [defaultValue, allAssets]);

  useEffect(() => {
    if (newMedia?.length) {
      setSelectingAssets(newMedia);
      setSelectedAssets(newMedia);
    }
  }, [newMedia, allAssets]); // don't remove allAssets this is for handling new assets when we're in content entry - (create new)

  // useEffect(() => {
  //   dispatch(setContentSubmitButton(true));
  // }, [allAssets]);

  useEffect(() => {
    if (newAsset?.assetId) {
      if (type === "MANY") {
        const newData = [...selectedAssets, newAsset];
        setNewMedia([...newData]);
      } else {
        setNewMedia([newAsset]);
      }

      setNewAsset([]);
    }
  }, [newAsset]);

  useEffect(() => {
    const hasMatchingAsset = selectedAssets.some((selectedAsset) => {
      return allAssets.content.some((asset) => asset.url !== selectedAsset.url);
    });

    if (hasMatchingAsset) {
      dispatch(fetchAllMediaAsset(spaceId, spaceEnvironmentId));
    }
  }, [showExistAsset]);
  const handleRemoveImage = (entry) => {
    const updatedSelectedAssets = selectedAssets.filter(
      (asset) => asset.assetId !== entry.assetId
    );
    setSelectedAssets(updatedSelectedAssets);
    setSelectingAssets(updatedSelectedAssets);
  };

  return (
    <div className="file-upload-module">
      {label && (
        <label className={cn("font-weight-medium")}>
          {label}&nbsp;
          {required && (
            <span className={cn("color-gray-1100 font-weight-regular")}>
              (required)&nbsp;
            </span>
          )}
          {localized && (
            <span className="font-weight-regular color-gray-1100">
              | {language}
            </span>
          )}
        </label>
      )}
      <div className="dashed-border">
        <div className="selected-assets">
          {selectedAssets &&
            selectedAssets.map((entry, index) => {
              const isSelected = selectedAssets.some(
                (selectedEntry) => selectedEntry.assetId === entry.assetId
              );

              return (
                <div
                  key={index}
                  className={"asset-container"}
                  onClick={() => handleSelectMediaFile(entry)}
                >
                  <div className="content-model">
                    <div className="status">
                      <p
                        className={cn({
                          ["green"]: entry.status === "PUBLISHED",
                          ["yellow"]:
                            entry.status === "CHANGED" ||
                            entry.status === "DRAFT",
                        })}
                      >
                        {" "}
                        {entry.status}
                      </p>
                      <div
                        className="icon-container"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div
                          onClick={() => handleRemoveImage(entry)}
                          className="media_cross"
                        >
                          <AiFillCloseCircle />
                        </div>
                      </div>
                    </div>
                    <div className="asset">
                      <img src={entry.url} alt={"Asset"} />
                      <div className="asset-title">
                        {entry.title || "Untitled"}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
        </div>
        {type === "ONE" ? (
          !selectedAssets.length && (
            <>
              {" "}
              <button
                className="dropdown-button"
                type="button"
                onClick={toggleDropdown}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  fill="currentColor"
                  className="bi bi-plus"
                  viewBox="0 0 16 16"
                >
                  <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                </svg>
                Add Media
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  className="bi bi-chevron-down"
                  viewBox="0 0 16 16"
                >
                  <path
                    fillRule="evenodd"
                    d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"
                    fill="#000000"
                  ></path>
                </svg>
              </button>
              {showDropdown && (
                <div className="dropdown-content">
                  <button
                    className="dropdown-button"
                    type="button"
                    onClick={() => handleOptionClick("createNew")}
                  >
                    Create New
                  </button>
                  <button
                    className="dropdown-button"
                    type="button"
                    onClick={() => handleOptionClick("uploadExisting")}
                  >
                    Upload Existing
                  </button>
                </div>
              )}
            </>
          )
        ) : (
          <>
            {" "}
            <button
              className="dropdown-button"
              type="button"
              onClick={toggleDropdown}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                fill="currentColor"
                className="bi bi-plus"
                viewBox="0 0 16 16"
              >
                <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
              </svg>
              Add Media
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                fill="currentColor"
                className="bi bi-chevron-down"
                viewBox="0 0 16 16"
              >
                <path
                  fillRule="evenodd"
                  d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"
                  fill="#000000"
                ></path>
              </svg>
            </button>
            {showDropdown && (
              <div className="dropdown-content">
                <button
                  className="dropdown-button"
                  type="button"
                  onClick={() => handleOptionClick("createNew")}
                >
                  Create New
                </button>
                <button
                  className="dropdown-button"
                  type="button"
                  onClick={() => handleOptionClick("uploadExisting")}
                >
                  Upload Existing
                </button>
              </div>
            )}
          </>
        )}
      </div>
      {hint && (
        <span className="d-block color-gray-1200 mt-3 italic text-body2">
          {hint}
        </span>
      )}
      {error && <ErrorEl error={error} />}

      {showPopup && (
        <div className="file-popup">
          <h2>File Overview</h2>
          {/* Add content for file overview here */}
          <button onClick={togglePopup} type="button">
            Close
          </button>
        </div>
      )}
      {showAsset && (
        <Modal
          heading="Add existing assets"
          contentClassName="h-100 relative"
          onClose={() => setShowAssets(!showAsset)}
          size="lg"
        >
          {type === "MANY" && (
            <div className="action">
              <Button onClick={handleClearSelected} text="Clear" />
              <Button
                onClick={handleSaveSelectedImages}
                variant="primary"
                text={`Insert ${selectingAssets.length} assets`}
              />
            </div>
          )}
          <div className="all-assets">
            {allAssets &&
              allAssets.content.map((entry, index) => {
                const isSelected = selectingAssets.some(
                  (selectedEntry) => selectedEntry.assetId === entry.assetId
                );
                const entryClassName = cn("content-model", {
                  "selected-entry": isSelected,
                  "deselected-entry": !isSelected,
                });

                return (
                  <div
                    key={index}
                    className={"asset-container"}
                    onClick={() => handleSelectingAssets(entry)}
                  >
                    <div className={entryClassName}>
                      <div className="status">
                        <p
                          className={cn({
                            ["green"]: entry.status === "PUBLISHED",
                            ["yellow"]:
                              entry.status === "CHANGED" ||
                              entry.status === "DRAFT",
                          })}
                        >
                          {entry.status}
                        </p>
                      </div>
                      <div className="asset">
                        <img src={entry.url} alt={"Asset"} />
                        <div className="asset-title">
                          {entry.title || "Untitled"}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        </Modal>
      )}

      {showCreateAsset && (
        <Modal
          heading={"Create New"}
          contentClassNameMain={"createNewMediaMain"}
          contentClassName={"createNewMedia"}
          onClose={() => setShowCreateAssets(!showCreateAsset)}
          size={"md"}
        >
          <div className={"create_page"}>
            <div className={"content"}>
              <CreateForm
                onClose={() => setShowCreateAssets(!showCreateAsset)}
                isOpen={showCreateAsset}
                setNewAsset={setNewAsset}
                referenceImage={referenceImage}
              />
            </div>
            <div className={"create_sidebar_wrapper"}>
              <Sidebar_Right
                media={true}
                referenceFieldForMedia={referenceFieldForMedia}
                referenceImage={referenceImage}
              />
            </div>
          </div>
        </Modal>
      )}

      {showExistAsset && (
        <Modal
          heading={"Update Media"}
          contentClassNameMain={"createNewMediaMain"}
          contentClassName={"createNewMedia"}
          onClose={() => setShowExistAsset(!showExistAsset)}
          size={"md"}
        >
          <div className={"create_page"}>
            <div className={"content"}>
              <CreateForm
                onClose={() => setShowExistAsset(!showExistAsset)}
                isOpen={showExistAsset}
                existingMedia={existAsset}
                isEditMode={true}
              />
            </div>
            <div className={"create_sidebar_wrapper"}>
              <Sidebar_Right page="media" media={true} />
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};

export default SelectFileModule;
