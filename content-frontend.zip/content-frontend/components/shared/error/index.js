import cn from "classnames";
import styles from "./index.module.scss";
import { BiSolidErrorCircle } from "react-icons/bi";

export default function ErrorEl({ error }) {
  return (
    <span
      className={cn("d-block color-scarletRed-500 text-body2", styles.error)}
    >
      <BiSolidErrorCircle size="1.2em" className="color-scarletRed-300" />{" "}
      {error}
    </span>
  );
}
