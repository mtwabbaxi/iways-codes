import React from "react";
import "./index.modules.scss";

const Loader = () => {
  return (
    <div className="container">
      <div className="preloader"></div>
    </div>
  );
};

export default Loader;
