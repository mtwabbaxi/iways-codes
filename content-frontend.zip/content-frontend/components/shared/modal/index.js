"use client";

import styles from "./modal.module.scss";
import { IoMdClose } from "react-icons/io";
import cn from "classnames";

export default function Modal({
  children,
  heading = "",
  onClose = () => {},
  size = "md",
  contentClassName = "",
  contentClassNameMain = "",
}) {
  const handleClose = (e) => {
    e.preventDefault();
    e.stopPropagation();
    onClose();
  };
  return (
    <div className={cn(styles.container, styles[size])}>
      <div className={cn(styles.box, "bg-gray-100", contentClassNameMain)}>
        <div className={styles["heading-container"]}>
          <h4 className="m-0 font-weight-semi-bold">{heading}</h4>
          <div className={styles["close-icon"]} onClick={(e) => handleClose(e)}>
            <IoMdClose />
          </div>
        </div>
        <div
          className={cn(styles.content, contentClassName, {
            [styles.fieldsSettingForm]: contentClassName,
          })}
        >
          {children}
        </div>
      </div>
    </div>
  );
}
