import React, { useEffect, useState } from "react";
import CKeditor from "@/components/CKeditor/CKeditor";
import cn from "classnames";
import "./index.modules.scss";
import ErrorEl from "@/components/shared/error";
export default function RichTextEditorField({
  label,
  required,
  defaultValue,
  hint,
  error,
  localized = false,
  language = "English (United States) (en-US)",
  ...rest
}) {
  const [editorLoaded, setEditorLoaded] = useState(false);
  const [data, setData] = useState("");
  useEffect(() => {
    setEditorLoaded(true);
  }, []);
  return (
    <div className="container">
      {label && (
        <label className={cn("font-weight-medium")}>
          {label}&nbsp;
          {required && (
            <span className={cn("color-gray-1100 font-weight-regular")}>
              (required)&nbsp;
            </span>
          )}
          {localized && (
            <span className="font-weight-regular color-gray-1100">
              | {language}
            </span>
          )}
        </label>
      )}
      <CKeditor
        name="description"
        onChange={(data) => {
          setData(data);
        }}
        editorLoaded={editorLoaded}
        defaultValue={defaultValue}
        {...rest}
      />
      {hint && (
        <span className="d-block color-gray-1200 mt-3 italic text-body2">
          {hint}
        </span>
      )}
      {error && <ErrorEl error={error} />}
    </div>
  );
}
