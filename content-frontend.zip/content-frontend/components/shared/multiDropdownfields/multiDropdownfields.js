import { useState, useEffect } from "react";
import styles from "./multiDropdownfields.module.scss";
import { AiOutlineUp, AiOutlineDown } from "react-icons/ai";
import { FaAngleDown, FaAngleUp } from "react-icons/fa6";

const MultiDropdownFields = ({
  data,
  selectedValues,
  setSelectedValues,
  existValues,
  title,
  required,
}) => {
  if (!data) {
    return false;
  }

  const [isOpen, setIsOpen] = useState(false);

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  const onChangeHandler = (selectedOption) => {
    const updatedValues = [...selectedValues];

    if (updatedValues.includes(selectedOption)) {
      updatedValues.splice(updatedValues.indexOf(selectedOption), 1);
    } else {
      updatedValues.push(selectedOption);
    }

    setSelectedValues(updatedValues);
  };

  useEffect(() => {
    if (existValues?.length > 0) {
      setSelectedValues(existValues);
    }
  }, []);

  // useEffect(() => {
  //   if (data) {
  //     const initialSelectedValues = data.flatMap((group) =>
  //       group.options.map((option) => option.value)
  //     );

  //     setSelectedValues(initialSelectedValues);
  //   }
  // }, []);

  return (
    <>
      <div className={styles.container}>
        <div className={styles.wrapper}>
          <label htmlFor="env" className={styles.selectLabel}>
            {title} {required && <span>(required)</span>}
          </label>
          <button
            type="button"
            className={styles.toggleButton}
            onClick={toggleDropdown}
          >
            <span>Select Content Type(s)</span>
            <span>{isOpen ? <FaAngleUp /> : <FaAngleDown />}</span>
          </button>
          {isOpen && (
            <div className={styles.dropdown}>
              <div className={styles.checkboxContainer}>
                {data &&
                  data?.map((group, groupIndex) => (
                    <div key={groupIndex} className={styles.groupContainer}>
                      {group?.options &&
                        group?.options?.map((option, optionIndex) => (
                          <div
                            key={optionIndex}
                            className={styles.checkboxOption}
                          >
                            <input
                              type="checkbox"
                              id={option?.id}
                              value={option?.value}
                              checked={selectedValues.includes(option?.value)}
                              onChange={() => onChangeHandler(option?.value)}
                            />
                            <label htmlFor={option?.id}>{option?.label}</label>
                          </div>
                        ))}
                    </div>
                  ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default MultiDropdownFields;
