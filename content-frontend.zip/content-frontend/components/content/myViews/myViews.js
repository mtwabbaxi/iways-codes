import React from "react";
import styles from "./myViews.module.scss";

const MyViews = () => {
  return (
    <>
      <div className={styles.MyViews}>
        <ul>
          <li>Created by me</li>
          <li>Updated by me</li>
        </ul>
      </div>
    </>
  );
};

export default MyViews;
