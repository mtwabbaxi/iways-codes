import styles from "./confirmPopup.module.scss"
import {IoMdClose} from "react-icons/io"

const ConfirmPopup = ({
	setIsContentDeletePopupOpen,
	setisDeleteConfirmed,
	message,
}) => {
	const handleOverlayClick = (e) => {
		if (!e.target.closest(`.${styles.deleteConfirmPopup}`)) {
			setIsContentDeletePopupOpen(false)
		}
	}

	return (
		<div className={styles.container}>
			<div
				className={`${styles.overlay} ${styles.isContentDeletePopupOpen}`}
				onClick={handleOverlayClick}
			>
				<div className={styles.deleteConfirmPopup}>
					<div className={styles.header}>
						<h1>Confirm Deletion</h1>
						<button
							className={styles.closeIcon}
							onClick={() => setIsContentDeletePopupOpen(false)}
						>
							<IoMdClose />
						</button>
					</div>
					<hr />
					<div className={styles.content}>
						<p>
							{message
								? message
								: "Are you sure you want to delete this content?"}
						</p>
						<div className={styles.buttonGroup}>
							<button
								className={styles.confirmButton}
								onClick={() => setisDeleteConfirmed(true)}
							>
								Confirm
							</button>
							<button
								className={styles.cancelButton}
								onClick={() => setIsContentDeletePopupOpen(false)}
							>
								Cancel
							</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	)
}

export default ConfirmPopup
