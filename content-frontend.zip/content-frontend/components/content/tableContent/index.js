"use client";

import { useState, useEffect } from "react";
import Header from "@/components/contentModel/header";
import { DataTable } from "@/components/theme/datatable";
import { useParams, useRouter } from "next/navigation";
import { APP_URLS, replaceUrlParams } from "@/utils/constants";
import NoSearchedData from "@/components/contentModel/tableContentModel/NoSearchedData";
import {
  deleteField,
  fetchAllContentModels,
} from "@/store/actions/contentModel";
import { useDispatch, useSelector } from "react-redux";
import styles from "./tableContent.module.scss";
import { format, formatDistance, formatRelative, subDays } from "date-fns";
import {
  FaChevronLeft,
  FaChevronRight,
  FaChevronUp,
  FaChevronDown,
} from "react-icons/fa";

import {
  UpdateMultipleContentEntryStatus,
  addSortingContentEntry,
  deleteContentEntry,
  deleteMultipleContentEntry,
  revertMultipleContentEntry,
  fetchAllContentEntries,
} from "@/store/actions/contentEntry";
import { setCreateMediaOpen } from "@/store/actions/media";
import { ContextMenu } from "@/components/theme/menus";
import { useToast } from "@/context/toastContext";
import ConfirmPopup from "../confirmPopup/confirmPopup";
import { Checkbox } from "@/components/theme/form-inputs";
import OptionRow from "../../sharedComponents/optionRow";

export default function TableContent() {
  const dispatch = useDispatch();
  const router = useRouter();
  const { addToast } = useToast();
  const [filteredData, setFilteredData] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 50;
  const { searchNameContent } = useSelector((state) => state.contentModel);
  const { spaceId, spaceEnvironmentId } = useParams();
  const [isContentDeletePopupOpen, setIsContentDeletePopupOpen] =
    useState(false);
  const [currRow, setCurrRow] = useState("");
  const [isDeleteConfirmed, setisDeleteConfirmed] = useState(false);
  const { contentEntries, filterValue, sortBy, filters } = useSelector(
    (state) => state.contentEntries
  );

  const startIdx = (currentPage - 1) * itemsPerPage;
  const endIdx = startIdx + itemsPerPage;
  const displayedData = filteredData?.slice(startIdx, endIdx);
  const totalPages = Math.ceil(filteredData?.length / itemsPerPage);
  const [selectedEntries, setSelectedEntries] = useState([]);
  const [selectAll, setSelectAll] = useState(false);

  const handleSort = (key) => {
    const newSortOrder = sortBy?.[key] === "ASC" ? "DESC" : "ASC";
    dispatch(addSortingContentEntry(key, newSortOrder));
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handleDelete = async (row) => {
    try {
      let res = null;
      const data = {
        contentModelId: row.contentModelId,
        contentEntryId: row.contentEntryId,
      };
      res = await dispatch(
        deleteContentEntry(data, spaceId, spaceEnvironmentId)
      );
      const {
        result: { body },
      } = res;
      if (body.responseCode === 200) {
        addToast(body.responseMessage);
        dispatch(
          fetchAllContentEntries(spaceId, spaceEnvironmentId, {
            filters,
            sortBy,
          })
        );
      } else {
        addToast(body?.responseMessage || "An unknown error occured!", {
          type: "error",
        });
      }
    } catch (err) {
      console.log("error: ", err);
    } finally {
      setIsContentDeletePopupOpen(false);
      setisDeleteConfirmed(false);
    }
  };

  const handleDeleteConfirmPopup = async (row) => {
    setIsContentDeletePopupOpen(true);
    setCurrRow(row);
    dispatch(setCreateMediaOpen(false));
  };

  const isChecked = (id) => {
    return Boolean(selectedEntries.filter((s) => s?.id === id).length);
  };

  const handleAllSelect = (e) => {
    const { value } = e.target;
    if (value === "false") {
      setSelectAll(true);
      const allIds = displayedData.map((d) => {
        return {
          id: d?.contentEntryId,
          status: d?.status,
          modelId: d?.contentModel,
        };
      });
      setSelectedEntries(allIds);
    } else {
      setSelectAll(false);
      setSelectedEntries([]);
    }
  };

  const handleSelection = (entry) => {
    if (isChecked(entry?.contentEntryId)) {
      const currentSelection = selectedEntries.filter(
        (s) => s?.id !== entry?.contentEntryId
      );
      setSelectedEntries(currentSelection);
    } else {
      setSelectedEntries([
        ...selectedEntries,
        {
          id: entry?.contentEntryId,
          status: entry?.status,
          modelId: entry?.contentModelId,
        },
      ]);
    }
  };

  const columns = [
    {
      title: (
        <Checkbox
          id="all"
          value={selectAll}
          onChange={(e) => handleAllSelect(e)}
        />
      ),
      key: "select",
      styles: {
        paddingLeft: "0.5rem",
        width: "1%",
      },
      render: (contentEntries) => {
        return (
          <div className={styles.name}>
            <div className="font-weight-medium">
              <Checkbox
                id={contentEntries.contentEntryId}
                checked={isChecked(contentEntries.contentEntryId)}
                onChange={() => handleSelection(contentEntries)}
              />
            </div>
          </div>
        );
      },
    },
    {
      title: "Name",
      key: "name",
      styles: {
        paddingLeft: "1.5rem",
        // width: "20%",
      },
      render: (contentEntries) => {
        return (
          <div
            className={styles.name}
            onClick={() => rowClickHandler(contentEntries)}
          >
            <div className="font-weight-medium">{contentEntries.name}</div>
          </div>
        );
      },
    },
    {
      title: (
        <div className={styles["content-type"]}>
          <p>Content Type</p>
        </div>
      ),
      key: "contentType",
      render: (contentEntries) => {
        return (
          <div className={styles.name}>
            <div className="font-weight-medium">
              {contentEntries.contentModelName}
            </div>
          </div>
        );
      },
    },
    {
      title: (
        <div
          className={styles.sortableColumn}
          onClick={() => handleSort("lastModifiedDate")}
        >
          Updated
          {sortBy?.lastModifiedDate === "ASC" ? (
            <FaChevronUp className={styles.icon} />
          ) : (
            <FaChevronDown className={styles.icon} />
          )}
        </div>
      ),
      key: "lastModifiedDate",
      render: (data) => {
        return (
          <div>
            {formatDistance(
              subDays(new Date(data.lastModifiedDate), 0),
              new Date(),
              { addSuffix: true }
            )}
          </div>
        );
      },
    },
    {
      title: "Last Updated By",
      key: "lastUpdatedBy",
      render: (contentEntries) => {
        return <div>{contentEntries.lastUpdatedBy || "-"}</div>;
      },
    },
    {
      title: "Status",
      key: "status",
      render: (contentEntries) => {
        const currStatus = contentEntries?.status.toLowerCase();
        return (
          <div className={`${styles[currStatus]}`}>{contentEntries.status}</div>
        );
      },
    },
    {
      title: "",
      key: "actions",
      render: (row) => {
        const menuOptions = [
          // {id: 1, title: "Delete", onClick: () => handleDelete(row)},
          {
            id: 1,
            title: "Delete",
            onClick: () => handleDeleteConfirmPopup(row),
          },
          {
            id: 2,
            title: <span style={{ width: "max-content" }}>Edit Entry</span>,
            onClick: () => rowClickHandler(row),
          },
        ];
        return (
          <div className={styles["col-actions"]}>
            <ContextMenu options={menuOptions} />
          </div>
        );
      },
    },
  ];

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handlePageChange = (page) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  useEffect(() => {
    dispatch(fetchAllContentModels(spaceId, spaceEnvironmentId));
    dispatch(setCreateMediaOpen(false));
  }, []);

  useEffect(() => {
    dispatch(
      fetchAllContentEntries(spaceId, spaceEnvironmentId, { filters, sortBy })
    );
  }, [sortBy, filters]);

  const rowClickHandler = (row) => {
    console.log({ row });
    if (row.contentModelId) {
      router.push(
        replaceUrlParams(APP_URLS.CONTENT.UPDATE, {
          spaceId: spaceId,
          spaceEnvironmentId: spaceEnvironmentId,
          contentModelId: row.contentModelId,
          contentEntryId: row.contentEntryId,
        })
      );
    }
  };

  useEffect(() => {
    // Initialize filteredData with contentEntries.content
    setFilteredData(contentEntries?.content);
    // Set search text to empty when there is no filter or when filterValue is empty
    setSearchText("");
    setSelectedEntries([]);
  }, [contentEntries]);

  useEffect(() => {
    if (isDeleteConfirmed) {
      handleDelete(currRow);
    } else {
      setIsContentDeletePopupOpen(false);
      setCurrRow("row");
    }
  }, [isDeleteConfirmed]);

  const handleSelectionDelete = async () => {
    const data = {
      contentEntryIds: selectedEntries.map((e) => e?.id),
      spaceId,
      spaceEnvironmentId,
    };
    try {
      const res = await dispatch(deleteMultipleContentEntry(data));
      console.log(res);
      if (res?.result?.body?.responseCode === 200) {
        addToast(res?.result?.body?.responseMessage);
        await dispatch(
          fetchAllContentEntries(spaceId, spaceEnvironmentId, {
            filters,
            sortBy,
          })
        );
      }
    } catch (error) {
      console.log({ error });
    } finally {
      setSelectedEntries([]);
    }
  };

  const handleSelectionRevert = async () => {
    const data = {
      contentEntryIds: selectedEntries.map((e) => e?.id),
      contentModelId: selectedEntries[0].modelId,
      spaceId,
      spaceEnvironmentId,
    };
    try {
      const res = await dispatch(revertMultipleContentEntry(data));
      console.log(res);
      if (res?.result?.body?.responseCode === 200) {
        addToast(res?.result?.body?.responseMessage);
        await dispatch(
          fetchAllContentEntries(spaceId, spaceEnvironmentId, {
            filters,
            sortBy,
          })
        );
      } else {
        addToast(res?.result?.body?.responseMessage);
      }
    } catch (error) {
      console.log({ error });
    } finally {
      setSelectedEntries([]);
    }
  };

  const handleSelectionPublishOrUnpublish = async (status) => {
    const data = {
      contentEntryIds: selectedEntries.map((e) => e?.id),
      spaceId,
      spaceEnvironmentId,
      status,
    };
    try {
      const res = await dispatch(UpdateMultipleContentEntryStatus(data));
      console.log(res);
      if (res?.result?.body?.responseCode === 200) {
        addToast(res?.result?.body?.responseMessage);
        await dispatch(
          fetchAllContentEntries(spaceId, spaceEnvironmentId, {
            filters,
            sortBy,
          })
        );
      }
    } catch (error) {
      console.log({ error });
    } finally {
      setSelectedEntries([]);
    }
  };

  return (
    <div className={styles.TableContent}>
      {/* <Header searchText={searchText} onSearchChange={handleSearchChange} /> */}

      {Boolean(!displayedData?.length) && <NoSearchedData />}
      {Boolean(selectedEntries.length) && (
        <OptionRow
          handleDelete={handleSelectionDelete}
          handleUnPublish={handleSelectionPublishOrUnpublish}
          handlePublish={handleSelectionPublishOrUnpublish}
          handleRevert={handleSelectionRevert}
          selectedEntries={selectedEntries}
        />
      )}
      {displayedData?.length > 0 && (
        <>
          <DataTable
            // rowClickHandler={rowClickHandler}
            columns={columns}
            dataSource={displayedData}
          />
          <div className={styles.pagination}>
            <span>{`${startIdx + 1} - ${startIdx + displayedData.length} of ${
              filteredData.length
            } items`}</span>
            {filteredData.length > itemsPerPage && (
              <>
                <button onClick={handlePrevPage} disabled={currentPage === 1}>
                  <FaChevronLeft />
                </button>
                <button
                  onClick={handleNextPage}
                  disabled={currentPage === totalPages}
                >
                  <FaChevronRight />
                </button>
              </>
            )}
          </div>
        </>
      )}

      {isContentDeletePopupOpen && (
        <ConfirmPopup
          setIsContentDeletePopupOpen={setIsContentDeletePopupOpen}
          setisDeleteConfirmed={setisDeleteConfirmed}
        />
      )}
    </div>
  );
}
