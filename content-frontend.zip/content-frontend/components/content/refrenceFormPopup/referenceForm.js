"use client";
import React, { useContext, useEffect, useMemo, useState } from "react";
import { FormProvider, useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { Radio, TextArea, TextField } from "@/components/theme/form-inputs";
import { Button } from "@/components/theme/buttons";
import styles from "./referenceForm.module.scss";
import cn from "classnames";
import { useToast } from "@/context/toastContext";
import SelectFileModule from "@/components/shared/selectFileModule";
import {
  addField,
  createContentModel,
  fetchAllContentModels,
  getContentModelById,
  getContentModelByIdForReference,
  modifyselectedContentModelForReference,
  resetselectedContentModelForReference,
  updateContentModel,
  updateField,
} from "@/store/actions/contentModel";
import { useDispatch, useSelector } from "react-redux";
import { useParams, useRouter } from "next/navigation";
import RichTextEditorField from "@/components/shared/richTextfield";
import CustomDateField from "@/components/shared/dateField";
import ReferenceField from "@/components/shared/refrerenceField";
import CreatePage_top_Tabs from "@/components/media/createPage_top_Tabs/createPage_top_Tabs";
import {
  createContentEntry,
  fetchAllContentEntries,
  getContentEntryById,
  setContentEntryStatus,
  updateContentEntry,
  setCurrTitle,
  setContentSubmitButton,
  setReferenceContentSubmitButton,
} from "@/store/actions/contentEntry";
import {
  APP_URLS,
  formatOptions,
  getLocaleByCode,
  replaceUrlParams,
  timeModeOptions,
} from "@/utils/constants";
import { AiFillGolden, AiOutlineTag } from "react-icons/ai";
import { fetchAllMediaAsset } from "@/store/actions/media";
import JsonField from "@/components/shared/jsonField";
import { VscReferences } from "react-icons/vsc";
import BooleanField from "@/components/shared/booleanField";
import { triggerFormSubmissionForReference } from "@/store/actions/form";
import Sidebar_Right from "@/components/media/sidebar_right";

const generateFieldValidationSchema = (field) => {
  if (field.required) {
    switch (field.fieldType) {
      case "TEXT":
        return yup
          .string()
          .required(`${field.name} is required`)
          .max(256, `${field.name} must be at most 256 characters long`);
      case "RICH_TEXT":
        return yup
          .mixed()
          .test(
            "is-rich-text-populated",
            `${field.name} is required`,
            (value) => {
              // Implement your custom validation logic here
              // You can check if the "content" field contains data as per your requirement
              return value && value.content && value.content.length > 0;
            }
          );
      case "NUMBER":
        return yup.string().required(`${field.name} is required`);
      case "DATETIME":
        return yup.string().required(`${field.name} is required`);
      case "MEDIA":
        return yup
          .array()
          .of(yup.object().shape({}))
          .required(`${field.name} is required`);
      case "BOOLEAN":
        return yup
          .boolean()
          .required(`${field.name} is required`)
          .transform((originalValue, originalObject) => {
            return typeof originalValue !== "boolean" ? null : originalValue;
          })
          .test(
            "is-boolean",
            `${field.name} is required`,
            (value) => typeof value === "boolean"
          );
      case "JSON":
        return yup
          .mixed()
          .test("is-json-populated", `Enter a valid JSON format`, (value) => {
            try {
              JSON.parse(value);
              return true;
            } catch (error) {
              return false;
            }
          })
          .required(`${field.name} is required`);
      case "REFERENCE":
        return yup
          .mixed()
          .test("is-reference", `${field.name} is required`, (value) => {
            if (Array.isArray(value) && value.length > 0) {
              return value.every(
                (item) =>
                  item.contentEntryId &&
                  item.contentModelId &&
                  item.contentModelName &&
                  item.name
              );
            }
            return false;
          })
          .required(`${field.name} is required`);
      default:
        return yup.mixed(); // Handle other field types as needed
    }
  } else {
    switch (field.fieldType) {
      case "TEXT":
        return yup.string();
      case "BOOLEAN":
        return yup.boolean();
      case "NUMBER":
        return yup.string();
      case "DATETIME":
        return yup.string();
      case "MEDIA":
        return yup.array().of(yup.object().shape({}));
      default:
        return yup.mixed(); // Handle other field types as needed
    }
  }
};

const generateYupValidationSchema = (fields) => {
  const schemaShape = {};
  if (fields)
    fields.forEach((field) => {
      schemaShape[field.id] = generateFieldValidationSchema(field);
      if ("details" in field) {
        schemaShape[field.id + " - details"] = yup.mixed();
      }
    });

  return yup.object().shape(schemaShape);
};

export default function ReferenceForm({
  onClose = () => {},
  isEditMode = false,
  fields,
  page,
  ReferenceContentModelId,
  handleClose = () => {},
  handleCreateNewEntry = () => {},
  type,
  referenceFieldForMedia = false,
}) {
  const [addFieldsForOtherLanguages, setAddFieldsForOtherLanguages] = useState(
    []
  );

  const params = useParams();
  let { spaceId, spaceEnvironmentId } = params;

  const [contentModelId, setContentModelId] = useState("");
  const [fieldsStructure, setFieldsStructure] = useState({});

  // FETCH FIELDS STRUCTURE TO DRAW THE FORM
  useEffect(() => {
    const getContentModel = async () => {
      const { result: res } = await dispatch(
        getContentModelByIdForReference(
          ReferenceContentModelId,
          spaceId,
          spaceEnvironmentId
        )
      );

      if (res && res.body.responseCode === 200) {
        console.log("response", res.body.response);
        setFieldsStructure(res.body.response);
      }
    };

    if (ReferenceContentModelId) {
      getContentModel();
    }
  }, [ReferenceContentModelId]);

  useEffect(() => {
    if (ReferenceContentModelId) {
      setContentModelId(ReferenceContentModelId);
    }
  }, [ReferenceContentModelId]);

  const {
    contentEntryValues,
    contentEntries,
    contentEntryStatus,
    contentSubmitButton,
  } = useSelector((state) => state.contentEntries);

  const { shouldSubmitForm, shouldSubmitFormForReference } = useSelector(
    (state) => state.form
  );
  const { allAssets, mediaCreateOpen } = useSelector((state) => state.media);

  const dispatch = useDispatch();
  const router = useRouter();

  const { addToast } = useToast();

  const { contentEntrySelectedLanguages = [] } =
    useSelector((state) => state.locales) || {};

  const setNullOrValuesForFields = (type, value) => {
    if (
      value instanceof Object &&
      !(value instanceof Array) &&
      (type === "MEDIA" || type === "REFERENCE")
    ) {
      let data = [];
      if (Object.keys(value).length) {
        data.push(value);
      }
      return data;
    } else if (
      value !== null ||
      value !== undefined ||
      typeof value === "boolean" ||
      value?.length > 0 ||
      typeof value === "number"
    ) {
      if (typeof value === "number") {
        return value.toString();
      }
      return value;
    }
    // set null for fields
    switch (type) {
      case "MEDIA":
        return undefined;
      case "TEXT":
        return "";
      case "NUMBER":
        return "";
      case "REFERENCE":
        return undefined;
      case "DATETIME":
        return "";
      case "RICH_TEXT":
        return "";
      case "JSON":
        return undefined;
      default:
        return "";
    }
  };

  const handleLateronAddedDateFieldDefaultValue = (
    dValues,
    selectedModelsFields,
    contentEntrySelectedLanguages
  ) => {
    selectedModelsFields?.forEach((fieldData) => {
      if (fieldData?.fieldType === "DATETIME") {
        contentEntrySelectedLanguages.forEach((lang) => {
          const isEnglish = lang === "en-US";
          const id = isEnglish ? fieldData?.id : fieldData?.id + ` - (${lang})`;
          if (!(id in dValues)) {
            dValues[id] = "";
            dValues[id + " - details"] = {
              ...fieldData?.details,
              time_mode: fieldData?.details?.time_mode?.id,
              format: fieldData?.details?.format?.id,
              timeInput: "",
              date: "",
              utcFormat: "",
            };
          }
        });
      }
    });
  };

  const defaultValues = useMemo(() => {
    let initialValues = {};

    if (!isEditMode && fieldsStructure?.fields?.length > 0) {
      (fieldsStructure?.fields || []).forEach((fieldData, i) => {
        initialValues[fieldData.id] = setNullOrValuesForFields(
          fieldData?.fieldType,
          fieldData?.value?.length === 0 ? undefined : fieldData.value
        );
        if (contentEntrySelectedLanguages?.length > 1 && fieldData?.localized) {
          contentEntrySelectedLanguages.forEach((lang) => {
            if (lang !== "en-US") {
              initialValues[fieldData.id + ` - (${lang})`] =
                setNullOrValuesForFields(fieldData?.fieldType, undefined);
              if ("details" in fieldData) {
                initialValues[fieldData.id + ` - (${lang}) - details`] = {
                  ...fieldData?.details,
                  date: "",
                  utcFormat: "",
                  timeInput: "",
                  format: fieldData?.details?.format?.id,
                  time_mode: fieldData?.details?.time_mode?.id,
                };
              }
            }
          });
        }
        if ("false_custom_label" in fieldData) {
          initialValues["false_custom_label"] = fieldData?.false_custom_label;
        }
        if ("true_custom_label" in fieldData) {
          initialValues["true_custom_label"] = fieldData?.true_custom_label;
        }
        if ("details" in fieldData) {
          initialValues[fieldData.id + " - details"] = {
            ...fieldData?.details,
            format: fieldData?.details?.format?.id,
            time_mode: fieldData?.details?.time_mode?.id,
          };
        }
      });
      return initialValues;
    }
    // Loop through contentEntryData.languageData and set field values
    if (
      contentEntryValues?.languageData &&
      contentEntryValues.languageData.length > 0
    ) {
      const fieldForOtherLanguages = [];
      contentEntrySelectedLanguages.forEach((lang) => {
        const getContentData =
          contentEntryValues?.languageData.find((c) => c?.languageCode === lang)
            ?.contentData || [];
        fieldForOtherLanguages.push({
          contentData: [...getContentData],
          languageCode: lang,
        });
      });
      fieldForOtherLanguages.forEach((item) => {
        item.contentData.forEach((fieldData) => {
          let isEnglish = item.languageCode === "en-US";
          let fieldId = isEnglish
            ? fieldData.fieldId
            : fieldData?.fieldId + ` - (${item.languageCode})`;
          let detailsId = isEnglish
            ? fieldData.fieldId + " - details"
            : fieldData?.fieldId + ` - (${item.languageCode}) - details`;

          initialValues[fieldId] = setNullOrValuesForFields(
            fieldData?.fieldType,
            fieldData.fieldValue.value
          );

          const findDetails =
            fieldsStructure?.fields?.find(
              (m) => m?.id === fieldData?.fieldId
            ) || {};

          if ("details" in fieldData?.fieldValue) {
            initialValues[detailsId] = {
              ...fieldData?.fieldValue?.details,
              format: findDetails?.details?.format?.id,
              time_mode: findDetails?.details?.time_mode?.id,
            };
          }
        });
      });
      // handle default values for later on added date field
      handleLateronAddedDateFieldDefaultValue(
        initialValues,
        fieldsStructure?.fields,
        contentEntrySelectedLanguages
      );

      return initialValues;
    }
  }, [
    contentEntryValues,
    fieldsStructure?.fields,
    contentEntrySelectedLanguages,
  ]);

  const methods = useForm({
    defaultValues,
    mode: "onChange",
    resolver: yupResolver(
      generateYupValidationSchema(
        addFieldsForOtherLanguages.length > 0 && addFieldsForOtherLanguages
      )
    ),
  });

  const {
    reset,
    setValue,
    watch,
    handleSubmit,
    control,
    formState: { errors, touchedFields, isValid },
  } = methods;
  const currTitle = methods.watch("title");
  const currentFormValues = watch();

  // useEffect(() => {
  //   if (shouldSubmitFormForReference) {
  //     handleSubmit(onSubmit)();
  //     // const submitButton = document.getElementById(
  //     //   "submit-content-button-reference"
  //     // );
  //     // setTimeout(() => {
  //     //   if (submitButton) {
  //     //     submitButton.click();
  //     //   }
  //     // }, 500);
  //     // dispatch(triggerFormSubmissionForReference()); // Reset the trigger
  //   }
  // }, [shouldSubmitFormForReference]);

  useEffect(() => {
    dispatch(fetchAllContentEntries(spaceId, spaceEnvironmentId));
    dispatch(fetchAllMediaAsset(spaceId, spaceEnvironmentId));
    dispatch(fetchAllContentModels(spaceId, spaceEnvironmentId));
  }, [contentModelId]);

  useEffect(() => {
    reset(defaultValues);
  }, [reset, defaultValues]);

  useEffect(() => {
    if (currTitle?.length > 0) {
      dispatch(setCurrTitle(currTitle));
    } else {
      dispatch(setCurrTitle(""));
    }
  }, [currTitle]);

  const getValue = (item, values) => {
    if (item?.type === "INTEGER" || item?.type === "DECIMAL") {
      return Number(values[item.id]);
    } else if (item?.fieldType === "MEDIA" && item.type === "ONE") {
      return values[item.id]?.[0] || {};
    } else if (item?.fieldType === "REFERENCE" && item.type === "ONE") {
      return values[item.id]?.[0] || {};
    } else {
      return values[item.id];
    }
  };

  const onSubmit = async (values) => {
    let entryTitleName;
    const textFields = fieldsStructure.fields.filter(
      (item) => item.fieldType === "TEXT"
    );

    if (textFields.length > 0) {
      const firstTextField = textFields[0];
      const firstTextFieldValue = values?.[firstTextField?.id];
      entryTitleName = firstTextFieldValue;
    }

    let sendDataforOtherLanguages = [];
    sendDataforOtherLanguages = contentEntrySelectedLanguages.map((lang) => {
      const isEnglish = lang === "en-US";
      const filteredFields = isEnglish
        ? fieldsStructure.fields
        : addFieldsForOtherLanguages.filter(
            (item) => lang === item.languageCode && lang !== "en-US"
          );

      return {
        languageCode: lang,
        contentData: filteredFields.map((item) => {
          const pattern = /(.*) -.*/;
          return {
            fieldId: isEnglish ? item.id : item.id.replace(pattern, "$1"),
            fieldType: item.fieldType,
            fieldName: item.name,
            type: item.type,
            localized: item.localized,
            fieldValue: {
              value: getValue(item, values),
              ...(item.fieldType === "DATETIME"
                ? {
                    details: {
                      ...values?.[item.id + " - details"],
                      format:
                        formatOptions[values?.[item.id + " - details"]?.format],
                      time_mode:
                        timeModeOptions[
                          values?.[item.id + " - details"]?.time_mode
                        ],
                    },
                  }
                : {}),
            },
          };
        }),
      };
    });

    const data = {
      contentModelId: contentModelId,
      contentModelName: fieldsStructure.name,
      name: entryTitleName ? entryTitleName : "Untitled",
      status: contentEntryStatus,
      languageData: [...sendDataforOtherLanguages],
    };

    try {
      let res = await dispatch(
        createContentEntry(data, spaceId, spaceEnvironmentId)
      );

      const {
        result: { body = {} },
      } = res || {};
      if (body.responseCode === 200) {
        const {
          contentEntryId,
          contentModelId,
          contentModelName,
          createdBy,
          createdDate,
          lastModifiedDate,
          lastUpdatedBy,
          name,
          status,
        } = body.response;
        const data = {
          contentEntryId,
          contentModelId,
          contentModelName,
          createdBy,
          createdDate,
          lastModifiedDate,
          lastUpdatedBy,
          name,
          status,
        };
        addToast(body.responseMessage);
        // dispatch(setContentSubmitButton(true));
        dispatch(setReferenceContentSubmitButton(false));
        handleClose();
        handleCreateNewEntry(type === "ONE" ? data : data);
        dispatch(fetchAllContentEntries(spaceId, spaceEnvironmentId));
      } else {
        addToast(body?.responseMessage || "An unknown error occured!", {
          type: "error",
        });
      }
      ``;
    } catch (err) {
      console.log("error: ", err);
    } finally {
    }
  };

  const sidebarOptions_Content = [
    { title: "Editor", icon: <AiFillGolden /> },
    { title: "References", icon: <VscReferences /> },
    { title: "Tags", icon: <AiOutlineTag /> },
  ];

  useEffect(() => {
    if (!isEditMode) {
      dispatch(setContentEntryStatus("DRAFT"));
    }
  }, [isEditMode]);

  useEffect(() => {
    if (fieldsStructure?.fields?.length > 0) {
      // en-US default thats why check is greater than 1
      if (contentEntrySelectedLanguages?.length > 1) {
        const addFieldsForOtherLang = [];
        fieldsStructure?.fields.forEach((fieldData) => {
          if (fieldData?.localized) {
            addFieldsForOtherLang.push({ ...fieldData });
            contentEntrySelectedLanguages.forEach((lang) => {
              if (lang === "en-US") return;
              addFieldsForOtherLang.push({
                ...fieldData,
                id: fieldData?.id + ` - (${lang})`,
                languageCode: lang,
                value: null,
              });
            });
          } else {
            addFieldsForOtherLang.push({ ...fieldData });
          }
        });
        setAddFieldsForOtherLanguages(addFieldsForOtherLang);
      } else {
        setAddFieldsForOtherLanguages([...fieldsStructure?.fields]);
      }
    }
  }, [fieldsStructure?.fields, contentEntrySelectedLanguages]);
  useEffect(() => {
    dispatch(setContentSubmitButton(false));
  }, []);
  return (
    <>
      <CreatePage_top_Tabs options={sidebarOptions_Content} />
      <FormProvider {...methods}>
        <form
          className={styles.form}
          onSubmit={(e) => {
            handleSubmit(onSubmit);
            e.preventDefault();
          }}
        >
          <div className={styles.form_main}>
            {addFieldsForOtherLanguages?.length > 0 &&
              addFieldsForOtherLanguages.map((item) => (
                <div key={item.id} className="mb-5">
                  <Controller
                    name={item.id}
                    control={control}
                    render={({ field, fieldState }) => {
                      switch (item.fieldType) {
                        case "TEXT":
                          return (
                            <TextField
                              {...field}
                              label={item.name}
                              required={item.required}
                              error={errors[item.id]?.message}
                              hint={item.helpText}
                              // value={item.value}
                              applyLimit
                              localized={item.localized}
                              language={getLocaleByCode(item?.languageCode)}
                            />
                          );
                        case "RICH_TEXT":
                          return (
                            <RichTextEditorField
                              {...field}
                              label={item.name}
                              required={item.required}
                              defaultValue={
                                isEditMode && defaultValues?.[item.id]
                              }
                              error={errors[item.id]?.message}
                              hint={item.helpText}
                              localized={item.localized}
                              language={getLocaleByCode(item?.languageCode)}
                            />
                          );
                        case "NUMBER":
                          return (
                            <TextField
                              {...field}
                              label={item.name}
                              required={item.required}
                              type="number"
                              // value={item.value}
                              error={errors[item.id]?.message}
                              hint={item.helpText}
                              localized={item.localized}
                              language={getLocaleByCode(item?.languageCode)}
                            />
                          );
                        case "DATETIME":
                          return (
                            <CustomDateField
                              {...field}
                              label={item.name}
                              required={item.required}
                              error={errors[item.id]?.message}
                              hint={item.helpText}
                              localized={item.localized}
                              language={getLocaleByCode(item?.languageCode)}
                              name={item.id}
                              contentEntry
                              details={{
                                ...defaultValues?.[item.id + " - details"],
                              }}
                            />
                          );
                        case "LOCATION":
                          return (
                            <LocationField
                              {...field}
                              label={item.name}
                              required={item.required}
                              hint={item.helpText}
                            />
                          );
                        case "MEDIA":
                          return (
                            <SelectFileModule
                              {...field}
                              label={item.name}
                              required={item.required}
                              allAssets={allAssets}
                              defaultValue={
                                isEditMode && defaultValues?.[item.id]
                              }
                              fieldId={item.id}
                              error={errors[item.id]?.message}
                              hint={item.helpText}
                              localized={item.localized}
                              language={getLocaleByCode(item?.languageCode)}
                              type={item.type} // ONE OR MANY
                              referenceFieldForMedia={referenceFieldForMedia}
                              referenceImage
                            />
                          );
                        case "BOOLEAN":
                          return (
                            <BooleanField
                              {...field}
                              value={
                                typeof currentFormValues?.[item?.id] ===
                                "boolean"
                                  ? currentFormValues?.[item?.id]
                                  : undefined
                              }
                              label={item.name}
                              name={item.name}
                              required={item.required}
                              id={item.id}
                              options={item}
                              error={errors[item.id]?.message}
                              hint={item.helpText}
                              localized={item.localized}
                              language={getLocaleByCode(item?.languageCode)}
                              defaultValue={defaultValues?.[item.id]}
                              isEditMode={isEditMode}
                            />
                          );
                        case "JSON":
                          return (
                            <JsonField
                              {...field}
                              label={item.name}
                              required={item.required}
                              error={errors[item.id]?.message}
                              hint={item.helpText}
                              localized={item.localized}
                              language={getLocaleByCode(item?.languageCode)}
                            />
                          );
                        case "REFERENCE":
                          return (
                            <ReferenceField
                              {...field}
                              label={item.name}
                              required={item.required}
                              contentEntries={contentEntries}
                              defaultValue={
                                isEditMode && defaultValues?.[item.id]
                              }
                              error={errors[item.id]?.message}
                              hint={item.helpText}
                              localized={item.localized}
                              language={getLocaleByCode(item?.languageCode)}
                              type={item.type} // ONE OR MANY
                              referenceFieldForMedia
                            />
                          );
                        default:
                          return null; // Handle other field types as needed
                      }
                    }}
                  />
                </div>
              ))}
          </div>

          {/* <Button
            id="submit-content-button-reference"
            className={cn(styles["submit-button"], "mt-5")}
            type="submit"
            size="md"
            variant="secondary"
            text={"Save"}
            loading={loading}
          /> */}
          <div className={styles.right_sideBar}>
            <Sidebar_Right
              referenceSidebar
              onSubmit={() => onSubmit(currentFormValues)}
            />
          </div>
        </form>
      </FormProvider>
    </>
  );
}
