import { useCallback } from "react";
import styles from "./sharedViews.module.scss";
import MenuDropdown from "@/components/layout/secondaryNav/menuDropdown";
import MenuItem from "@/components/layout/secondaryNav/menuItem";
import { IoIosArrowDown } from "react-icons/io";
import { useDispatch, useSelector } from "react-redux";
import {
  addSortingContentEntry,
  filterContentStatus,
  filterContentTable,
  removeContentEntryFilter,
  addFiltersContentEntry,
  addFilterUdatedByMeContentEntry,
} from "@/store/actions/contentEntry";

import cn from "classnames";
import { useParams } from "next/navigation";

const SharedViews = ({ pageType, isSideBar }) => {
  const { data } = useSelector((state) => state.contentModel);
  const { user } = useSelector((state) => state.user);
  const dispatch = useDispatch();

  const { spaceId = "", spaceEnvironmentId = "" } = useParams() || {};

  const VIEW_DROPDOWN = [
    {
      id: 1,
      title: "CONTENT TYPE",
      icon: <IoIosArrowDown />,
      children: [
        ...(data
          ? data.content.map((item, index) => ({
              id: index + 1,
              title:
                item.name.length > 28
                  ? `${item.name.slice(0, 28)}...`
                  : item.name,
              data: item,
            }))
          : []),
      ],
    },
  ];

  const FILE_TYPES = [
    {
      id: 1,
      title: "FILE TYPE",
      icon: <IoIosArrowDown />,
      children: [
        { id: 1, title: "Attachment", isFilterFileType: true },
        { id: 2, title: "Plain Text", isFilterFileType: true },
        { id: 3, title: "Rich Text", isFilterFileType: true },
        { id: 4, title: "Image", isFilterFileType: true },
        { id: 5, title: "Audio", isFilterFileType: true },
        { id: 6, title: "Video", isFilterFileType: true },
      ],
    },
  ];

  const STATUS = [
    {
      id: 1,
      title: "STATUS",
      icon: <IoIosArrowDown />,
      children: [
        { id: 1, title: "Published" },
        { id: 2, title: "Changed" },
        { id: 3, title: "Draft" },
        // { id: 2, title: "Archieved" },
      ],
    },
  ];

  const getMenus = useCallback((items) => {
    return items.map((item) => {
      if (item.children?.length) {
        return (
          <MenuDropdown
            key={item.id + " - MenuDropdown"}
            title={item.title}
            icon={item.icon}
            children={item.children}
            align={item.align}
            pageType={pageType}
            isSideBar={isSideBar}
            isMenuOpen
            dropdown_status_sidebar
            count={item.children?.length}
            isMedia={pageType === "media"}
          />
        );
      } else {
        return (
          <MenuItem
            key={item.id + "- MenuItem"}
            text={item.title}
            icon={item.icon}
            url={item.url}
            isSideBar={isSideBar}
            children={item.children}
          />
        );
      }
    });
  }, []);
  const handleUpdatedByMe = () => {
    dispatch(
      addFiltersContentEntry(
        "lastUpdatedBy",
        user?.firstName + " " + user?.lastName
      )
    );
    dispatch(removeContentEntryFilter("status"));
    dispatch(filterContentStatus(""));
    dispatch(removeContentEntryFilter("createdBy"));
  };
  const handleCreatedByMe = () => {
    dispatch(
      addFiltersContentEntry(
        "createdBy",
        user?.firstName + " " + user?.lastName
      )
    );
    dispatch(removeContentEntryFilter("status"));
    dispatch(removeContentEntryFilter("lastUpdatedBy"));
    dispatch(filterContentStatus(""));
  };

  const handleClearFilters = () => {
    dispatch(filterContentTable(null, "Any"));
    dispatch(addSortingContentEntry("lastModifiedDate", "DESC"));
    dispatch(removeContentEntryFilter("contentModelId"));
    dispatch(removeContentEntryFilter("status"));
    dispatch(filterContentStatus(""));
    dispatch(removeContentEntryFilter("lastUpdatedBy"));
    dispatch(removeContentEntryFilter("createdBy"));
  };

  return (
    <>
      <div className={styles.SharedViews}>
        <div className={styles.private_views_main}>
          <p
            className={styles.private_views_button}
            onClick={handleCreatedByMe}
          >
            Created by me
          </p>
          <p
            className={styles.private_views_button}
            onClick={handleUpdatedByMe}
          >
            Update by me
          </p>
        </div>
        <p className={styles.clear_Filters} onClick={handleClearFilters}>
          All
        </p>
        {pageType === "media" ? (
          <>
            <div className={styles.dropdown_status}>
              {STATUS[0] && getMenus(STATUS)}
            </div>
            <div className={styles.dropdown}>
              {FILE_TYPES[0] && getMenus(FILE_TYPES)}
            </div>
          </>
        ) : (
          <>
            <div className={styles.dropdown_status}>
              {STATUS[0] && getMenus(STATUS)}
            </div>
            <div className={styles.dropdown}>
              {VIEW_DROPDOWN[0] && getMenus(VIEW_DROPDOWN)}
            </div>
          </>
        )}
      </div>
    </>
  );
};

export default SharedViews;
