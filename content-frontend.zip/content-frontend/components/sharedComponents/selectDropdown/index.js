import React from "react";
import { Controller, useFormContext } from "react-hook-form";
import styles from "./selectDropdown.module.scss";
import cn from "classnames";
import { BiSolidErrorCircle } from "react-icons/bi";
import { FaAngleDown } from "react-icons/fa6";

export default function SelectDropdown({
  options = [],
  label = "",
  labelClassName = "font-weight-medium text-body2 mb-1",
  className = "",
  required = false,
  error,
  disabled,
  ...rest
}) {
  return (
    <div className={styles["container"]}>
      {label && (
        <label className={labelClassName}>
          {label}{" "}
          {required && (
            <span className="text-body2 color-gray-1100 font-weight-regular">
              (required)
            </span>
          )}
        </label>
      )}

      <div className={styles["select-container"]}>
        <select
          id="select-dropdown"
          {...rest}
          className={cn(styles.select, className, {
            [styles.error]: Boolean(error),
          })}
          disabled={disabled}
        >
          {options.map((option) => (
            <option key={option?.value} value={option?.value}>
              {option?.name}
            </option>
          ))}
        </select>
        <FaAngleDown />
      </div>
      {error && (
        <span
          className={cn(
            "d-block color-scarletRed-500 text-body2",
            styles.error
          )}
        >
          <BiSolidErrorCircle size="1.2em" className="color-scarletRed-300" />
          {error}
        </span>
      )}
    </div>
  );
}
