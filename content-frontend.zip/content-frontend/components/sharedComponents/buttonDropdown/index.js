"use client";
import React, { useRef, useState } from "react";
import { BiChevronDown } from "react-icons/bi";
import styles from "./buttonDropdown.module.scss";
import { useDispatch } from "react-redux";
import { setContentEntryStatus } from "@/store/actions/contentEntry";
import {
  triggerFormSubmission,
  triggerFormSubmissionForReference,
} from "@/store/actions/form";
import { useOutsideClick } from "@/hooks/useOutsideClick";
import { setMediaEntryStatus } from "@/store/actions/media";
import { useFormContext } from "react-hook-form";

export default function ButtonDropdown({
  text = "",
  options = [],
  onChange = () => {},
  optionsLabel = "",
  optionsLabelClassName = "",
  media = false,
  disabled,
  referenceSidebar = false,
  referenceImage = false,
  referenceFieldForMedia = false,
  fetchedMediaStatus,
  status,
  onSubmit = () => {},
}) {
  const { handleSubmit } = useFormContext() || {};

  const dispatch = useDispatch();
  const [open, setOpen] = useState(false);
  const handleStatus = (value) => {
    onChange(value);
    setOpen(false);
    // if (referenceSidebar) {
    //   // dispatch(triggerFormSubmissionForReference());
    // }
    if (!media) {
      dispatch(setContentEntryStatus(value));
    } else {
      dispatch(setMediaEntryStatus(value));
    }
    dispatch(triggerFormSubmission());
  };
  const ref = useRef();
  const handleClose = () => setOpen(false);

  useOutsideClick(ref, handleClose);

  return (
    <div className={styles["button-dropdown-container"]} ref={ref}>
      {!disabled ? (
        <button disabled className={styles.disabled}>
          {text}
        </button>
      ) : (
        <button
          className={styles["button-container"]}
          onClick={(e) => {
            setOpen(!open);
            e.preventDefault();
          }}
        >
          {text} <BiChevronDown />
        </button>
      )}
      {open && (
        <div className={styles["options-container"]}>
          <div className={styles["box-container"]}>
            <label className={styles["option-label"]}>{optionsLabel}</label>
            <p
              onClick={() => handleStatus("PUBLISHED")}
              className={styles.option}
            >
              Publish
            </p>
            {(fetchedMediaStatus === "PUBLISHED" ||
              fetchedMediaStatus === "CHANGED" ||
              status === "PUBLISHED" ||
              status === "CHANGED") && (
              <p
                onClick={() => handleStatus("CHANGED")}
                className={styles.option}
              >
                Changed
              </p>
            )}
            <p onClick={() => handleStatus("DRAFT")} className={styles.option}>
              Draft
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
