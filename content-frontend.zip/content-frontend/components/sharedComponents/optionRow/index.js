import React from "react";
import styles from "./optionRow.module.scss";
import { Button } from "@/components/theme/buttons";

const OptionRow = ({
  handleDelete = () => {},
  handleUnPublish = () => {},
  handlePublish = () => {},
  handleRevert = () => {},
  selectedEntries = [],
}) => {
  const showBtns = {
    delete:
      selectedEntries.filter((s) => s.status === "PUBLISHED").length === 0,
    unpublish:
      selectedEntries.filter(
        (s) =>
          s.status === "DRAFT" ||
          // s.status === "UNPUBLISHED" ||
          s.status === "CHANGED"
      ).length === 0,
    revert: selectedEntries.filter((s) => s.status !== "CHANGED").length === 0,
  };

  return (
    <div className={styles.option_row}>
      <p className={styles.text}>
        <b>Selected Entries: </b>
        {selectedEntries?.length}
      </p>
      {showBtns.delete && (
        <>
          <Button
            className={`${styles.rowBtn} ${styles.deleteBtn}`}
            text="Delete"
            onClick={handleDelete}
          ></Button>
          <Button
            className={`${styles.rowBtn} ${styles.publishBtn}`}
            text="Publish"
            onClick={() => handlePublish("PUBLISHED")}
          ></Button>
        </>
      )}

      {showBtns.unpublish && (
        <Button
          className={`${styles.rowBtn}`}
          text="Unpublish"
          onClick={() => handleUnPublish("CHANGED")}
        ></Button>
      )}
      {showBtns.revert && (
        <>
          <Button
            className={`${styles.rowBtn} ${styles.revertBtn}`}
            text="Revert"
            onClick={() => handleRevert("REVERT")}
          ></Button>
        </>
      )}
    </div>
  );
};

export default OptionRow;
