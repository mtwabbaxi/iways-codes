import {
  CREATE_LOCALE,
  CREATE_LOCALE_FAILURE,
  CREATE_LOCALE_SUCCESS,
  FETCH_ALL_LOCALES,
  FETCH_ALL_LOCALES_SUCCESS,
  FETCH_ALL_LOCALES_FAILURE,
  SWAGGER,
  SELETED_LOCALE_VALUE,
  SET_LOCALE_CURRENT_VALUE,
  SET_LOCALE_SUBMIT_BUTTON,
  UPDATE_LOCALE_ASSET,
  UPDATE_LOCALE_ASSET_SUCCESS,
  UPDATE_LOCALE_ASSET_FAILURE,
  DELETE_LOCALES,
  DELETE_LOCALES_SUCCESS,
  DELETE_LOCALES_FAILURE,
  SET_CONTENT_ENTRY_SELECTED_LANGUAGES,
  FETCH_ALL_ENABLE_LANGUAGES,
  FETCH_ALL_ENABLE_LANGUAGES_SUCCESS,
  FETCH_ALL_ENABLE_LANGUAGES_FAILURE,
  REMOVE_OR_ADD_ENABLE_LANGUAGES,
  REMOVE_OR_ADD_ENABLE_LANGUAGES_SUCCESS,
  REMOVE_OR_ADD_ENABLE_LANGUAGES_FAILURE,
} from "@/store/actions/actionTypes";

export const fetchAllLocales = (spaceId, spaceEnvironmentId) => {
  return {
    type: SWAGGER,
    types: [
      FETCH_ALL_LOCALES,
      FETCH_ALL_LOCALES_SUCCESS,
      FETCH_ALL_LOCALES_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      const requestParams = {
        pageNo: 0,
        pageSize: 1000,
        spaceEnvironmentId: spaceEnvironmentId,
        spaceId: spaceId,
      };
      return api["locale-controller"].getAllLocales({
        ...requestParams,
      });
    },
  };
};

export const addLocale = (data) => {
  return {
    type: SWAGGER,
    types: [CREATE_LOCALE, CREATE_LOCALE_SUCCESS, CREATE_LOCALE_FAILURE],
    skipAuth: false,
    swagger: (api) => {
      return api["locale-controller"].createLocale(
        {},
        {
          requestBody: {
            ...data,
          },
        }
      );
    },
  };
};

export const updateLocale = (localeId, data, spaceId, spaceEnvironmentId) => {
  return {
    type: SWAGGER,
    types: [
      UPDATE_LOCALE_ASSET,
      UPDATE_LOCALE_ASSET_SUCCESS,
      UPDATE_LOCALE_ASSET_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["locale-controller"].updateLocale(
        {
          localeId: localeId,
        },
        {
          requestBody: {
            ...data,
            spaceEnvironmentId: spaceEnvironmentId,
            spaceId: spaceId,
          },
        }
      );
    },
  };
};

export const setCurrLocale = (value, spaceId, spaceEnvironmentId) => {
  return {
    type: SET_LOCALE_CURRENT_VALUE,
    data: {
      value,
      spaceEnvironmentId: spaceEnvironmentId,
      spaceId: spaceId,
    },
  };
};

export const isSubmitButton = (val) => ({
  type: SET_LOCALE_SUBMIT_BUTTON,
  data: val,
});

export const selectedLocaleData = (val) => ({
  type: SELETED_LOCALE_VALUE,
  data: val,
});

export const setContentEntrySelectedLanguage = (selectedLanguages) => {
  return {
    type: SET_CONTENT_ENTRY_SELECTED_LANGUAGES,
    payload: selectedLanguages,
  };
};

export const deleteLocales = (data) => {
  return {
    type: SWAGGER,
    types: [DELETE_LOCALES, DELETE_LOCALES_SUCCESS, DELETE_LOCALES_FAILURE],
    skipAuth: false,
    swagger: (api) => {
      return api["locale-controller"].deleteLocale(
        {
          ...data,
        },
        {}
      );
    },
  };
};

export const fetchAllEnableLanguages = () => {
  return {
    type: SWAGGER,
    types: [
      FETCH_ALL_ENABLE_LANGUAGES,
      FETCH_ALL_ENABLE_LANGUAGES_SUCCESS,
      FETCH_ALL_ENABLE_LANGUAGES_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      const requestParams = {};
      return api["user-enable-language-controller"].getUserEnableLanguages({
        ...requestParams,
      });
    },
  };
};

export const addRemoveSelectedLanguage = (languages) => {
  return {
    type: SWAGGER,
    types: [
      REMOVE_OR_ADD_ENABLE_LANGUAGES,
      REMOVE_OR_ADD_ENABLE_LANGUAGES_SUCCESS,
      REMOVE_OR_ADD_ENABLE_LANGUAGES_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      const requestParams = {};

      return api[
        "user-enable-language-controller"
      ].addOrRemoveUserEnableLanguages(
        { ...requestParams },
        {
          requestBody: languages,
        }
      );
    },
  };
};
