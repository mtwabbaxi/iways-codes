import {SWAGGER} from "./actionTypes"
import {
	LOGIN,
	LOGIN_SUCCESS,
	LOGIN_FAILURE,
	SIGNUP,
	SIGNUP_SUCCESS,
	SIGNUP_FAILURE,
} from "./actionTypes"

// Login
export const login = (data) => {
	return {
		type: SWAGGER,
		types: ["LOGIN", "LOGIN_SUCCESS", "LOGIN_FAILURE"],
		skipAuth: true,
		service: "user_service",
		swagger: (api) => {
			return api["user-account-controller"].login({}, {requestBody: data})
		},
	}
}

export const signup = (data) => {
	return {
		type: SWAGGER,
		types: ["SIGNUP", "SIGNUP_SUCCESS", "SIGNUP_FAILURE"],
		skipAuth: true,
		service: "user_service",
		swagger: (api) => {
			return api["user-account-controller"].signUp({}, {requestBody: data})
		},
	}
}
