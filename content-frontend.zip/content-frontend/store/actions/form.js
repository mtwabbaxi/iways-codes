export const triggerFormSubmission = () => {
  return { type: "TRIGGER_FORM_SUBMISSION" };
};
export const triggerFormSubmissionForReference = () => {
  return { type: "TRIGGER_FORM_SUBMISSION_FOR_REFERENCE" };
};
