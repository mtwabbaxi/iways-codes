import { SWAGGER } from "./actionTypes";

// Import action types for Core Account Types
import {
    UPDATE_ACCOUNT_TYPE,
    UPDATE_ACCOUNT_TYPE_SUCCESS,
    UPDATE_ACCOUNT_TYPE_FAILURE,
    ADD_ACCOUNT_TYPE,
    ADD_ACCOUNT_TYPE_SUCCESS,
    ADD_ACCOUNT_TYPE_FAILURE,
    GET_ACCOUNT_TYPES,
    GET_ACCOUNT_TYPES_SUCCESS,
    GET_ACCOUNT_TYPES_FAILURE,
    DELETE_ACCOUNT_TYPE,
    DELETE_ACCOUNT_TYPE_SUCCESS,
    DELETE_ACCOUNT_TYPE_FAILURE,
} from "./actionTypes";

// Update Core Account Type by ID
export const updateAccountType = (accountTypeId, data) => {
    return {
        type: SWAGGER,
        types: [
            "UPDATE_ACCOUNT_TYPE",
            "UPDATE_ACCOUNT_TYPE_SUCCESS",
            "UPDATE_ACCOUNT_TYPE_FAILURE",
        ],
        swagger: (api) => {
            return api["core-account-types"].updateAccountType({ accountTypeId }, { requestBody: data });
        },
    };
};

// Add Core Account Type
export const addAccountType = (data) => {
    return {
        type: SWAGGER,
        types: [
            "ADD_ACCOUNT_TYPE",
            "ADD_ACCOUNT_TYPE_SUCCESS",
            "ADD_ACCOUNT_TYPE_FAILURE",
        ],
        swagger: (api) => {
            return api["core-account-types"].addAccountType({}, { requestBody: data });
        },
    };
};

// Get Core Account Types
export const getAccountTypes = () => {
    return {
        type: SWAGGER,
        types: [
            "GET_ACCOUNT_TYPES",
            "GET_ACCOUNT_TYPES_SUCCESS",
            "GET_ACCOUNT_TYPES_FAILURE",
        ],
        swagger: (api) => {
            return api["core-account-types"].getAccountTypes();
        },
    };
};

// Delete Core Account Type by ID
export const deleteAccountType = (accountTypeId) => {
    return {
        type: SWAGGER,
        types: [
            "DELETE_ACCOUNT_TYPE",
            "DELETE_ACCOUNT_TYPE_SUCCESS",
            "DELETE_ACCOUNT_TYPE_FAILURE",
        ],
        swagger: (api) => {
            return api["core-account-types"].deleteAccountType({ accountTypeId });
        },
    };
};
