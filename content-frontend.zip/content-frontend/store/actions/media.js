import {
  UPLOAD_MEDIA,
  UPLOAD_MEDIA_SUCCESS,
  UPLOAD_MEDIA_FAILURE,
  ADD_MEDIA_ASSET,
  ADD_MEDIA_ASSET_SUCCESS,
  ADD_MEDIA_ASSET_FAILURE,
  UPDATE_MEDIA_ASSET,
  UPDATE_MEDIA_ASSET_SUCCESS,
  UPDATE_MEDIA_ASSET_FAILURE,
  FETCH_ALL_MEDIA_ASSET,
  FETCH_ALL_MEDIA_ASSET_SUCCESS,
  FETCH_ALL_MEDIA_ASSET_FAILURE,
  DELETE_MEDIA_ASSET,
  DELETE_MEDIA_ASSET_SUCCESS,
  DELETE_MEDIA_ASSET_FAILURE,
  FETCH_MEDIA_ASSET_BY_ID,
  FETCH_MEDIA_ASSET_BY_ID_SUCCESS,
  FETCH_MEDIA_ASSET_BY_ID_FAILURE,
  SET_CURRENT_TITLE,
  SET_CURRENT_DESCRIPTION,
  SET_CURRENT_UPLOADFILE,
  DELETE_MEDIA,
  DELETE_MEDIA_SUCCESS,
  DELETE_MEDIA_FAILURE,
  SET_MEDIA_TYPE_BUTTON,
  SET_CREATE_MEDIA_OPEN,
  SET_EXISTING_MEDIA_OPEN,
  SWAGGER,
  DELETE_MULTIPLE_MEDIA_ASSET,
  DELETE_MULTIPLE_MEDIA_ASSET_SUCCESS,
  DELETE_MULTIPLE_MEDIA_ASSET_FAILURE,
  REVERT_MULTIPLE_MEDIA_ASSET,
  REVERT_MULTIPLE_MEDIA_ASSET_SUCCESS,
  REVERT_MULTIPLE_MEDIA_ASSET_FAILURE,
  UPDATE_MULTIPLE_MEDIA_ASSET_FAILURE,
  UPDATE_MULTIPLE_MEDIA_ASSET_SUCCESS,
  UPDATE_MULTIPLE_MEDIA_ASSET,
  ADD_FILTERS_MEDIA,
  REMOVE_FILTERS_MEDIA,
  MEDIA_APPLY_SORTING,
  MEDIA_REMOVE_SORTING,
} from "@/store/actions/actionTypes";

export const UpdateMultipleMediaAssetStatus = ({
  assetIds,
  status,
  spaceId,
  spaceEnvironmentId,
}) => {
  return {
    type: SWAGGER,
    types: [
      UPDATE_MULTIPLE_MEDIA_ASSET,
      UPDATE_MULTIPLE_MEDIA_ASSET_SUCCESS,
      UPDATE_MULTIPLE_MEDIA_ASSET_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["media-controller"].updateBulkMediaAssetStatus(
        {
          assetIds,
          spaceEnvironmentId: spaceEnvironmentId,
          spaceId: spaceId,
          status: status,
        },
        {}
      );
    },
  };
};

export const deleteMultipleMediaAsset = ({
  assetIds,
  spaceId,
  spaceEnvironmentId,
}) => {
  return {
    type: SWAGGER,
    types: [
      DELETE_MULTIPLE_MEDIA_ASSET,
      DELETE_MULTIPLE_MEDIA_ASSET_SUCCESS,
      DELETE_MULTIPLE_MEDIA_ASSET_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["media-controller"].deleteBulkMediaAsset(
        {
          assetIds,
          spaceEnvironmentId: spaceEnvironmentId,
          spaceId: spaceId,
        },
        {}
      );
    },
  };
};

export const revertMultipleMediaAsset = ({
  assetIds,
  spaceId,
  spaceEnvironmentId,
}) => {
  return {
    type: SWAGGER,
    types: [
      REVERT_MULTIPLE_MEDIA_ASSET,
      REVERT_MULTIPLE_MEDIA_ASSET_SUCCESS,
      REVERT_MULTIPLE_MEDIA_ASSET_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["media-controller"].revertContentEntryData(
        {
          assetId: assetIds[0],
          spaceEnvironmentId: spaceEnvironmentId,
          spaceId: spaceId,
        },
        {}
      );
    },
  };
};

export const uploadMedia = (
  file,
  mediaType,
  mediaDimensions,
  spaceId,
  spaceEnvironmentId
) => {
  return {
    type: SWAGGER,
    types: [UPLOAD_MEDIA, UPLOAD_MEDIA_SUCCESS, UPLOAD_MEDIA_FAILURE],
    skipAuth: false,
    swagger: (api) => {
      return api["media-controller"].uploadFiles(
        {},
        {
          requestBody: {
            files: file,
          },
        }
      );
    },
    mediaType: mediaType,
    mediaDimensions: mediaDimensions,
  };
};

export const addMediaAsset = (data, spaceId, spaceEnvironmentId) => {
  return {
    type: SWAGGER,
    types: [ADD_MEDIA_ASSET, ADD_MEDIA_ASSET_SUCCESS, ADD_MEDIA_ASSET_FAILURE],
    skipAuth: false,
    swagger: (api) => {
      return api["media-controller"].addAsset(
        {},
        {
          requestBody: {
            ...data,
            spaceEnvironmentId: spaceEnvironmentId,
            spaceId: spaceId,
          },
        }
      );
    },
  };
};

export const updateMediaAsset = (
  assetId,
  data,
  spaceId,
  spaceEnvironmentId
) => {
  return {
    type: SWAGGER,
    types: [
      UPDATE_MEDIA_ASSET,
      UPDATE_MEDIA_ASSET_SUCCESS,
      UPDATE_MEDIA_ASSET_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["media-controller"].updateMediaAsset(
        {
          assetId: assetId,
        },
        {
          requestBody: {
            ...data,
            spaceEnvironmentId: spaceEnvironmentId,
            spaceId: spaceId,
          },
        }
      );
    },
  };
};

export const fetchAllMediaAsset = (spaceId, spaceEnvironmentId, data) => {
  let filterCriteria = "";
  let sortCriteria = "";

  const { filters = {}, sortBy = {} } = data || {};
  if (Object.keys(filters).length) {
    filterCriteria = Object.keys(filters)
      .map((key) => {
        if (key === "mediaType" && filters[key] === "Image") {
          return "mediaType:like:image";
        } else {
          return `${key}:eq:${filters[key]}`;
        }
      })
      .join(",");
  }

  if (Object.keys(sortBy).length) {
    sortCriteria = Object.keys(sortBy)
      .map((key) => {
        return `${key}:${sortBy[key]}`;
      })
      .join(",");
  }

  return {
    type: SWAGGER,
    types: [
      FETCH_ALL_MEDIA_ASSET,
      FETCH_ALL_MEDIA_ASSET_SUCCESS,
      FETCH_ALL_MEDIA_ASSET_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["media-controller"].getAllAssets(
        {
          spaceId,
          spaceEnvironmentId,
          pageNo: 0,
          pageSize: 100,
          ...(filterCriteria ? { filterCriteria } : {}),
          ...(sortCriteria ? { sortCriteria } : {}),
        },
        {}
      );
    },
  };
};
export const fetchMediaAssetById = (assetId, spaceId, spaceEnvironmentId) => {
  return {
    type: SWAGGER,
    types: [
      FETCH_MEDIA_ASSET_BY_ID,
      FETCH_MEDIA_ASSET_BY_ID_SUCCESS,
      FETCH_MEDIA_ASSET_BY_ID_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["media-controller"].getAssetById(
        {
          assetId: assetId,
          spaceEnvironmentId: spaceEnvironmentId,
          spaceId: spaceId,
        },
        {}
      );
    },
  };
};

export const deleteAsset = (data, spaceId, spaceEnvironmentId) => {
  return {
    type: SWAGGER,
    types: [
      DELETE_MEDIA_ASSET,
      DELETE_MEDIA_ASSET_SUCCESS,
      DELETE_MEDIA_ASSET_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["media-controller"].deleteMediaAsset({
        assetId: data,
        spaceEnvironmentId: spaceEnvironmentId,
        spaceId: spaceId,
      });
    },
  };
};

export const deleteMedia = (fileName) => {
  return {
    type: SWAGGER,
    types: [DELETE_MEDIA, DELETE_MEDIA_SUCCESS, DELETE_MEDIA_FAILURE],
    skipAuth: false,
    swagger: (api) => {
      return api["media-controller"].deleteFile({
        fileName: fileName,
      });
    },
  };
};

export const setMediaEntryStatus = (status) => {
  return {
    type: "SET_MEDIA_ENTRY_STATUS",
    status,
  };
};

export const setMediaSubmitButton = (val) => ({
  type: SET_MEDIA_TYPE_BUTTON,
  data: val,
});

export const setCurrTitle = (title, spaceId, spaceEnvironmentId) => {
  return {
    type: SET_CURRENT_TITLE,
    data: {
      title,
      spaceEnvironmentId: spaceEnvironmentId,
      spaceId: spaceId,
    },
  };
};
export const setCurrDescription = (
  description,
  spaceId,
  spaceEnvironmentId
) => {
  return {
    type: SET_CURRENT_DESCRIPTION,
    data: {
      description,
      spaceEnvironmentId: spaceEnvironmentId,
      spaceId: spaceId,
    },
  };
};

export const setCurrUploadFile = (file) => {
  return {
    type: SET_CURRENT_UPLOADFILE,
    data: {
      file,
    },
  };
};

export const setCreateMediaOpen = (val) => ({
  type: SET_CREATE_MEDIA_OPEN,
  data: val,
});

export const setExistingMediaOpen = (val) => ({
  type: SET_EXISTING_MEDIA_OPEN,
  data: val,
});

export const addMediaFilters = (key, value) => ({
  type: ADD_FILTERS_MEDIA,
  key,
  value,
});

export const removeMediaFilter = (key) => ({
  type: REMOVE_FILTERS_MEDIA,
  key,
});

export const addMediaSorting = (key, value) => ({
  type: MEDIA_APPLY_SORTING,
  key,
  value,
});

export const removeMediaSorting = (key) => ({
  type: MEDIA_REMOVE_SORTING,
  key,
});
