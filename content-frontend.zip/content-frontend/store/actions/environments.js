import {
	CREATE_ENVIRONMENT,
	CREATE_ENVIRONMENT_FAILURE,
	CREATE_ENVIRONMENT_SUCCESS,
	FETCH_ALL_ENVIRONMENTS,
	FETCH_ALL_ENVIRONMENTS_SUCCESS,
	FETCH_ALL_ENVIRONMENTS_FAILURE,
	SWAGGER,
	DELETE_ENVIRONMENT,
	DELETE_ENVIRONMENT_SUCCESS,
	DELETE_ENVIRONMENT_FAILURE,
	UPDATE_CONTENT,
	UPDATE_CONTENT_SUCCESS,
	UPDATE_CONTENT_FAILURE,
	GET_CONTENT_ENTRY_BY_ID,
	GET_CONTENT_ENTRY_BY_ID_SUCCESS,
	GET_CONTENT_ENTRY_BY_ID_FAILURE,
	SET_CONTENT_CURRENT_TITLE,
} from "@/store/actions/actionTypes"

export const fetchAllEnvironments = (spaceId, spaceEnvironmentId) => {
	return {
		type: SWAGGER,
		types: [
			FETCH_ALL_ENVIRONMENTS,
			FETCH_ALL_ENVIRONMENTS_SUCCESS,
			FETCH_ALL_ENVIRONMENTS_FAILURE,
		],
		skipAuth: false,
		swagger: (api) => {
			const requestParams = {
				pageNo: 0,
				pageSize: 1000,
				spaceEnvironmentId: spaceEnvironmentId,
				spaceId: spaceId,
			}
			return api["space-environment-controller"].getBySpaceId({
				...requestParams,
			})
		},
	}
}

export const addEnvironment = (data) => {
	return {
		type: SWAGGER,
		types: [
			CREATE_ENVIRONMENT,
			CREATE_ENVIRONMENT_SUCCESS,
			CREATE_ENVIRONMENT_FAILURE,
		],
		skipAuth: false,
		swagger: (api) => {
			return api["space-environment-controller"].createSpaceEnvironment(
				{},
				{
					requestBody: {
						...data,
					},
				}
			)
		},
	}
}

export const deleteEnvironment = (data) => {
	return {
		type: SWAGGER,
		types: [
			DELETE_ENVIRONMENT,
			DELETE_ENVIRONMENT_SUCCESS,
			DELETE_ENVIRONMENT_FAILURE,
		],
		skipAuth: false,
		swagger: (api) => {
			return api["space-environment-controller"].deleteSpaceEnvironment(
				{
					...data,
				},
				{}
			)
		},
	}
}

export const filterContentTable = (id, title) => {
	return {
		type: "FILTER_CONTENT_VALUE",
		filterValue: id,
		title: title,
	}
}

export const setContentEntryStatus = (status) => {
	return {
		type: "SET_ENTRY_STATUS",
		status,
	}
}

export const setCurrTitle = (title, spaceId, spaceEnvironmentId) => {
	return {
		type: SET_CONTENT_CURRENT_TITLE,
		data: {
			title,
			spaceEnvironmentId: spaceEnvironmentId,
			spaceId: spaceId,
		},
	}
}
