import {
  SWAGGER,
  CREATE_MODEL,
  CREATE_MODEL_SUCCESS,
  CREATE_MODEL_FAILURE,
  FETCH_ALL_CONTENT_MODELS,
  FETCH_ALL_CONTENT_MODELS_SUCCESS,
  FETCH_ALL_CONTENT_MODELS_FAILURE,
  GET_CONTENT_MODEL_BY_ID,
  GET_CONTENT_MODEL_BY_ID_SUCCESS,
  GET_CONTENT_MODEL_BY_ID_FAILURE,
  UPDATE_CONTENT_MODEL,
  UPDATE_CONTENT_MODEL_SUCCESS,
  UPDATE_CONTENT_MODEL_FAILURE,
  DELETE_CONTENT_MODEL,
  DELETE_CONTENT_MODEL_SUCCESS,
  DELETE_CONTENT_MODEL_FAILURE,
  ADD_CONTENT_MODEL_FIELD,
  ADD_CONTENT_MODEL_FIELD_SUCCESS,
  ADD_CONTENT_MODEL_FIELD_FAILURE,
  UPDATE_CONTENT_MODEL_FIELD,
  UPDATE_CONTENT_MODEL_FIELD_SUCCESS,
  UPDATE_CONTENT_MODEL_FIELD_FAILURE,
  DELETE_CONTENT_MODEL_FIELD,
  DELETE_CONTENT_MODEL_FIELD_SUCCESS,
  DELETE_CONTENT_MODEL_FIELD_FAILURE,
  RESET_SELECTED_CONTENT_MODEL,
  MODIFY_SELECTED_CONTENT_MODEL,
  SEARCH_NAME_CONTENT,
  SEARCH_NAME_MEDIA,
  SAVE_DATE_WHILE_CREATING_MODEL,
  CONTENT_MODEL_UPDDATE_SORTING,
  CONTENT_MODEL_SORTING,
  GET_CONTENT_MODEL_BY_ID_SUCCESS_REFERENCE,
  GET_CONTENT_MODEL_BY_ID_FAILURE_REFERENCE,
  GET_CONTENT_MODEL_BY_ID_REFEREENCE,
} from "./actionTypes";
export const createContentModel = (
  data,
  spaceId,
  spaceEnvironmentId,
  fieldData
) => {
  console.log("🚀 ~ data:", data);
  let fields = [];
  fields.push(fieldData?.value);
  return {
    type: SWAGGER,
    types: [CREATE_MODEL, CREATE_MODEL_SUCCESS, CREATE_MODEL_FAILURE],
    skipAuth: false,
    swagger: (api) => {
      return api["content-model-controller"].createContentModel(
        {},
        {
          requestBody: {
            ...data,
            spaceEnvironmentId,
            spaceId: spaceId,
            fields,
          },
        }
      );
    },
  };
};

export const fetchAllContentModels = (spaceId, spaceEnvironmentId, data) => {
  const { sortBy = {} } = data || {};
  const sorting = Object.keys(sortBy).length
    ? {
        sortFieldName: [Object.keys(sortBy)[0]],
        sortDirection: sortBy[Object.keys(sortBy)[0]],
      }
    : {};

  if (data) {
    if ("sortBy" in data) {
      delete data.sortBy;
    }
  }

  return {
    type: SWAGGER,
    types: [
      FETCH_ALL_CONTENT_MODELS,
      FETCH_ALL_CONTENT_MODELS_SUCCESS,
      FETCH_ALL_CONTENT_MODELS_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["content-model-controller"].getAll({
        pageNo: 0,
        pageSize: 1000,
        spaceEnvironmentId: spaceEnvironmentId,
        spaceId: spaceId,
        ...data,
        ...(sorting ? { ...sorting } : {}),
      });
    },
  };
};

export const getContentModelById = (
  contentModelId,
  spaceId,
  spaceEnvironmentId
) => {
  return {
    type: SWAGGER,
    types: [
      GET_CONTENT_MODEL_BY_ID,
      GET_CONTENT_MODEL_BY_ID_SUCCESS,
      GET_CONTENT_MODEL_BY_ID_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["content-model-controller"].getById({
        contentModelId: contentModelId,
        spaceEnvironmentId: spaceEnvironmentId,
        spaceId: spaceId,
      });
    },
  };
};
export const getContentModelByIdForReference = (
  contentModelId,
  spaceId,
  spaceEnvironmentId
) => {
  return {
    type: SWAGGER,
    types: [
      GET_CONTENT_MODEL_BY_ID_REFEREENCE,
      GET_CONTENT_MODEL_BY_ID_SUCCESS_REFERENCE,
      GET_CONTENT_MODEL_BY_ID_FAILURE_REFERENCE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["content-model-controller"].getById({
        contentModelId: contentModelId,
        spaceEnvironmentId: spaceEnvironmentId,
        spaceId: spaceId,
      });
    },
  };
};

export const updateContentModel = (data, spaceId, spaceEnvironmentId) => {
  return {
    type: SWAGGER,
    types: [
      UPDATE_CONTENT_MODEL,
      UPDATE_CONTENT_MODEL_SUCCESS,
      UPDATE_CONTENT_MODEL_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["content-model-controller"].updateContentModel(
        {},
        {
          requestBody: {
            ...data,
            spaceEnvironmentId: spaceEnvironmentId,
            spaceId: spaceId,
            fields: [],
          },
        }
      );
    },
  };
};

export const deleteContentModel = (
  contentModelId,
  spaceId,
  spaceEnvironmentId
) => {
  return {
    type: SWAGGER,
    types: [
      DELETE_CONTENT_MODEL,
      DELETE_CONTENT_MODEL_SUCCESS,
      DELETE_CONTENT_MODEL_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["content-model-controller"].deleteContentModel(
        {
          contentModelId: contentModelId,
          spaceEnvironmentId: spaceEnvironmentId,
          spaceId: spaceId,
        },
        {}
      );
    },
  };
};

export const addField = (data, spaceId, spaceEnvironmentId) => {
  return {
    type: SWAGGER,
    types: [
      ADD_CONTENT_MODEL_FIELD,
      ADD_CONTENT_MODEL_FIELD_SUCCESS,
      ADD_CONTENT_MODEL_FIELD_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["content-model-controller"].addField(
        {},
        {
          requestBody: {
            ...data,
            spaceEnvironmentId: spaceEnvironmentId,
            spaceId: spaceId,
          },
        }
      );
    },
  };
};

export const updateField = (
  data,
  existingFieldId,
  spaceId,
  spaceEnvironmentId
) => {
  return {
    type: SWAGGER,
    types: [
      UPDATE_CONTENT_MODEL_FIELD,
      UPDATE_CONTENT_MODEL_FIELD_SUCCESS,
      UPDATE_CONTENT_MODEL_FIELD_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["content-model-controller"].updateField(
        { existingFieldId: existingFieldId || "" },
        {
          requestBody: {
            ...data,
            spaceEnvironmentId: spaceEnvironmentId,
            spaceId: spaceId,
          },
        }
      );
    },
  };
};

export const deleteField = (data, spaceId, spaceEnvironmentId) => {
  return {
    type: SWAGGER,
    types: [
      DELETE_CONTENT_MODEL_FIELD,
      DELETE_CONTENT_MODEL_FIELD_SUCCESS,
      DELETE_CONTENT_MODEL_FIELD_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["content-model-controller"].deleteField({
        ...data,
        spaceEnvironmentId: spaceEnvironmentId,
        spaceId: spaceId,
      });
    },
  };
};

export const resetSelectedContentModel = () => {
  return {
    type: RESET_SELECTED_CONTENT_MODEL,
  };
};

export const modifySelectedContentModel = (
  data,
  spaceId,
  spaceEnvironmentId
) => {
  return {
    type: MODIFY_SELECTED_CONTENT_MODEL,
    data: {
      ...data,
      spaceEnvironmentId: spaceEnvironmentId,
      spaceId: spaceId,
    },
  };
};

export const searchByNameOnContent = (data, spaceId, spaceEnvironmentId) => {
  return {
    type: SEARCH_NAME_CONTENT,
    data: {
      data,
      spaceEnvironmentId: spaceEnvironmentId,
      spaceId: spaceId,
    },
  };
};

export const searchByNameOnMedia = (data, spaceId, spaceEnvironmentId) => {
  return {
    type: SEARCH_NAME_MEDIA,
    data: {
      data,
      spaceEnvironmentId: spaceEnvironmentId,
      spaceId: spaceId,
    },
  };
};

export const saveCreatingModelData = (data) => ({
  type: SAVE_DATE_WHILE_CREATING_MODEL,
  payload: data,
});

export const addSortingContentModel = (key, value) => ({
  type: CONTENT_MODEL_SORTING,
  key,
  value,
});

export const updateSortingContentModel = (key, value) => ({
  type: CONTENT_MODEL_UPDDATE_SORTING,
  key,
  value,
});
