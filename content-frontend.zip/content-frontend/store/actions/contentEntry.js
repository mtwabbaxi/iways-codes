import {
  CREATE_CONTENT,
  CREATE_CONTENT_FAILURE,
  CREATE_CONTENT_SUCCESS,
  FETCH_ALL_CONTENT_ENTRIES,
  FETCH_ALL_CONTENT_ENTRIES_SUCCESS,
  FETCH_ALL_CONTENT_ENTRIES_FAILURE,
  SWAGGER,
  DELETE_CONTENT_ENTRY,
  DELETE_CONTENT_ENTRY_SUCCESS,
  DELETE_CONTENT_ENTRY_FAILURE,
  UPDATE_CONTENT,
  UPDATE_CONTENT_SUCCESS,
  UPDATE_CONTENT_FAILURE,
  GET_CONTENT_ENTRY_BY_ID,
  GET_CONTENT_ENTRY_BY_ID_SUCCESS,
  GET_CONTENT_ENTRY_BY_ID_FAILURE,
  SET_CONTENT_CURRENT_TITLE,
  SET_CONTENT_TYPE_BUTTON,
  DELETE_MULTIPLE_CONTENT_ENTRY_FAILURE,
  DELETE_MULTIPLE_CONTENT_ENTRY_SUCCESS,
  DELETE_MULTIPLE_CONTENT_ENTRY,
  REVERT_MULTIPLE_CONTENT_ENTRY_FAILURE,
  REVERT_MULTIPLE_CONTENT_ENTRY_SUCCESS,
  REVERT_MULTIPLE_CONTENT_ENTRY,
  UPDATE_MULTIPLE_CONTENT_ENTRY,
  UPDATE_MULTIPLE_CONTENT_ENTRY_SUCCESS,
  UPDATE_MULTIPLE_CONTENT_ENTRY_FAILURE,
  CONTENT_ENTRY_ADD_SORTING,
  ADD_FILTERS_CONTENT_ENTRY,
  REMOVE_FILTER_CONTENT_ENTRY,
  SET_CONTENT_TYPE_BUTTON_REFERENCE,
  ADD_FILTER_UPDATED_BY_ME_CONTENT_ENTRY,
} from "@/store/actions/actionTypes";

export const UpdateMultipleContentEntryStatus = ({
  contentEntryIds = [],
  status,
  spaceId,
  spaceEnvironmentId,
}) => {
  return {
    type: SWAGGER,
    types: [
      UPDATE_MULTIPLE_CONTENT_ENTRY,
      UPDATE_MULTIPLE_CONTENT_ENTRY_SUCCESS,
      UPDATE_MULTIPLE_CONTENT_ENTRY_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["content-entry-controller"].updateBulkContentEntryStatus(
        {
          contentEntryIds,
          spaceEnvironmentId: spaceEnvironmentId,
          spaceId: spaceId,
          status: status,
        },
        {}
      );
    },
  };
};

export const deleteMultipleContentEntry = ({
  contentEntryIds = [],
  spaceId,
  spaceEnvironmentId,
}) => {
  return {
    type: SWAGGER,
    types: [
      DELETE_MULTIPLE_CONTENT_ENTRY,
      DELETE_MULTIPLE_CONTENT_ENTRY_SUCCESS,
      DELETE_MULTIPLE_CONTENT_ENTRY_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["content-entry-controller"].deleteBulkContentEntry(
        {
          contentEntryIds,
          spaceEnvironmentId: spaceEnvironmentId,
          spaceId: spaceId,
        },
        {}
      );
    },
  };
};

export const revertMultipleContentEntry = ({
  contentEntryIds,
  contentModelId,
  spaceId,
  spaceEnvironmentId,
}) => {
  return {
    type: SWAGGER,
    types: [
      REVERT_MULTIPLE_CONTENT_ENTRY,
      REVERT_MULTIPLE_CONTENT_ENTRY_SUCCESS,
      REVERT_MULTIPLE_CONTENT_ENTRY_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["content-entry-controller"].revertContentEntryData_1(
        {
          contentEntryId: contentEntryIds[0],
          contentModelId,
          spaceEnvironmentId: spaceEnvironmentId,
          spaceId: spaceId,
        },
        {}
      );
    },
  };
};

export const fetchAllContentEntries = (spaceId, spaceEnvironmentId, data) => {
  const { sortBy = {}, filters = {} } = data || {};
  let sortCriteria = "";
  let filterCriteria = "";

  const updatedFilters = { ...filters };

  if (
    "lastUpdatedBy" in updatedFilters &&
    updatedFilters["lastUpdatedBy"] === "Any"
  ) {
    delete updatedFilters["lastUpdatedBy"];
  }
  if ("createdBy" in updatedFilters && updatedFilters["createdBy"] === "Any") {
    delete updatedFilters["createdBy"];
  }

  if (Object.keys(updatedFilters).length) {
    filterCriteria = Object.keys(updatedFilters)
      .map((key) => {
        if (key === "mediaType" && updatedFilters[key] === "Image") {
          return "mediaType:like:image";
        } else {
          return `${key}:eq:${updatedFilters[key]}`;
        }
      })
      .join(",");
  }

  if (Object.keys(sortBy).length) {
    sortCriteria = Object.keys(sortBy)
      .map((key) => {
        return `${key}:${sortBy[key]}`;
      })
      .join(",");
  }

  return {
    type: SWAGGER,
    types: [
      FETCH_ALL_CONTENT_ENTRIES,
      FETCH_ALL_CONTENT_ENTRIES_SUCCESS,
      FETCH_ALL_CONTENT_ENTRIES_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      const requestParams = {
        pageNo: 0,
        pageSize: 1000,
        spaceEnvironmentId: spaceEnvironmentId,
        spaceId: spaceId,
        ...(filterCriteria ? { filterCriteria } : {}),
        ...(sortCriteria ? { sortCriteria } : {}),
      };
      return api["content-entry-controller"].getAll_1({
        ...requestParams,
      });
    },
  };
};

export const createContentEntry = (data, spaceId, spaceEnvironmentId) => {
  return {
    type: SWAGGER,
    types: [CREATE_CONTENT, CREATE_CONTENT_SUCCESS, CREATE_CONTENT_FAILURE],
    skipAuth: false,
    swagger: (api) => {
      return api["content-entry-controller"].createContentEntry(
        {},
        {
          requestBody: {
            ...data,
            spaceEnvironmentId: spaceEnvironmentId,
            spaceId: spaceId,
          },
        }
      );
    },
  };
};

export const updateContentEntry = (id, data, spaceId, spaceEnvironmentId) => {
  return {
    type: SWAGGER,
    types: [UPDATE_CONTENT, UPDATE_CONTENT_SUCCESS, UPDATE_CONTENT_FAILURE],
    skipAuth: false,
    swagger: (api) => {
      return api["content-entry-controller"].updateContentEntry(
        {
          contentEntryId: id,
        },
        {
          requestBody: {
            ...data,
            spaceEnvironmentId: spaceEnvironmentId,
            spaceId: spaceId,
          },
        }
      );
    },
  };
};

export const getContentEntryById = (data, spaceId, spaceEnvironmentId) => {
  return {
    type: SWAGGER,
    types: [
      GET_CONTENT_ENTRY_BY_ID,
      GET_CONTENT_ENTRY_BY_ID_SUCCESS,
      GET_CONTENT_ENTRY_BY_ID_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["content-entry-controller"].getById_1(
        {
          contentEntryId: data,
          spaceEnvironmentId: spaceEnvironmentId,
          spaceId: spaceId,
        },
        {}
      );
    },
  };
};

export const deleteContentEntry = (data, spaceId, spaceEnvironmentId) => {
  return {
    type: SWAGGER,
    types: [
      DELETE_CONTENT_ENTRY,
      DELETE_CONTENT_ENTRY_SUCCESS,
      DELETE_CONTENT_ENTRY_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["content-entry-controller"].deleteContentEntry(
        {
          ...data,
          spaceEnvironmentId: spaceEnvironmentId,
          spaceId: spaceId,
        },
        {}
      );
    },
  };
};

export const filterContentTable = (id, title) => {
  return {
    type: "FILTER_CONTENT_VALUE",
    filterValue: id,
    title,
  };
};
export const filterContentStatus = (title) => {
  return {
    type: "FILTER_CONTENT_STATUS",
    // statusFilterValue: id,
    status: title,
  };
};

export const setContentEntryStatus = (status) => {
  return {
    type: "SET_ENTRY_STATUS",
    status,
  };
};

export const setCurrTitle = (title, spaceId, spaceEnvironmentId) => {
  return {
    type: SET_CONTENT_CURRENT_TITLE,
    data: {
      title,
      spaceEnvironmentId: spaceEnvironmentId,
      spaceId: spaceId,
    },
  };
};

export const setContentSubmitButton = (val) => ({
  type: SET_CONTENT_TYPE_BUTTON,
  data: val,
});
export const setReferenceContentSubmitButton = (val) => ({
  type: SET_CONTENT_TYPE_BUTTON_REFERENCE,
  data: val,
});

export const addSortingContentEntry = (key, value) => ({
  type: CONTENT_ENTRY_ADD_SORTING,
  key,
  value,
});

export const addFiltersContentEntry = (key, value) => ({
  type: ADD_FILTERS_CONTENT_ENTRY,
  key,
  value,
});
export const addFilterUdatedByMeContentEntry = (key, value) => ({
  type: ADD_FILTER_UPDATED_BY_ME_CONTENT_ENTRY,
  key,
  value,
});

export const removeContentEntryFilter = (key) => ({
  type: REMOVE_FILTER_CONTENT_ENTRY,
  key,
});
