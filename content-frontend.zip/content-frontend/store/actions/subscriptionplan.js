import {
  FETCH_ALL_SUBSCRIPTION_PLAN,
  FETCH_ALL_SUBSCRIPTION_PLAN_FAILURE,
  FETCH_ALL_SUBSCRIPTION_PLAN_SUCCESS,
  SET_USER_SUBSCRIPTION,
  SWAGGER,
} from "./actionTypes";

export const fetchAllSubscriptionPlan = () => {
  return {
    type: SWAGGER,
    types: [
      FETCH_ALL_SUBSCRIPTION_PLAN,
      FETCH_ALL_SUBSCRIPTION_PLAN_SUCCESS,
      FETCH_ALL_SUBSCRIPTION_PLAN_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["subscription-plan-controller"].getAllSubscriptionPlan({
        pageNo: 0,
        pageSize: 1000,
      });
    },
  };
};

export const setUserSubscription = (data) => ({
  type: SET_USER_SUBSCRIPTION,
  payload: data,
});
