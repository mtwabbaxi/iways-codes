import {
  FETCH_ALL_SPACES,
  FETCH_ALL_SPACES_SUCCESS,
  FETCH_ALL_SPACES_FAILURE,
  FETCH_ENVIRONMENT_BY_ID,
  FETCH_ENVIRONMENT_BY_ID_SUCCESS,
  FETCH_ENVIRONMENT_BY_ID_FAILURE,
  ADD_SPACE,
  ADD_SPACE_SUCCESS,
  ADD_SPACE_FAILURE,
  SWAGGER,
} from "@/store/actions/actionTypes";

export const fetchAllSpaces = () => {
  return {
    type: SWAGGER,
    types: [
      FETCH_ALL_SPACES,
      FETCH_ALL_SPACES_SUCCESS,
      FETCH_ALL_SPACES_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["space-controller"].getAllSpaces({
        pageNo: 0,
        pageSize: 100,
      });
    },
  };
};

export const fetchEnvironmentBySpaceId = (spaceId) => {
  return {
    type: SWAGGER,
    types: [
      FETCH_ENVIRONMENT_BY_ID,
      FETCH_ENVIRONMENT_BY_ID_SUCCESS,
      FETCH_ENVIRONMENT_BY_ID_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["space-environment-controller"].getBySpaceId({
        pageNo: 0,
        pageSize: 100,
        spaceId: spaceId,
      });
    },
  };
};

export const addSpace = (data) => {
  return {
    type: SWAGGER,
    types: [ADD_SPACE, ADD_SPACE_SUCCESS, ADD_SPACE_FAILURE],
    skipAuth: false,
    swagger: (api) => {
      return api["space-controller"].createSpace(
        {},
        {
          requestBody: {
            title: data?.title,
            description: data?.description,
          },
        }
      );
    },
  };
};

export const deleteSpace = (spaceId) => {
  return {
    type: SWAGGER,
    types: [ADD_SPACE, ADD_SPACE_SUCCESS, ADD_SPACE_FAILURE],
    skipAuth: false,
    swagger: (api) => {
      return api["space-controller"].deleteSpace({ spaceId });
    },
  };
};
