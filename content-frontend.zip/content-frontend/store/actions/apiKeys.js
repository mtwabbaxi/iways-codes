import {
  FETCH_ALL_API_KEYS,
  FETCH_ALL_API_KEYS_SUCCESS,
  FETCH_ALL_API_KEYS_FAILURE,
  CREATE_API_KEY,
  CREATE_API_KEY_SUCCESS,
  CREATE_API_KEY_FAILURE,
  SWAGGER,
  DELETE_API_KEY,
  DELETE_API_KEY_SUCCESS,
  DELETE_API_KEY_FAILURE,
  UPDATE_API_KEY,
  UPDATE_API_KEY_SUCCESS,
  UPDATE_API_KEY_FAILURE,
  SET_API_KEYS_LOADING_TRUE,
} from "./actionTypes";

export const getAllAPIKeys = ({ spaceId }) => {
  return {
    type: SWAGGER,
    types: [
      FETCH_ALL_API_KEYS,
      FETCH_ALL_API_KEYS_SUCCESS,
      FETCH_ALL_API_KEYS_FAILURE,
    ],
    skipAuth: false,
    swagger: (api) => {
      return api["api-key-controller"].getAPIKeys({
        spaceId,
      });
    },
  };
};

export const createAPIKey = ({
  spaceId,
  spaceEnvironmentIds,
  name,
  description,
}) => {
  return {
    type: SWAGGER,
    types: [CREATE_API_KEY, CREATE_API_KEY_SUCCESS, CREATE_API_KEY_FAILURE],
    skipAuth: false,
    swagger: (api) => {
      return api["api-key-controller"].createAPIKey(
        {},
        {
          requestBody: {
            name,
            description,
            spaceEnvironmentIds,
            spaceId,
          },
        }
      );
    },
  };
};

export const deleteAPIKeyById = ({ spaceId, spaceEnvironmentId, apiKeyId }) => {
  return {
    type: SWAGGER,
    types: [DELETE_API_KEY, DELETE_API_KEY_SUCCESS, DELETE_API_KEY_FAILURE],
    skipAuth: false,
    swagger: (api) => {
      return api["api-key-controller"].deleteApiKey(
        {
          spaceId,
          spaceEnvironmentId,
          apiKeyId,
        },
        {}
      );
    },
  };
};

export const updateAPIKeyById = ({ data, apiKeyId }) => {
  return {
    type: SWAGGER,
    types: [UPDATE_API_KEY, UPDATE_API_KEY_SUCCESS, UPDATE_API_KEY_FAILURE],
    skipAuth: false,
    swagger: (api) => {
      return api["api-key-controller"].updateApiKey(
        {
          apiKeyId,
        },
        {
          requestBody: { ...data },
        }
      );
    },
  };
};

export const setAPIKeyLoadingTrue = () => ({
  type: SET_API_KEYS_LOADING_TRUE,
  payload: {},
});
