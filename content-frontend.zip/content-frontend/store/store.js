import { applyMiddleware, combineReducers, compose, createStore } from "redux";
import thunk from "redux-thunk";
import SwaggerMiddleware from "./middleware/swagger";
import contentModelReducer from "@/store/reducers/contentModel";
import userReducer from "@/store/reducers/user";
import contentModelEntryReducer from "@/store/reducers/contentEntry";
import formReducer from "@/store/reducers/form";
import mediaReducer from "@/store/reducers/media";
import spacesReducer from "@/store/reducers/spaces";
import environmentsReducer from "./reducers/environments";
import localesReducer from "./reducers/locales";
import apiKeyReducer from "./reducers/apiKey";
import subscriptionPlanReducer from "./reducers/subscriptionplan";

const getStore = (reducers) => {
  const rootReducer = combineReducers(reducers);
  const logger = (store) => (next) => (action) => {
    if (
      process.env.REACT_APP_ENV === "development" ||
      process.env.REACT_APP_ENV === "staging"
    ) {
      // console.log('[Middleware] Dispatching', action);
    }
    const result = next(action);
    if (
      process.env.REACT_APP_ENV === "development" ||
      process.env.REACT_APP_ENV === "staging"
    ) {
      // console.log('[Middleware] next state', store.getState());
    }
    return result;
  };

  const composeEnhancers = compose;
  return createStore(
    rootReducer,
    composeEnhancers(applyMiddleware(thunk, SwaggerMiddleware()))
  );
};

// Add reducers here!
const store = getStore({
  contentModel: contentModelReducer,
  contentEntries: contentModelEntryReducer,
  form: formReducer,
  user: userReducer,
  media: mediaReducer,
  spaces: spacesReducer,
  environments: environmentsReducer,
  locales: localesReducer,
  apiKeys: apiKeyReducer,
  subscriptionPlans: subscriptionPlanReducer,
});

export default store;
