import {
  FETCH_ALL_LOCALES,
  FETCH_ALL_LOCALES_SUCCESS,
  CREATE_LOCALE,
  CREATE_LOCALE_SUCCESS,
  CREATE_LOCALE_FAILURE,
  SET_LOCALE_CURRENT_VALUE,
  SET_LOCALE_SUBMIT_BUTTON,
  SELETED_LOCALE_VALUE,
  UPDATE_LOCALE_ASSET,
  UPDATE_LOCALE_ASSET_SUCCESS,
  UPDATE_LOCALE_ASSET_FAILURE,
  DELETE_LOCALES,
  DELETE_LOCALES_SUCCESS,
  DELETE_LOCALES_FAILURE,
  SET_CONTENT_ENTRY_SELECTED_LANGUAGES,
  FETCH_ALL_ENABLE_LANGUAGES,
  FETCH_ALL_ENABLE_LANGUAGES_SUCCESS,
  FETCH_ALL_ENABLE_LANGUAGES_FAILURE,
  REMOVE_OR_ADD_ENABLE_LANGUAGES,
  REMOVE_OR_ADD_ENABLE_LANGUAGES_SUCCESS,
  REMOVE_OR_ADD_ENABLE_LANGUAGES_FAILURE,
} from "../actions/actionTypes";

const initialState = {
  allLocales: { content: [], totalPages: 0, totalElements: 0 },
  filterValue: null,
  selectedModel: "Any",
  contentEntryValues: {},
  contentEntryStatus: "",
  contentCurrTitle: [],
  addLocales: null,
  localeCurrValue: "",
  isLocaleSubmit: false,
  seletedLocaleValue: [],
  contentEntrySelectedLanguages: ["en-US"],
  loading: false,
};
const localesReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_ALL_LOCALES:
      return {
        ...state,
      };
    case FETCH_ALL_LOCALES_SUCCESS:
      return {
        ...state,
        allLocales: action.result.body.data,
      };
    case SET_LOCALE_CURRENT_VALUE:
      return {
        ...state,
        localeCurrValue: action?.data?.value,
      };
    case SET_LOCALE_SUBMIT_BUTTON:
      return {
        ...state,
        isLocaleSubmit: action?.data,
      };
    case CREATE_LOCALE:
      return {
        ...state,
      };
    case CREATE_LOCALE_SUCCESS:
      return {
        ...state,
        addLocales: action.result.body.data,
      };
    case CREATE_LOCALE_FAILURE:
      return {
        ...state,
      };
    case SELETED_LOCALE_VALUE:
      return {
        ...state,
        seletedLocaleValue: action?.data,
      };
    case UPDATE_LOCALE_ASSET:
      return {
        ...state,
      };
    case UPDATE_LOCALE_ASSET_SUCCESS:
      return {
        ...state,
        addLocales: action.result.body.data,
      };
    case UPDATE_LOCALE_ASSET_FAILURE:
      return {
        ...state,
      };
    case DELETE_LOCALES:
      return {
        ...state,
      };
    case DELETE_LOCALES_SUCCESS:
      return {
        ...state,
        addLocales: action.result.body.data,
      };
    case DELETE_LOCALES_FAILURE:
      return {
        ...state,
      };

    case SET_CONTENT_ENTRY_SELECTED_LANGUAGES:
      return {
        ...state,
        contentEntrySelectedLanguages: action.payload,
      };
    case FETCH_ALL_ENABLE_LANGUAGES:
      return { ...state, loading: true };
    case FETCH_ALL_ENABLE_LANGUAGES_SUCCESS:
      const { responseCode = 0 } = action?.result?.body || {};
      if (responseCode === 200) {
        const enableLanguages =
          action?.result?.body?.response?.enableLanguages || [];
        const hasEnglish = enableLanguages.includes("en-US");

        return {
          ...state,
          contentEntrySelectedLanguages: hasEnglish
            ? [...enableLanguages]
            : [...enableLanguages, "en-US"],
          loading: false,
        };
      }
      return { ...state, loading: false };
    case FETCH_ALL_ENABLE_LANGUAGES_FAILURE:
      return {
        ...state,
        contentEntrySelectedLanguages: ["en-US"],
        loading: false,
      };
    case REMOVE_OR_ADD_ENABLE_LANGUAGES:
      return { ...state, loading: true };
    case REMOVE_OR_ADD_ENABLE_LANGUAGES_SUCCESS:
      return { ...state, loading: false };
    case REMOVE_OR_ADD_ENABLE_LANGUAGES_FAILURE:
      return { ...state, loading: false };
    default:
      return state;
  }
};

export default localesReducer;
