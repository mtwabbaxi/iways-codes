const initialState = {
  shouldSubmitForm: false,
  shouldSubmitFormForReference: false,
};

const formReducer = (state = initialState, action) => {
  switch (action.type) {
    case "TRIGGER_FORM_SUBMISSION":
      return {
        ...state,
        shouldSubmitForm: !state.shouldSubmitForm,
      };
    case "TRIGGER_FORM_SUBMISSION_FOR_REFERENCE":
      return {
        ...state,
        shouldSubmitFormForReference: !state.shouldSubmitFormForReference,
      };
    default:
      return state;
  }
};

export default formReducer;
