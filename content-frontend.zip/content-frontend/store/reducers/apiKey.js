import {
  FETCH_ALL_API_KEYS,
  FETCH_ALL_API_KEYS_SUCCESS,
  FETCH_ALL_API_KEYS_FAILURE,
  CREATE_API_KEY,
  CREATE_API_KEY_SUCCESS,
  CREATE_API_KEY_FAILURE,
  SWAGGER,
  DELETE_API_KEY,
  DELETE_API_KEY_SUCCESS,
  DELETE_API_KEY_FAILURE,
  UPDATE_API_KEY,
  UPDATE_API_KEY_SUCCESS,
  UPDATE_API_KEY_FAILURE,
  SET_API_KEYS_LOADING_TRUE,
} from "../actions/actionTypes";

const initialState = {
  allApiKeys: [],
  apiKeysLoading: false,
};
const apiKeyReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_ALL_API_KEYS:
    case FETCH_ALL_API_KEYS_SUCCESS:
      const { response = [] } = action?.result?.body || {};
      return {
        ...state,
        allApiKeys: response || [],
      };
    case FETCH_ALL_API_KEYS_FAILURE:
      return {
        ...state,
        allApiKeys: [],
      };
    case CREATE_API_KEY:
      return {
        ...state,
        apiKeysLoading: true,
      };
    case CREATE_API_KEY_SUCCESS:
      return {
        ...state,
        apiKeysLoading: false,
      };
    case CREATE_API_KEY_FAILURE:
      return {
        ...state,
        apiKeysLoading: false,
      };
    case DELETE_API_KEY:
      return {
        ...state,
        apiKeysLoading: true,
      };
    case DELETE_API_KEY_SUCCESS:
      return {
        ...state,
        apiKeysLoading: false,
      };
    case DELETE_API_KEY_FAILURE:
      return {
        ...state,
        apiKeysLoading: false,
      };
    case UPDATE_API_KEY:
      return {
        ...state,
        apiKeysLoading: true,
      };
    case UPDATE_API_KEY_SUCCESS:
      return {
        ...state,
        apiKeysLoading: false,
      };
    case UPDATE_API_KEY_FAILURE:
      return {
        ...state,
        apiKeysLoading: false,
      };
    case SET_API_KEYS_LOADING_TRUE: {
      return {
        ...state,
        apiKeysLoading: true,
      };
    }
    default:
      return state;
  }
};

export default apiKeyReducer;
