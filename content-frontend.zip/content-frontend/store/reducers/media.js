import {
  FETCH_ALL_MEDIA_ASSET_SUCCESS,
  UPLOAD_MEDIA,
  UPLOAD_MEDIA_FAILURE,
  UPLOAD_MEDIA_SUCCESS,
  FETCH_MEDIA_ASSET_BY_ID_SUCCESS,
  SET_CURRENT_TITLE,
  SET_CURRENT_DESCRIPTION,
  SET_CURRENT_UPLOADFILE,
  SET_MEDIA_TYPE_BUTTON,
  SET_CREATE_MEDIA_OPEN,
  SET_EXISTING_MEDIA_OPEN,
  DELETE_MEDIA,
  DELETE_MEDIA_SUCCESS,
  DELETE_MEDIA_FAILURE,
  DELETE_MULTIPLE_MEDIA_ASSET,
  DELETE_MULTIPLE_MEDIA_ASSET_SUCCESS,
  DELETE_MULTIPLE_MEDIA_ASSET_FAILURE,
  REVERT_MULTIPLE_MEDIA_ASSET,
  REVERT_MULTIPLE_MEDIA_ASSET_SUCCESS,
  REVERT_MULTIPLE_MEDIA_ASSET_FAILURE,
  UPDATE_MULTIPLE_MEDIA_ASSET,
  UPDATE_MULTIPLE_MEDIA_ASSET_SUCCESS,
  UPDATE_MULTIPLE_MEDIA_ASSET_FAILURE,
  ADD_FILTERS_MEDIA,
  REMOVE_FILTERS_MEDIA,
  MEDIA_APPLY_SORTING,
  MEDIA_REMOVE_SORTING,
} from "@/store/actions/actionTypes";

const initialState = {
  files: null,
  allAssets: { content: [], totalPages: 0, totalElements: 0 },
  assetValues: null,
  mediaType: null,
  mediaDimensions: null,
  mediaEntryStatus: "",
  createMediaCurrTitle: [],
  createMediaCurrDescription: [],
  createMediaCurrUploadFile: [],
  mediaSubmitButton: "",
  mediaCreateOpen: "",
  existingMediaOpen: [],
  filters: {},
  sortBy: {},
};

const mediaReducer = (state = initialState, action) => {
  const { key = "", value = "" } = action;
  switch (action.type) {
    case "UPLOAD_MEDIA":
      return {
        ...state,
      };
    case "UPLOAD_MEDIA_SUCCESS":
      return {
        ...state,
        files: action.result.body.response,
        mediaType: action.mediaType,
        mediaDimensions: action.mediaDimensions,
      };
    case "FETCH_ALL_MEDIA_ASSET_SUCCESS":
      return {
        ...state,
        allAssets: action.result.body.data,
      };
    case "FETCH_MEDIA_ASSET_BY_ID_SUCCESS":
      return {
        ...state,
        assetValues: action.result.body.response,
      };
    case "SET_MEDIA_ENTRY_STATUS":
      return {
        ...state,
        mediaEntryStatus: action.status,
      };
    case SET_CURRENT_TITLE:
      return {
        ...state,
        createMediaCurrTitle: action?.data?.title,
      };
    case SET_CURRENT_DESCRIPTION:
      return {
        ...state,
        createMediaCurrDescription: action?.data?.description,
      };
    case SET_CURRENT_UPLOADFILE:
      return {
        ...state,
        createMediaCurrUploadFile: action?.data?.file,
      };
    case SET_MEDIA_TYPE_BUTTON:
      return {
        ...state,
        mediaSubmitButton: action?.data,
      };
    case SET_CREATE_MEDIA_OPEN:
      return {
        ...state,
        mediaCreateOpen: action?.data,
      };
    case SET_EXISTING_MEDIA_OPEN:
      return {
        ...state,
        existingMediaOpen: action?.data,
      };
    case DELETE_MEDIA:
      return {
        ...state,
      };
    case DELETE_MEDIA_SUCCESS:
      return {
        ...state,
        createMediaCurrUploadFile: action.fileName,
      };
    case DELETE_MEDIA_FAILURE:
      return {
        ...state,
      };
    case DELETE_MULTIPLE_MEDIA_ASSET:
      return {
        ...state,
      };
    case DELETE_MULTIPLE_MEDIA_ASSET_SUCCESS:
      return {
        ...state,
      };
    case DELETE_MULTIPLE_MEDIA_ASSET_FAILURE:
      return {
        ...state,
      };
    case REVERT_MULTIPLE_MEDIA_ASSET:
      return {
        ...state,
      };
    case REVERT_MULTIPLE_MEDIA_ASSET_SUCCESS:
      return {
        ...state,
      };
    case REVERT_MULTIPLE_MEDIA_ASSET_FAILURE:
      return {
        ...state,
      };
    case UPDATE_MULTIPLE_MEDIA_ASSET:
      return {
        ...state,
      };
    case UPDATE_MULTIPLE_MEDIA_ASSET_SUCCESS:
      return {
        ...state,
      };
    case UPDATE_MULTIPLE_MEDIA_ASSET_FAILURE:
      return {
        ...state,
      };
    case ADD_FILTERS_MEDIA:
      const updatedFilters = { ...state.filters } || {};
      updatedFilters[key] = value;
      return {
        ...state,
        filters: updatedFilters,
      };
    case REMOVE_FILTERS_MEDIA:
      const currentFilters = { ...state.filters };
      if (currentFilters.hasOwnProperty(key)) {
        delete currentFilters[key];
        return {
          ...state,
          filters: { ...currentFilters },
        };
      }
      return { ...state };
    case MEDIA_APPLY_SORTING:
      const updatingSorting = { ...state.sortBy } || {};
      updatingSorting[key] = value;
      return {
        ...state,
        sortBy: updatingSorting,
      };
    case MEDIA_REMOVE_SORTING:
      const currentSorting = { ...state.sortBy };
      if (currentSorting.hasOwnProperty(key)) {
        delete currentSorting[key];
        return {
          ...state,
          sortBy: { ...currentSorting },
        };
      }
      return { ...state };

    default:
      return state;
  }
};

export default mediaReducer;
