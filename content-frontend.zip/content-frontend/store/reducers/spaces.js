import {
  FETCH_ALL_SPACES,
  FETCH_ALL_SPACES_SUCCESS,
  FETCH_ALL_SPACES_FAILURE,
  FETCH_ENVIRONMENT_BY_ID_SUCCESS,
  ADD_SPACE,
  ADD_SPACE_SUCCESS,
  ADD_SPACE_FAILURE,
  DELETE_SPACE,
  DELETE_SPACE_SUCCESS,
  DELETE_SPACE_FAILURE,
} from "@/store/actions/actionTypes";

const initialState = {
  allSpaces: null,
  environment: null,
  spaceId: null,
  addSpace: null,
};

const spacesReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_ALL_SPACES:
      return {
        ...state,
      };
    case FETCH_ALL_SPACES_SUCCESS:
      return {
        ...state,
        allSpaces: action.result.body.data,
      };
    case FETCH_ALL_SPACES_FAILURE:
      return {
        ...state,
      };
    case FETCH_ENVIRONMENT_BY_ID_SUCCESS:
      return {
        ...state,
        environment: action.result.body.data,
      };
    case ADD_SPACE:
      return {
        ...state,
      };
    case ADD_SPACE_SUCCESS:
      return {
        ...state,
        addSpace: action.result.body.data,
      };
    case ADD_SPACE_FAILURE:
      return {
        ...state,
      };
    case DELETE_SPACE:
    case DELETE_SPACE_SUCCESS:
    case DELETE_SPACE_FAILURE:

    default:
      return state;
  }
};

export default spacesReducer;
