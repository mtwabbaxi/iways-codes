import {
  FETCH_ALL_CONTENT_ENTRIES,
  FETCH_ALL_CONTENT_ENTRIES_SUCCESS,
  GET_CONTENT_ENTRY_BY_ID,
  GET_CONTENT_ENTRY_BY_ID_SUCCESS,
  GET_CONTENT_ENTRY_BY_ID_FAILURE,
  SET_CONTENT_CURRENT_TITLE,
  SET_CONTENT_TYPE_BUTTON,
  DELETE_MULTIPLE_CONTENT_ENTRY,
  DELETE_MULTIPLE_CONTENT_ENTRY_SUCCESS,
  DELETE_MULTIPLE_CONTENT_ENTRY_FAILURE,
  REVERT_MULTIPLE_CONTENT_ENTRY,
  REVERT_MULTIPLE_CONTENT_ENTRY_SUCCESS,
  REVERT_MULTIPLE_CONTENT_ENTRY_FAILURE,
  UPDATE_MULTIPLE_CONTENT_ENTRY,
  UPDATE_MULTIPLE_CONTENT_ENTRY_SUCCESS,
  UPDATE_MULTIPLE_CONTENT_ENTRY_FAILURE,
  CONTENT_ENTRY_ADD_SORTING,
  ADD_FILTERS_CONTENT_ENTRY,
  REMOVE_FILTER_CONTENT_ENTRY,
  SET_CONTENT_TYPE_BUTTON_REFERENCE,
  ADD_FILTER_UPDATED_BY_ME_CONTENT_ENTRY,
} from "../actions/actionTypes";

const initialState = {
  contentEntries: { content: [], totalPages: 0, totalElements: 0 },
  filterValue: null,
  statusFilterValue: null,
  selectedStatus: "",
  selectedModel: "Any",
  contentEntryValues: {},
  contentEntryStatus: "",
  contentCurrTitle: [],
  contentSubmitButton: false,
  contentReferenceSubmitButton: false,
  sortBy: {
    lastModifiedDate: "DESC",
  },
  filters: {},
};
const contentModelEntryReducer = (state = initialState, action) => {
  const { key = "", value = "" } = action || {};
  switch (action.type) {
    case FETCH_ALL_CONTENT_ENTRIES:
      GET_CONTENT_ENTRY_BY_ID;
      return {
        ...state,
      };
    case FETCH_ALL_CONTENT_ENTRIES_SUCCESS:
      return {
        ...state,
        contentEntries: action.result.body.data,
      };
    case GET_CONTENT_ENTRY_BY_ID_SUCCESS:
      return {
        ...state,
        contentEntryValues: action.result.body.response,
      };
    case GET_CONTENT_ENTRY_BY_ID_FAILURE:
      return {
        ...state,
      };
    case "FILTER_CONTENT_VALUE":
      return {
        ...state,
        filterValue: action.filterValue,
        selectedModel: action.title,
      };

    case "FILTER_CONTENT_STATUS":
      return {
        ...state,
        selectedStatus: action.status,
      };
    case "SET_ENTRY_STATUS":
      return {
        ...state,
        contentEntryStatus: action.status,
      };
    case SET_CONTENT_CURRENT_TITLE:
      return {
        ...state,
        contentCurrTitle: action?.data?.title,
      };
    case SET_CONTENT_TYPE_BUTTON:
      return {
        ...state,
        contentSubmitButton: action?.data,
      };
    case SET_CONTENT_TYPE_BUTTON_REFERENCE:
      return {
        ...state,
        contentReferenceSubmitButton: action?.data,
      };
    case DELETE_MULTIPLE_CONTENT_ENTRY:
      return {
        ...state,
      };
    case DELETE_MULTIPLE_CONTENT_ENTRY_SUCCESS:
      return {
        ...state,
      };
    case DELETE_MULTIPLE_CONTENT_ENTRY_FAILURE:
      return {
        ...state,
      };
    case REVERT_MULTIPLE_CONTENT_ENTRY:
      return {
        ...state,
      };
    case REVERT_MULTIPLE_CONTENT_ENTRY_SUCCESS:
      return {
        ...state,
      };
    case REVERT_MULTIPLE_CONTENT_ENTRY_FAILURE:
      return {
        ...state,
      };
    case UPDATE_MULTIPLE_CONTENT_ENTRY:
      return {
        ...state,
      };
    case UPDATE_MULTIPLE_CONTENT_ENTRY_SUCCESS:
      return {
        ...state,
      };
    case UPDATE_MULTIPLE_CONTENT_ENTRY_FAILURE:
      return {
        ...state,
      };
    case CONTENT_ENTRY_ADD_SORTING:
      const updatingSorting = { ...state.sortBy } || {};
      updatingSorting[key] = value;
      return {
        ...state,
        sortBy: updatingSorting,
      };
    case ADD_FILTERS_CONTENT_ENTRY:
      const updatedFilters = { ...state.filters } || {};
      updatedFilters[key] = value;
      return {
        ...state,
        filters: updatedFilters,
      };
    case ADD_FILTER_UPDATED_BY_ME_CONTENT_ENTRY:
      const updatedCreatedByMeFilters = { ...state.filters } || {};
      updatedCreatedByMeFilters[key] = value;
      return {
        ...state,
        filters: updatedCreatedByMeFilters,
      };
    case REMOVE_FILTER_CONTENT_ENTRY:
      const currentFilters = { ...state.filters };
      if (currentFilters.hasOwnProperty(key)) {
        delete currentFilters[key];
        return {
          ...state,
          filters: { ...currentFilters },
        };
      }
      return { ...state };
    default:
      return state;
  }
};

export default contentModelEntryReducer;
