import {
  LOGIN,
  LOGIN_SUCCESS,
  LOGIN_FAILURE,
  SIGNUP,
  SIGNUP_SUCCESS,
  SIGNUP_FAILURE,
} from "../actions/actionTypes";
import Auth from "@/utils/auth";

const auth = new Auth();
const initialState = {
  user: auth.getUserCookie(),
};
const userReducer = (state = initialState, action) => {
  let user;
  switch (action.type) {
    case LOGIN:
      return {
        ...state,
        loading: true,
      };
    case LOGIN_SUCCESS:
      user = action.result.body.data ?? {};
      if (user.error === "Authentication failed") {
        auth.removeAuth();
        return {
          ...state,
          user: null,
          loading: false,
        };
      }
      if (user.error) {
        return {
          ...state,
          user: null,
          loading: false,
          fetchTokenError: true,
        };
      }
      auth.setUser(user);
      return {
        ...state,
        user: { ...user, name: user?.firstName + " " + user?.lastName },
        loading: false,
      };
    case SIGNUP:
      return {
        ...state,
        loading: true,
      };
    case SIGNUP_SUCCESS:
      user = action.result.body.data ?? {};
      if (user.error === "Authentication failed") {
        auth.removeAuth();
        return {
          ...state,
          user: null,
          loading: false,
        };
      }
      if (user.error) {
        return {
          ...state,
          user: null,
          loading: false,
          fetchTokenError: true,
        };
      }
      // auth.setUser(user)
      return {
        ...state,
        user: { ...user, name: user?.firstName + " " + user?.lastName },
        loading: false,
      };
    default:
      return state;
  }
};

export default userReducer;
