import {
  CREATE_MODEL,
  CREATE_MODEL_SUCCESS,
  CREATE_MODEL_FAILURE,
  FETCH_ALL_CONTENT_MODELS_SUCCESS,
  FETCH_ALL_CONTENT_MODELS,
  GET_CONTENT_MODEL_BY_ID,
  GET_CONTENT_MODEL_BY_ID_REFEREENCE,
  GET_CONTENT_MODEL_BY_ID_SUCCESS,
  GET_CONTENT_MODEL_BY_ID_SUCCESS_REFERENCE,
  GET_CONTENT_MODEL_BY_ID_FAILURE,
  GET_CONTENT_MODEL_BY_ID_FAILURE_REFERENCE,
  UPDATE_CONTENT_MODEL,
  UPDATE_CONTENT_MODEL_SUCCESS,
  UPDATE_CONTENT_MODEL_FAILURE,
  DELETE_CONTENT_MODEL,
  DELETE_CONTENT_MODEL_SUCCESS,
  DELETE_CONTENT_MODEL_FAILURE,
  RESET_SELECTED_CONTENT_MODEL,
  MODIFY_SELECTED_CONTENT_MODEL,
  SEARCH_NAME_CONTENT,
  SEARCH_NAME_MEDIA,
  FETCH_ALL_CONTENT_MODELS_FAILURE,
  SAVE_DATE_WHILE_CREATING_MODEL,
  CONTENT_MODEL_UPDDATE_SORTING,
  CONTENT_MODEL_SORTING,
} from "../actions/actionTypes";

const initialState = {
  loading: false,
  deleting: false,
  data: { content: [], totalPages: 0, totalElements: 0 },
  selectedContentModel: null,
  selectedContentModelForReference: null,
  searchNameContent: [],
  searchNameMedia: [],
  savedModelData: {},
  sortBy: {
    name: "ASC",
  },
};
const contentModelReducer = (state = initialState, action) => {
  const { key = "", value = "" } = action;
  switch (action.type) {
    case CREATE_MODEL:
    case UPDATE_CONTENT_MODEL:
    case DELETE_CONTENT_MODEL:
      return {
        ...state,
        loading: true,
      };
    case CREATE_MODEL_SUCCESS:
    case UPDATE_CONTENT_MODEL_SUCCESS:
    case DELETE_CONTENT_MODEL_SUCCESS:
      return {
        ...state,
        loading: false,
      };
    case CREATE_MODEL_FAILURE:
    case UPDATE_CONTENT_MODEL_FAILURE:
    case DELETE_CONTENT_MODEL_FAILURE:
      return {
        ...state,
        loading: false,
      };

    case DELETE_CONTENT_MODEL:
      return {
        ...state,
        deleting: true,
      };
    case DELETE_CONTENT_MODEL_SUCCESS:
      return {
        ...state,
        deleting: false,
      };
    case DELETE_CONTENT_MODEL_FAILURE:
      return {
        ...state,
        deleting: false,
      };
    case FETCH_ALL_CONTENT_MODELS:
      return {
        ...state,
        loading: true,
      };

    case FETCH_ALL_CONTENT_MODELS_SUCCESS:
      if (action.result.body.responseCode === 404) {
        return {
          ...state,
          loading: false,
          data: { content: [], totalPages: 0, totalElements: 0 },
        };
      }
      return {
        ...state,
        loading: false,
        data: action.result.body.data,
      };
    case FETCH_ALL_CONTENT_MODELS_FAILURE:
      return {
        ...state,
        loading: false,
      };
    case GET_CONTENT_MODEL_BY_ID_SUCCESS:
      const {
        result: { body },
      } = action;
      if (body.responseCode === 200) {
        return {
          ...state,
          loading: false,
          selectedContentModel: body.response,
        };
      } else {
        return {
          ...state,
          loading: false,
        };
      }
    case GET_CONTENT_MODEL_BY_ID_SUCCESS_REFERENCE:
      const {
        result: { body: data = {} },
      } = action;
      if (data.responseCode === 200) {
        return {
          ...state,
          selectedContentModelForReference: data.response,
        };
      } else {
        return {
          ...state,
        };
      }

    case GET_CONTENT_MODEL_BY_ID_FAILURE:
      return {
        ...state,
        loading: false,
      };

    case RESET_SELECTED_CONTENT_MODEL:
      return {
        ...state,
        selectedContentModel: null,
      };
    case MODIFY_SELECTED_CONTENT_MODEL:
      return {
        ...state,
        selectedContentModel: {
          ...state.selectedContentModel,
          ...action.data,
        },
      };
    case SEARCH_NAME_CONTENT:
      return {
        ...state,
        searchNameContent: action.data,
      };
    case SEARCH_NAME_MEDIA:
      return {
        ...state,
        searchNameMedia: action.data,
      };
    case SAVE_DATE_WHILE_CREATING_MODEL:
      return {
        ...state,
        savedModelData: action.payload,
      };
    case CONTENT_MODEL_SORTING:
      const sorting = {};
      sorting[key] = value;
      return {
        ...state,
        sortBy: sorting,
      };
    case CONTENT_MODEL_UPDDATE_SORTING:
      if (key in state.sortBy) {
        const updateSorting = { ...state.sortBy };
        updateSorting[key] = value;
        return {
          ...state,
          sortBy: updateSorting,
        };
      }
      return { ...state };
    default:
      return state;
  }
};

export default contentModelReducer;
