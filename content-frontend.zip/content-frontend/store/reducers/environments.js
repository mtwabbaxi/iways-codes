import {
	FETCH_ALL_ENVIRONMENTS,
	FETCH_ALL_ENVIRONMENTS_SUCCESS,
	CREATE_ENVIRONMENT,
	CREATE_ENVIRONMENT_SUCCESS,
	CREATE_ENVIRONMENT_FAILURE,
	DELETE_ENVIRONMENT,
	DELETE_ENVIRONMENT_SUCCESS,
	DELETE_ENVIRONMENT_FAILURE,
	GET_CONTENT_ENTRY_BY_ID,
	GET_CONTENT_ENTRY_BY_ID_SUCCESS,
	GET_CONTENT_ENTRY_BY_ID_FAILURE,
	SET_CONTENT_CURRENT_TITLE,
} from "../actions/actionTypes"

const initialState = {
	allEnvironments: {content: [], totalPages: 0, totalElements: 0},
	filterValue: null,
	selectedModel: "Any",
	contentEntryValues: {},
	contentEntryStatus: "",
	contentCurrTitle: [],
	addEnvironment: null,
}
const environmentsReducer = (state = initialState, action) => {
	switch (action.type) {
		case FETCH_ALL_ENVIRONMENTS:
			return {
				...state,
			}
		case FETCH_ALL_ENVIRONMENTS_SUCCESS:
			return {
				...state,
				allEnvironments: action.result.body.data,
			}
		case GET_CONTENT_ENTRY_BY_ID_SUCCESS:
			return {
				...state,
				contentEntryValues: action.result.body.response,
			}
		case GET_CONTENT_ENTRY_BY_ID_FAILURE:
			return {
				...state,
			}
		case "FILTER_CONTENT_VALUE":
			if (action.filterValue === "any") {
				return {
					...state,
					filterValue: null,
					selectedModel: "Any",
				}
			}
			return {
				...state,
				filterValue: action.filterValue,
				selectedModel: action.title,
			}
		case "SET_ENTRY_STATUS":
			return {
				...state,
				contentEntryStatus: action.status,
			}
		case SET_CONTENT_CURRENT_TITLE:
			return {
				...state,
				contentCurrTitle: action?.data?.title,
			}
		case CREATE_ENVIRONMENT:
			return {
				...state,
			}
		case CREATE_ENVIRONMENT_SUCCESS:
			return {
				...state,
				addEnvironment: action.result.body.data,
			}
		case CREATE_ENVIRONMENT_FAILURE:
			return {
				...state,
			}
		case DELETE_ENVIRONMENT:
			return {
				...state,
			}
		case DELETE_ENVIRONMENT_SUCCESS:
			return {
				...state,
				addEnvironment: action.result.body.data,
			}
		case DELETE_ENVIRONMENT_FAILURE:
			return {
				...state,
			}
		default:
			return state
	}
}

export default environmentsReducer
