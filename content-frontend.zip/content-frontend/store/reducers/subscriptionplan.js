import {
  FETCH_ALL_SUBSCRIPTION_PLAN,
  FETCH_ALL_SUBSCRIPTION_PLAN_SUCCESS,
  FETCH_ALL_SUBSCRIPTION_PLAN_FAILURE,
  SET_USER_SUBSCRIPTION,
} from "../actions/actionTypes";

const initialState = {
  allSubscriptionPlans: {},
  userSubscription: {},
  loading: false,
};

const subscriptionPlanReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_ALL_SUBSCRIPTION_PLAN:
      return {
        ...state,
        loading: true,
      };
    case FETCH_ALL_SUBSCRIPTION_PLAN_SUCCESS:
      if (action?.result?.body?.responseCode === 200) {
        return {
          ...state,
          allSubscriptionPlans: action?.result?.body?.data,
          loading: false,
        };
      }
      return { ...state, loading: false };
    case FETCH_ALL_SUBSCRIPTION_PLAN_FAILURE:
      return { ...state, loading: false };
    case SET_USER_SUBSCRIPTION:
      return { ...state, userSubscription: action.payload };
    default:
      return state;
  }
};

export default subscriptionPlanReducer;
