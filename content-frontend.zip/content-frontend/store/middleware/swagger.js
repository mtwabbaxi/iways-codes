import SwaggerClient from "swagger-client";
import Auth from "../../utils/auth";
import { USER_SERVICE_URL, CONTENT_MANAGEMENT_SERVICE_URL } from "@/config/app";

let spec = {};
let currentFetch;
const getSpec = async (url) => {
  if (spec && spec[url]) {
    return spec[url];
  }
  if (currentFetch && currentFetch.url === url) {
    return currentFetch;
  }
  return (currentFetch = fetch(url)
    .then((res) => res.json())
    .then((specJson) => {
      spec[url] = specJson;
      return specJson;
    }));
};

const runOnceQueue = {};

const SwaggerMiddleware = () => {
  return ({ dispatch, getState }) =>
    (next) =>
    (action) => {
      let opts;
      if (action.service === "user_service") {
        opts = { url: USER_SERVICE_URL };
      } else {
        opts = { url: CONTENT_MANAGEMENT_SERVICE_URL };
      }
      if (typeof action === "function") {
        return action(dispatch, getState);
      }
      if (!action.swagger) {
        return next(action);
      }

      const auth = new Auth();
      return auth
        .checkAuthorization(action.skipAuth)
        .then((token) => getSpec(opts.url))
        .then((providedSpec) => {
          return new SwaggerClient({
            ...opts,
            spec: providedSpec,
            requestInterceptor: async function (req) {
              if (!action.skipAuth) {
                req.headers["Authorization"] = await auth.checkAuthorization();
              }
              return !!opts.requestInterceptor
                ? opts.requestInterceptor(req, action, dispatch, getState)
                : req;
            },
            responseInterceptor(resp) {
              const { status = 0 } = resp || {};
              if (status === 401) {
                window.location.href = "/login";
              }
              return !!opts.responseInterceptor
                ? opts.responseInterceptor(resp, action, dispatch, getState)
                : resp;
            },
          });
        })
        .then(
          (result) => {
            if (!spec) {
              spec = result;
            }
            const { swagger, types, actions, runOnce, ...rest } = action;
            const [REQUEST, SUCCESS, FAILURE] = actions || types;
            const callApi = async (apis, sw) => {
              if (typeof sw !== "function") {
                const error = new Error("Swagger api call is not a function");
                opts.error && opts.error(error);
                throw error;
              }
              if (typeof REQUEST === "function") next(REQUEST(rest));
              else if (REQUEST) next({ ...rest, type: REQUEST });
              !!opts.preRequest && (await opts.preRequest(action));
              if (!runOnce || (runOnce && !runOnceQueue[runOnce])) {
                try {
                  runOnceQueue[runOnce] = true;
                  //   const authorization = await auth.checkAuthorization();
                  const resp = await sw(
                    apis
                    // { Authorization: authorization },
                    // action
                  );
                  if (typeof SUCCESS === "function") {
                    return next(SUCCESS({ ...rest, result: resp }));
                  } else if (SUCCESS !== undefined) {
                    return next({ ...rest, result: resp, type: SUCCESS });
                  }
                } catch (error) {
                  if (error.response.status === 401) {
                    auth.removeAuth();
                    window.location.href = "/login";
                  }
                  if (typeof FAILURE === "function") {
                    return next(FAILURE({ ...rest, error }));
                  } else if (FAILURE !== undefined) {
                    return next({ ...rest, error, type: FAILURE });
                  }
                } finally {
                  runOnceQueue[runOnce] = false;
                  // spec = {}; // Reset the cached spec
                }
              }
            };
            return callApi(result.apis, swagger);
          },
          (err) => opts.error && opts.error(err)
        )
        .catch((err) => opts.error && opts.error(err));
    };
};

export default SwaggerMiddleware;
