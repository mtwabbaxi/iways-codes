import WegweiserService from "./wegweiser/wegweiser.service";

export { WegweiserService };
