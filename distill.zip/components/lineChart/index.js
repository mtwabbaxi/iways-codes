// LineChart.js
import React from 'react';
import { Line } from 'react-chartjs-2';

const LineChart = ({ data }) => {
    const labels = data.map(region => region.region);
    const populationTrendData = data.map(region => region.data['2021']['Bevölkerungsentwicklung seit 2011 (%)']);
    const jobTrendData = data.map(region => region.data['2021']['Arbeitsplatzentwicklung der vergangenen 5 Jahre (%)']);

    const lineChartData = {
        labels,
        datasets: [
            {
                label: 'Population Trend (%)',
                fill: false,
                lineTension: 0.1,
                borderColor: 'rgba(75,192,192,1)',
                borderWidth: 1,
                data: populationTrendData,
            },
            {
                label: 'Job Trend (%)',
                fill: false,
                lineTension: 0.1,
                borderColor: 'rgba(255,99,132,1)',
                borderWidth: 1,
                data: jobTrendData,
            },
        ],
    };

    return <Line data={lineChartData} />;
};

export default LineChart;
