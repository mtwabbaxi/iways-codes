import React from "react";
import { FORECAST_OPTIONS } from "../../../utils/constants";
import { useTranslation } from "react-i18next";
import { IoMdInformation } from "react-icons/io";
import classes from "./forecastOptionTable.module.scss";

export default function ForecastOptionTable({
  setTitle = () => {},
  getStatisticsData = () => {},
  setSliderValue = () => {},
  minYear = 2020,
  handlePopup = () => {},
  setIndicatorIds = [],
  setHasTable = () => {},
  onClick = () => {},
  setSelectedIndicatorInfo = () => {},
}) {
  const { t } = useTranslation("translations");

  const handleData = (indicators) => {
    indicators = indicators.map((i) => i.id);
    setIndicatorIds(indicators);
    handlePopup();
    setHasTable(true);
    onClick(indicators, minYear, false);
    setSliderValue(2006);
  };

  return FORECAST_OPTIONS.map((data, index) => (
    <React.Fragment key={index}>
      <tr style={{ cursor: "default" }}>
        <td
          onClick={() => handleData(data.indicators)}
          style={{ fontWeight: "bold" }}
          className=""
        >
          <div className={classes.flex}>
            {t(data.name)}
            <div onClick={(e) => e.stopPropagation()}>
              <IoMdInformation
                onClick={() =>
                  setSelectedIndicatorInfo(data.indicatorsPopupDetails)
                }
                className={classes["open-information-icon"]}
              />
            </div>
          </div>
        </td>
      </tr>
    </React.Fragment>
  ));
}
