import React, { useEffect } from 'react';

const ComingSoonAnimation = () => {
    useEffect(() => {
        // Load the script dynamically
        const script = document.createElement('script');
        script.src =
            'https://unpkg.com/@dotlottie/player-component@latest/dist/dotlottie-player.mjs';
        script.type = 'module';
        script.async = true;
        document.body.appendChild(script);

        return () => {
            // Clean up by removing the script when component unmounts
            document.body.removeChild(script);
        };
    }, []);

    return (
        <div>
            {/* Render the dotlottie-player component */}
            <dotlottie-player
                src='https://lottie.host/ad62e0b3-c632-4f39-8bf2-a11e1ff0553f/qiiaaTJ2dK.json'
                style={{ height: 300, width: 400 }}
                speed='1'
                direction='1'
                playMode='normal'
                loop
                autoplay
            ></dotlottie-player>
        </div>
    );
};

export default ComingSoonAnimation;
