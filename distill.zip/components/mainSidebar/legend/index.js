import React from "react";
import classes from "./legend.module.scss";
import { useTranslation } from "react-i18next";
import Airport from "../../../assets/mapElements/Airports_1.svg";
import Inland_Port from "../../../assets/mapElements/Inland Ports_2.svg";
import KVTerminal from "../../../assets/mapElements/KV Terminals_1.svg";
import TransportVolume from "../../../assets/mapElements/transport_volumes.png";

export default function Legend({ railwayStationLegend = {} }) {
  const { t } = useTranslation("sidebar");
  const { t: translation } = useTranslation("translations");

  const LIST = [
    {
      values: [
        {
          label: t("legend-section.airport.label"),
          icon: Airport,
        },
        {
          label: t("legend-section.inland-ports.label"),
          icon: Inland_Port,
        },
        {
          label: t("legend-section.kv-terminal.label"),
          icon: KVTerminal,
        },
        {
          label: t("legend-section.transport-volumes.label"),
          icon: TransportVolume,
        },
        {
          label: t("legend-section.nearby-railway-destination.label"),
          icon: "/images/destination-icon.png",
        },
        {
          label: t("legend-section.nearby-railway-source.label"),
          icon: "/images/source-icon.png",
        },
        {
          label: t("filters.leagRailway"),
          color: "blue",
        },
        {
          label: t("legend-section.railway-track.label"),
          color: "#EC0117",
        },
        {
          label: t("filters.mainRoad"),
          color: "#EEB238FF",
        },
        {
          label: t("filters.motorway"),
          color: "blue",
        },
        {
          label: t("legend-section.lauistz-map-boundaries.label"),
          color: "#990000",
        },
        {
          label: t("filters.roadRouting"),
          color: "#FF6666",
        },
        {
          label: t("filters.railwayRouting"),
          color: "#FF6666",
        },
        {
          label: t("filters.combinedRouting"),
          color: "#FF6666",
        },
        {
          label: t("legend-section.transport-volume-data.label"),
          color: "#112255",
        },
      ],
    },
  ];

  return (
    <div className={classes["main-container"]}>
      <div className={classes["legend-container"]}>
        <p className={classes.heading}>{t("tabs.legend")}</p>

        <div className={classes.details}>
          {LIST.map((data, i) => (
            <div key={i} className={classes["single-detail"]}>
              <div className={classes["values-container"]}>
                {data.values?.map((v) => (
                  <div className={classes["label-and-color"]} key={v.label}>
                    <div
                      style={{
                        background: v.color,
                      }}
                      className={classes["color"]}
                    >
                      {v.icon && <img src={v.icon} alt="icon.png" />}
                    </div>
                    <p>{v.label}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
