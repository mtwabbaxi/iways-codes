import React, { useEffect, useState } from "react";
import { axiosInstance } from "../../axios/axiosIntercepter";
import axios from "axios";
import classes from "../comparisonSidebar/comparisonSider.module.scss";
import { useTranslation } from "react-i18next";
import { WegweiserService } from "../../services";

const StatsPopup = ({
  setCompare = () => {},
  cuurentRegion = "",
  selectedRegionFriendlyURL = "",
}) => {
  const [regions, setRegions] = useState([
    { name: cuurentRegion, data: [], chart: null },
    { name: "", data: [], chart: null },
  ]);

  const [loading, setLoading] = useState(false);
  const { t } = useTranslation("translations");

  const fetchIndicatordValueForRegion = async (region) => {
    try {
      const result = await WegweiserService.getSpecificRegionDetails(region);

      const regionId = result?.data[0]?.id;
      const regionFriendlyURL = result?.data[0]?.friendlyUrl;

      const response = await WegweiserService.getStatisticsData({
        regionIds: [regionId],
        years: [2022],
        indicatorIds: [
          179, 175, 26, 27, 28, 13, 152, 160, 166, 167, 170, 55, 317, 326, 338,
          327, 287, 173, 288, 238, 220, 222, 221, 223, 219, 199,
        ],
      });

      const formattedData = response?.data?.indicators?.map((indicator) => ({
        name: indicator?.name,
        unit: indicator?.unit,
        value: indicator?.regionYearValues[0][0], // Assuming you want the first value from regionYearValues array
        friendlyURL: regionFriendlyURL,
      }));

      return { formattedData: formattedData, regionFriendlyURL };
    } catch (error) {
      console.error("Error fetching indicator data:", error);
    }
  };

  const fetchChart = async (
    chart = "tabelle",
    indicator = "demografische-entwicklung",
    region = ""
  ) => {
    const startYear = "2013";
    const endYear = "2021";

    try {
      const response = await WegweiserService.fetchStatsByFriendlyURL({
        indicator,
        friendlyURL: selectedRegionFriendlyURL,
        startYear,
        endYear,
        chart,
        arrayBuffer: true,
      });

      const buffer = await response.data;
      const base64String = buffer
        ? btoa(
            new Uint8Array(buffer).reduce(
              (data, byte) => data + String.fromCharCode(byte),
              ""
            )
          )
        : "";
      return base64String;
    } catch (error) {
      console.error("Error fetching chart:", error);
    }
  };

  const handleRegionChange = async (index, selectedRegion) => {
    setLoading(true);
    const data = await fetchIndicatordValueForRegion(selectedRegion);
    const chartData = await fetchChart(
      "tabelle",
      "demografische-entwicklung",
      selectedRegion
    );
    setRegions((prevRegions) => {
      const updatedRegions = [...prevRegions];
      updatedRegions[index] = {
        name: selectedRegion,
        data: data?.formattedData || [],
        chart: chartData,
        regionFriendlyURL: data?.regionFriendlyURL,
      };
      return updatedRegions;
    });
    setLoading(false);
  };

  const addRegionInput = () => {
    setRegions((prevRegions) => [
      ...prevRegions,
      { name: "", data: [], chart: null },
    ]);
  };

  const removeRegionInput = (index) => {
    setRegions((prevRegions) => {
      const updatedRegions = [...prevRegions];
      updatedRegions.splice(index, 1);
      return updatedRegions;
    });
  };

  useEffect(() => {
    const fetchLatest = async () => {
      setLoading(true);
      const data = await fetchIndicatordValueForRegion(cuurentRegion);
      const chartData = await fetchChart(
        "tabelle",
        "demografische-entwicklung",
        cuurentRegion
      );
      setRegions((prevRegions) => {
        const updatedRegions = [...prevRegions];
        updatedRegions[0] = {
          name: cuurentRegion,
          data: data?.formattedData || [],
          chart: chartData,
          regionFriendlyURL: data?.regionFriendlyURL,
        };
        return updatedRegions;
      });
      setLoading(false);
    };

    fetchLatest();
  }, []);

  const [graph, setGraph] = useState("");

  const fetchGraph = async () => {
    try {
      let regionsFriendlyURLS = "";
      regions.forEach((d) => {
        if (d.data.regionFriendlyURL || d.regionFriendlyURL) {
          regionsFriendlyURLS +=
            (d.data.regionFriendlyURL || d.regionFriendlyURL) + "+";
        }
      });
      const response = await WegweiserService.fetchStatsByFriendlyURL({
        indicator: "demografische-entwicklung",
        friendlyURL: regionsFriendlyURLS,
        startYear: "2013",
        endYear: "2024",
        chart: "liniendiagramm",
        arrayBuffer: true,
      });

      const buffer = await response.data;
      const base64String = buffer
        ? btoa(
            new Uint8Array(buffer).reduce(
              (data, byte) => data + String.fromCharCode(byte),
              ""
            )
          )
        : "";
      setGraph(base64String);
      return base64String;
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    try {
      fetchGraph();
    } catch (e) {
      console.log("e", e);
    }
  }, [JSON.stringify(regions)]);

  return (
    <div className={classes["comparison-sidebar"]}>
      <div
        className={classes.header}
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <h2>{t("Comparison between regions")}</h2>
        <span className="close-icon" onClick={() => setCompare(false)}>
          &times;
        </span>
      </div>
      <div className={classes["region-inputs"]}>
        {regions.map((region, index) => (
          <div key={index} className={classes["region-input"]}>
            <select
              value={region.name}
              onChange={(e) => handleRegionChange(index, e.target.value)}
            >
              <option value="">Select Region {index + 1}</option>
              <option value="Dahme-Spreewald, LK">Dahme-Spreewald, LK</option>
              <option value="Cottbus">Cottbus</option>
              <option value="Oberspreewald-Lausitz, LK">
                Oberspreewald-Lausitz, LK
              </option>
              <option value="Elbe-Elster, LK">Elbe-Elster, LK</option>
              <option value="Spree-Neiße, LK">Spree-Neiße, LK</option>
              <option value="Bautzen, LK">Bautzen, LK</option>
              <option value="Görlitz, LK">Görlitz, LK</option>
            </select>

            {index !== 0 && (
              <span
                className={classes["close-icon"]}
                onClick={() => removeRegionInput(index)}
              >
                &times;
              </span>
            )}
          </div>
        ))}
        <button
          className={classes["add-region-button"]}
          onClick={addRegionInput}
        >
          +
        </button>
      </div>
      {loading && (
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            maxheight: "50%",
          }}
        >
          <div className={classes.loader}></div>
        </div>
      )}
      {regions[0]?.data?.length > 1 && (
        <div className={classes["tables-container"]}>
          <table className={classes["dataTable"]}>
            <thead>
              <tr>
                <th>Indicator</th>
                {regions.map((region, index) => (
                  <th key={index}>{region.name}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {regions?.[0]?.data?.map((data, dataIndex) => (
                <tr key={dataIndex}>
                  <td>{data.name}</td>
                  {regions.map((region, index) => (
                    <td key={index}>{region.data[dataIndex]?.value || "-"}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <div className={classes["charts-container"]}>
        <div>
          <h2>{t("demografische-entwicklung")}</h2>
          {/* {regions.map(
          (region, index) =>
            region.chart && (
              <div key={index} className="chart">
                <h2>{`Chart for ${region.name}`}</h2>
                <img
                  src={`data:image/jpg;base64,${region.chart}`}
                  alt={`Chart for ${region.name}`}
                />
              </div>
            )
        )} */}
          {graph && (
            <img src={`data:image/jpg;base64,${graph}`} alt={`graph`} />
          )}
        </div>
      </div>
    </div>
  );
};

export default StatsPopup;
