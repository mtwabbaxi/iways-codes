import { GeoJSON } from "react-leaflet";
import React from "react";
import { axiosInstance } from "../../../axios/axiosIntercepter";
import store from "../../../store";

export const GEORailway = ({
  selectedFiles,
  data,
  setSteckenSideMapData,
  setOpenSteckenSideMap,
}) => {
  if (!selectedFiles.includes("railway")) return null;

  const { mapColors = {} } = store((state) => state) || {};

  const getData = async (id) => {
    try {
      const response = await axiosInstance.get(
        `https://distill-backend-dev.i-ways-network.org/api/getStreckenPolylines/propertiesById?id=${id}`
      );
      if (response) {
        const geojson = response?.data?.properties || [];
        if (geojson) {
          setSteckenSideMapData(geojson);
          setOpenSteckenSideMap(true);
        }
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  return (
    data.length && (
      <GeoJSON
        data={data}
        style={() => ({
          color: mapColors.railway.root,
          weight: 3,
          fillOpacity: 0.15,
          fillColor: "#ddc6e1",
        })}
        onEachFeature={(feature, layer) => {
          layer.on({
            click: async (event) => {
              // Extract the region value from the feature properties
              await getData(feature.id);
              // console.log(locationInfo,"locations")
            },
          });
        }}
      />
    )
  );
};
