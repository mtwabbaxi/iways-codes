"use client";

import { useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet-compass/dist/leaflet-compass.min.css";
import "leaflet-compass";
import { useEffect } from "react";

const Compass = () => {
  const map = useMap();

  useEffect(() => {
    L.control
      .compass({
        position: "bottomright",
        autoActive: true,
      })
      .addTo(map);
  }, [map]);

  return null;
};

export default Compass;
