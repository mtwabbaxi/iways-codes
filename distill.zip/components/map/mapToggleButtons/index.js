// MapToggleButtons.js
import React from "react";
import classes from "./mapToggleButtons.module.scss";
import { useTranslation } from "react-i18next";

const MapToggleButtons = ({
  selectedFiles,
  onToggle,
  fetchRelevantFile,
  loadingState,
}) => {
  const { t } = useTranslation("translations");
  const mapFiles = [
    { id: "wmsLayer", label: t("WMS Layer"), color: "#8B4E21" },
  ];
  return (
    <div className={classes["map-toggle-buttons"]}>
      {mapFiles.map(({ id, label, color }) => (
        <button
          key={id}
          onClick={() => fetchRelevantFile(id)}
          style={{
            background: !selectedFiles.includes(id) ? color : "white",
            color: selectedFiles.includes(id) ? "black" : "white",
            fontFamily: "sans-serif",
          }}
          disabled={loadingState}
        >
          {label}
        </button>
      ))}
    </div>
  );
};

export default MapToggleButtons;
