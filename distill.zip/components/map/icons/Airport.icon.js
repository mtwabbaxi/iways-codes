import L from 'leaflet';
import airportIconPng from "../../../assets/mapElements/Airports_2.svg"

export const AirPortIcon = new L.Icon({
    iconUrl: airportIconPng,
    iconSize: [40, 60], // Adjust the size of your icon
    iconAnchor: [16, 32], // Adjust the anchor point if needed
    popupAnchor: [0, -32], // Adjust the popup anchor if needed
});