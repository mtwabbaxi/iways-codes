import L from 'leaflet';
import shipIcon from "../../../assets/mapElements/Inland Ports_2.svg"

export const InLandPortsIcon = new L.Icon({
    iconUrl: shipIcon,
    iconSize: [40, 60], // Adjust the size of your icon
    iconAnchor: [16, 32], // Adjust the anchor point if needed
    popupAnchor: [0, -32], // Adjust the popup anchor if needed
});