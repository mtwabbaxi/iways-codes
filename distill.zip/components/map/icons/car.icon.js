import L from 'leaflet';
import car from '../../../assets/car.png';

export const CarMarker = new L.Icon({
    iconUrl: car,
    iconSize: [40, 60], // Adjust the size of your icon
    iconAnchor: [16, 32], // Adjust the anchor point if needed
    popupAnchor: [0, -32], // Adjust the popup anchor if needed
});
