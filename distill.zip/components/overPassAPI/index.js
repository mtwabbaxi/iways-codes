import React, { useState, useEffect } from "react";
import { GeoJSON, Popup } from "react-leaflet";
import axios from "axios";

const OverPassAPI = () => {
  const [geoJsonData, setGeoJsonData] = useState(null);
  // Overpass API Query for Bicycle Repair Stations in Berlin Mitte
  const fetchData = async () => {
    const overpassUrl = "https://overpass-api.de/api/interpreter";
    const query = `
  [out:json][timeout:25];
    // Define the area for Berlin Mitte specifically
    area[name="Mitte"][admin_level=10]->.mitte;
    (
      // Query for bicycle repair stations in Berlin Mitte
      node(area.mitte)["amenity"="bicycle_repair_station"];
      way(area.mitte)["amenity"="bicycle_repair_station"];
      relation(area.mitte)["amenity"="bicycle_repair_station"];
    );
    out body;
    >; 
    out skel qt;
  `;

    try {
      const response = await axios.post(overpassUrl, query);
      if (response.data && response.data.elements) {
        const geoJson = osmToGeoJson(response.data);
        setGeoJsonData(geoJson);
      } else {
        console.error("No data or incorrect format received:", response.data);
        setGeoJsonData(null);
      }
    } catch (error) {
      console.error("Failed to fetch data from Overpass API:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Function to convert OSM data to GeoJSON
  const osmToGeoJson = (osmData) => {
    console.log("🚀 ~ osmToGeoJson ~ osmData:", osmData);
    const features = osmData.elements
      .map((element) => {
        // Default geometry for nodes
        let geometry = {
          type: "Point",
          coordinates: [element.lon, element.lat],
        };

        // Adjust geometry structure for ways if geometry data is available
        if (element.type === "way" && element.geometry) {
          geometry = {
            type: "LineString",
            coordinates: element.geometry.map((geom) => [geom.lon, geom.lat]),
          };
        } else if (element.type === "way" && !element.geometry) {
          console.warn("Geometry for way is not available:", element.id);
          return null; // Skip ways without geometry
        }

        return {
          type: "Feature",
          properties: element.tags,
          geometry: geometry,
        };
      })
      .filter((feature) => feature !== null); // Filter out any null features (ways without geometry)

    console.log("features: ", features);

    return {
      type: "FeatureCollection",
      features: features,
    };
  };

  return <>{geoJsonData && <GeoJSON data={geoJsonData} />}</>;
};

export default OverPassAPI;
