// HorizontalBarChart.js
import React from 'react';
import { Bar } from 'react-chartjs-2';

const HorizontalBarChart = ({ data }) => {
    const labels = data.map(region => region.region);
    const purchasingPowerData = data.map(region => region.data['2021']['Kaufkraft (Euro/Haushalt)']);

    const horizontalBarChartData = {
        labels,
        datasets: [
            {
                label: 'Purchasing Power (Euro/Household)',
                backgroundColor: 'rgba(75,192,192,0.4)',
                borderColor: 'rgba(75,192,192,1)',
                borderWidth: 1,
                data: purchasingPowerData,
            },
        ],
    };

    return <Bar data={horizontalBarChartData} />;
};

export default HorizontalBarChart;
