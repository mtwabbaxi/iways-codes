// BubbleChart.js
import React from 'react';
import { Bubble } from 'react-chartjs-2';

const BubbleChart = ({ data }) => {
    const bubbleChartData = {
        datasets: data.map(region => ({
            label: region.region,
            backgroundColor: 'rgba(75,192,192,0.3)',
            borderColor: 'rgba(75,192,192,1)',
            borderWidth: 1,
            data: [
                {
                    x: region.data['2021']['Beschäftigungsquote (%)'],
                    y: region.data['2021']['Bevölkerung (Anzahl)'],
                    r: region.data['2021']['Staatliche Investitionszuweisungen (Euro je Einwohner:in)'] / 10,
                },
            ],
        })),
    };

    return <Bubble data={bubbleChartData} />;
};

export default BubbleChart;
