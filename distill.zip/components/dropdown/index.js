// Dropdown.js
import React from 'react';
import Select from 'react-select';

const Dropdown = ({ regions, onSelectRegion }) => {
    const options = regions.map(region => ({ value: region.region, label: region.region }));

    return (
        <Select
            options={options}
            onChange={(selectedOption) => onSelectRegion(selectedOption.value)}
        />
    );
};

export default Dropdown;
