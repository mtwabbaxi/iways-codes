import React, { useState, useEffect, useMemo, useContext } from "react";
import { useLocation, useSearchParams } from "react-router-dom";
import classes from "./mapStylesOptions.module.scss";
import CustomRadio from "../../sharedComponent/customRadio";
import { useTranslation } from "react-i18next";
import { LanguageContext } from "../../../context/languageSelector";

export default function MapStylesOptions({
  selectedOption = "",
  onChange = () => {},
}) {
  const { t } = useTranslation("translations");

  const { selectedLanguage } = useContext(LanguageContext);

  const options = [
    { id: "Infrastructure", label: t("Infrastructure") },
    { id: "Max speeds", label: t("Max speeds") },
    {
      id: "Signalling and train protection",
      label: t("Signalling and train protection"),
    },
    { id: "Electrification", label: t("Electrification") },
    { id: "Track gauge", label: t("Track gauge") },
  ];

  const legendsData = useMemo(() => {
    return {
      "Max speeds": {
        url: `https://www.openrailwaymap.org//legend-generator.php?zoom=3&style=maxspeed&lang=${selectedLanguage}`,
        height: "834px",
      },
      "Signalling and train protection": {
        url: `https://www.openrailwaymap.org//legend-generator.php?zoom=3&style=signals&lang=${selectedLanguage}`,
        height: "375px",
      },
      Electrification: {
        url: `https://www.openrailwaymap.org//legend-generator.php?zoom=3&style=electrified&lang=${selectedLanguage}`,
        height: "569px",
      },
      "Track gauge": {
        url: `https://www.openrailwaymap.org//legend-generator.php?zoom=3&style=gauge&lang=${selectedLanguage}`,
        height: "362px",
      },
      Infrastructure: {
        url: `https://www.openrailwaymap.org//legend-generator.php?zoom=3&style=standard&lang=${selectedLanguage}`,
        height: "166px",
      },
    };
  }, [selectedLanguage]);

  return (
    <div className={classes["map-style-container"]}>
      <p className={classes.heading}>{t("Map Styles")}</p>
      <div className={classes["options-container"]}>
        {options.map((option) => (
          <div
            key={option.label}
            className={classes["single-option-container"]}
          >
            <p>{option.label}</p>
            <CustomRadio
              onClick={() =>
                onChange({
                  style: option.id,
                  legend: legendsData[option.id],
                })
              }
              checked={selectedOption === option.id}
            />
          </div>
        ))}
      </div>
    </div>
  );
}
