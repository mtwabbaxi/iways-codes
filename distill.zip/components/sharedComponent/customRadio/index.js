import React, { useState } from "react";
import classes from "./customRadio.module.scss";

export default function CustomRadio({ checked = true, onClick = () => {} }) {
  return (
    <div
      className={`${classes["outer-border"]} ${checked ? classes.checked : ""}`}
      onClick={onClick}
    >
      <span className={classes["inner-circle"]} />
    </div>
  );
}
