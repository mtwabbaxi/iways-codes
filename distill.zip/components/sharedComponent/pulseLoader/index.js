import React from "react";
import classes from "./pulseLoader.module.scss";

export default function PulseLoader() {
  return <div className={classes.loader}></div>;
}
