import React from "react";

export default function SettingIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="44"
      height="44"
      viewBox="0 0 44 44"
      fill="none"
    >
      <g filter="url(#filter0_d_33_117545)">
        <rect
          x="7.25684"
          y="5.30908"
          width="22.8354"
          height="23.0278"
          rx="5"
          fill="white"
        />
        <path
          d="M20.45 12.6253C20.302 12.7762 20.2192 12.9791 20.2192 13.1905C20.2192 13.4018 20.302 13.6048 20.45 13.7557L21.7419 15.0476C21.8928 15.1955 22.0957 15.2784 22.3071 15.2784C22.5184 15.2784 22.7213 15.1955 22.8723 15.0476L25.9163 12.0036C26.3223 12.9008 26.4452 13.9004 26.2687 14.8693C26.0922 15.8381 25.6246 16.7302 24.9282 17.4265C24.2319 18.1229 23.3398 18.5905 22.371 18.767C21.4021 18.9435 20.4025 18.8206 19.5053 18.4146L13.9259 23.9939C13.6047 24.3152 13.169 24.4956 12.7148 24.4956C12.2605 24.4956 11.8248 24.3152 11.5036 23.9939C11.1824 23.6727 11.002 23.2371 11.002 22.7828C11.002 22.3285 11.1824 21.8929 11.5036 21.5716L17.083 15.9923C16.677 15.0951 16.554 14.0954 16.7306 13.1266C16.9071 12.1577 17.3747 11.2657 18.0711 10.5693C18.7674 9.87299 19.6595 9.40539 20.6283 9.22886C21.5971 9.05233 22.5968 9.17526 23.494 9.58127L20.4581 12.6172L20.45 12.6253Z"
          stroke="#990000"
          stroke-width="1.3"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
      <defs>
        <filter
          id="filter0_d_33_117545"
          x="0.256836"
          y="0.309082"
          width="42.8354"
          height="43.0278"
          filterUnits="userSpaceOnUse"
          color-interpolation-filters="sRGB"
        >
          <feFlood flood-opacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx="3" dy="5" />
          <feGaussianBlur stdDeviation="5" />
          <feComposite in2="hardAlpha" operator="out" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
          />
          <feBlend
            mode="normal"
            in2="BackgroundImageFix"
            result="effect1_dropShadow_33_117545"
          />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="effect1_dropShadow_33_117545"
            result="shape"
          />
        </filter>
      </defs>
    </svg>
  );
}
