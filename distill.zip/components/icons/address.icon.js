import React from "react";

export default function AddressIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="44"
      height="44"
      viewBox="0 0 44 44"
      fill="none"
    >
      <g filter="url(#filter0_d_33_117509)">
        <rect
          x="7.25684"
          y="5.16992"
          width="22.8354"
          height="23.0278"
          rx="5"
          fill="white"
        />
        <path
          d="M25.2799 15.2156C25.2799 20.3531 18.6746 24.7566 18.6746 24.7566C18.6746 24.7566 12.0693 20.3531 12.0693 15.2156C12.0693 13.4638 12.7652 11.7837 14.004 10.545C15.2427 9.30626 16.9228 8.61035 18.6746 8.61035C20.4264 8.61035 22.1065 9.30626 23.3452 10.545C24.584 11.7837 25.2799 13.4638 25.2799 15.2156Z"
          stroke="#990000"
          stroke-width="1.2"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M18.6744 17.4172C19.8904 17.4172 20.8762 16.4314 20.8762 15.2154C20.8762 13.9994 19.8904 13.0137 18.6744 13.0137C17.4584 13.0137 16.4727 13.9994 16.4727 15.2154C16.4727 16.4314 17.4584 17.4172 18.6744 17.4172Z"
          stroke="#990000"
          stroke-width="1.2"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
      <defs>
        <filter
          id="filter0_d_33_117509"
          x="0.256836"
          y="0.169922"
          width="42.8354"
          height="43.0278"
          filterUnits="userSpaceOnUse"
          color-interpolation-filters="sRGB"
        >
          <feFlood flood-opacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx="3" dy="5" />
          <feGaussianBlur stdDeviation="5" />
          <feComposite in2="hardAlpha" operator="out" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
          />
          <feBlend
            mode="normal"
            in2="BackgroundImageFix"
            result="effect1_dropShadow_33_117509"
          />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="effect1_dropShadow_33_117509"
            result="shape"
          />
        </filter>
      </defs>
    </svg>
  );
}
