import React from "react";

export default function MailIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="13"
      viewBox="0 0 16 13"
      fill="none"
    >
      <path
        d="M2.52087 1.10547H13.5209C14.2771 1.10547 14.8959 1.72422 14.8959 2.48047V10.7305C14.8959 11.4867 14.2771 12.1055 13.5209 12.1055H2.52087C1.76462 12.1055 1.14587 11.4867 1.14587 10.7305V2.48047C1.14587 1.72422 1.76462 1.10547 2.52087 1.10547Z"
        stroke="#990000"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M14.8959 2.48047L8.02087 7.29297L1.14587 2.48047"
        stroke="#990000"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
}
