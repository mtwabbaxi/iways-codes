import React from "react";

export default function HoursIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="44"
      height="44"
      viewBox="0 0 44 44"
      fill="none"
    >
      <g filter="url(#filter0_d_33_117535)">
        <rect
          x="7.25684"
          y="5.85352"
          width="22.8354"
          height="23.0278"
          rx="5"
          fill="white"
        />
        <path
          d="M18.6748 24.8545C22.8099 24.8545 26.1621 21.5023 26.1621 17.3672C26.1621 13.2321 22.8099 9.87988 18.6748 9.87988C14.5397 9.87988 11.1875 13.2321 11.1875 17.3672C11.1875 21.5023 14.5397 24.8545 18.6748 24.8545Z"
          stroke="#990000"
          stroke-width="1.3"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M18.6748 12.875V17.3674L21.6697 18.8648"
          stroke="#990000"
          stroke-width="1.3"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
      <defs>
        <filter
          id="filter0_d_33_117535"
          x="0.256836"
          y="0.853516"
          width="42.8354"
          height="43.0278"
          filterUnits="userSpaceOnUse"
          color-interpolation-filters="sRGB"
        >
          <feFlood flood-opacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx="3" dy="5" />
          <feGaussianBlur stdDeviation="5" />
          <feComposite in2="hardAlpha" operator="out" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
          />
          <feBlend
            mode="normal"
            in2="BackgroundImageFix"
            result="effect1_dropShadow_33_117535"
          />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="effect1_dropShadow_33_117535"
            result="shape"
          />
        </filter>
      </defs>
    </svg>
  );
}
