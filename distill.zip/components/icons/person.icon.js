import React from "react";

export default function PersonIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="44"
      height="44"
      viewBox="0 0 44 44"
      fill="none"
    >
      <g filter="url(#filter0_d_33_117493)">
        <rect
          x="7.25684"
          y="5.48633"
          width="22.8354"
          height="23.0278"
          rx="5"
          fill="white"
        />
        <path
          d="M24.9127 24.4861V22.8226C24.9127 21.9402 24.5622 21.094 23.9383 20.4701C23.3143 19.8461 22.4681 19.4956 21.5857 19.4956H15.7635C14.8811 19.4956 14.0349 19.8461 13.411 20.4701C12.787 21.094 12.4365 21.9402 12.4365 22.8226V24.4861"
          stroke="#990000"
          stroke-width="1.3"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M18.6746 16.1686C20.5121 16.1686 22.0016 14.6791 22.0016 12.8416C22.0016 11.0042 20.5121 9.51465 18.6746 9.51465C16.8372 9.51465 15.3477 11.0042 15.3477 12.8416C15.3477 14.6791 16.8372 16.1686 18.6746 16.1686Z"
          stroke="#990000"
          stroke-width="1.3"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
      <defs>
        <filter
          id="filter0_d_33_117493"
          x="0.256836"
          y="0.486328"
          width="42.8354"
          height="43.0278"
          filterUnits="userSpaceOnUse"
          color-interpolation-filters="sRGB"
        >
          <feFlood flood-opacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx="3" dy="5" />
          <feGaussianBlur stdDeviation="5" />
          <feComposite in2="hardAlpha" operator="out" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
          />
          <feBlend
            mode="normal"
            in2="BackgroundImageFix"
            result="effect1_dropShadow_33_117493"
          />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="effect1_dropShadow_33_117493"
            result="shape"
          />
        </filter>
      </defs>
    </svg>
  );
}
