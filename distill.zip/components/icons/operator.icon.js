import React from "react";

export default function OperatorIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="44"
      height="44"
      viewBox="0 0 44 44"
      fill="none"
    >
      <g filter="url(#filter0_d_33_117504)">
        <rect
          x="7.25684"
          y="5.94189"
          width="22.8354"
          height="23.0278"
          rx="5"
          fill="white"
        />
        <path
          d="M13.7009 21.1605H12.9904C12.6135 21.1605 12.2521 21.0043 11.9856 20.7264C11.7191 20.4485 11.5693 20.0715 11.5693 19.6785V12.2686C11.5693 11.8756 11.7191 11.4986 11.9856 11.2207C12.2521 10.9428 12.6135 10.7866 12.9904 10.7866H24.3588C24.7357 10.7866 25.0972 10.9428 25.3637 11.2207C25.6302 11.4986 25.7799 11.8756 25.7799 12.2686V19.6785C25.7799 20.0715 25.6302 20.4485 25.3637 20.7264C25.0972 21.0043 24.7357 21.1605 24.3588 21.1605H23.6483"
          stroke="#990000"
          stroke-width="1.2"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M18.6737 19.6787L22.3786 24.1246H14.9688L18.6737 19.6787Z"
          stroke="#990000"
          stroke-width="1.2"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
      <defs>
        <filter
          id="filter0_d_33_117504"
          x="0.256836"
          y="0.941895"
          width="42.8354"
          height="43.0278"
          filterUnits="userSpaceOnUse"
          color-interpolation-filters="sRGB"
        >
          <feFlood flood-opacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx="3" dy="5" />
          <feGaussianBlur stdDeviation="5" />
          <feComposite in2="hardAlpha" operator="out" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
          />
          <feBlend
            mode="normal"
            in2="BackgroundImageFix"
            result="effect1_dropShadow_33_117504"
          />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="effect1_dropShadow_33_117504"
            result="shape"
          />
        </filter>
      </defs>
    </svg>
  );
}
