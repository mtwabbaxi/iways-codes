import React from "react";

export default function StorageIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="44"
      height="44"
      viewBox="0 0 44 44"
      fill="none"
    >
      <g filter="url(#filter0_d_33_117548)">
        <rect
          x="7.25684"
          y="5.53711"
          width="22.8354"
          height="23.0278"
          rx="5"
          fill="white"
        />
        <path
          d="M18.6746 13.8649C22.6333 13.8649 25.8424 12.7952 25.8424 11.4757C25.8424 10.1561 22.6333 9.08643 18.6746 9.08643C14.716 9.08643 11.5068 10.1561 11.5068 11.4757C11.5068 12.7952 14.716 13.8649 18.6746 13.8649Z"
          stroke="#990000"
          stroke-width="1.3"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M25.8424 17.0508C25.8424 18.3728 22.6567 19.44 18.6746 19.44C14.6925 19.44 11.5068 18.3728 11.5068 17.0508"
          stroke="#990000"
          stroke-width="1.3"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M11.5068 11.4761V22.6259C11.5068 23.948 14.6925 25.0152 18.6746 25.0152C22.6567 25.0152 25.8424 23.948 25.8424 22.6259V11.4761"
          stroke="#990000"
          stroke-width="1.3"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
      <defs>
        <filter
          id="filter0_d_33_117548"
          x="0.256836"
          y="0.537109"
          width="42.8354"
          height="43.0278"
          filterUnits="userSpaceOnUse"
          color-interpolation-filters="sRGB"
        >
          <feFlood flood-opacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx="3" dy="5" />
          <feGaussianBlur stdDeviation="5" />
          <feComposite in2="hardAlpha" operator="out" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
          />
          <feBlend
            mode="normal"
            in2="BackgroundImageFix"
            result="effect1_dropShadow_33_117548"
          />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="effect1_dropShadow_33_117548"
            result="shape"
          />
        </filter>
      </defs>
    </svg>
  );
}
