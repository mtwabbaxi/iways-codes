import React from "react";

export default function CapacityIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="44"
      height="44"
      viewBox="0 0 44 44"
      fill="none"
    >
      <g filter="url(#filter0_d_33_117554)">
        <rect
          x="7.25684"
          y="5.76465"
          width="22.8354"
          height="23.0278"
          rx="5"
          fill="white"
        />
        <path
          d="M24.159 10.1675H13.1904C12.4332 10.1675 11.8193 10.8042 11.8193 11.5897V14.434C11.8193 15.2194 12.4332 15.8562 13.1904 15.8562H24.159C24.9162 15.8562 25.53 15.2194 25.53 14.434V11.5897C25.53 10.8042 24.9162 10.1675 24.159 10.1675Z"
          stroke="#990000"
          stroke-width="1.3"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M24.159 18.7007H13.1904C12.4332 18.7007 11.8193 19.3374 11.8193 20.1229V22.9672C11.8193 23.7527 12.4332 24.3894 13.1904 24.3894H24.159C24.9162 24.3894 25.53 23.7527 25.53 22.9672V20.1229C25.53 19.3374 24.9162 18.7007 24.159 18.7007Z"
          stroke="#990000"
          stroke-width="1.3"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M14.6636 13.0122H14.6716"
          stroke="#990000"
          stroke-width="1.3"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M14.6636 21.5444H14.6716"
          stroke="#990000"
          stroke-width="1.3"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
      <defs>
        <filter
          id="filter0_d_33_117554"
          x="0.256836"
          y="0.764648"
          width="42.8354"
          height="43.0278"
          filterUnits="userSpaceOnUse"
          color-interpolation-filters="sRGB"
        >
          <feFlood flood-opacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx="3" dy="5" />
          <feGaussianBlur stdDeviation="5" />
          <feComposite in2="hardAlpha" operator="out" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
          />
          <feBlend
            mode="normal"
            in2="BackgroundImageFix"
            result="effect1_dropShadow_33_117554"
          />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="effect1_dropShadow_33_117554"
            result="shape"
          />
        </filter>
      </defs>
    </svg>
  );
}
