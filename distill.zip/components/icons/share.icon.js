import React from "react";

export default function ShareIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="40"
      height="40"
      viewBox="0 0 55 55"
      fill="none"
    >
      <g filter="url(#filter0_d_92_1951)">
        <rect
          x="13.4961"
          y="13.1328"
          width="39.75"
          height="40.125"
          rx="5"
          fill="white"
        />
        <path
          d="M39.3711 29.1953C41.0279 29.1953 42.3711 27.8522 42.3711 26.1953C42.3711 24.5385 41.0279 23.1953 39.3711 23.1953C37.7142 23.1953 36.3711 24.5385 36.3711 26.1953C36.3711 27.8522 37.7142 29.1953 39.3711 29.1953Z"
          stroke="#484848"
          stroke-width="1.5"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M27.3711 36.1953C29.0279 36.1953 30.3711 34.8522 30.3711 33.1953C30.3711 31.5385 29.0279 30.1953 27.3711 30.1953C25.7142 30.1953 24.3711 31.5385 24.3711 33.1953C24.3711 34.8522 25.7142 36.1953 27.3711 36.1953Z"
          stroke="#484848"
          stroke-width="1.5"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M39.3711 43.1953C41.0279 43.1953 42.3711 41.8522 42.3711 40.1953C42.3711 38.5385 41.0279 37.1953 39.3711 37.1953C37.7142 37.1953 36.3711 38.5385 36.3711 40.1953C36.3711 41.8522 37.7142 43.1953 39.3711 43.1953Z"
          stroke="#484848"
          stroke-width="1.5"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M29.9612 34.7051L36.7912 38.6851"
          stroke="#484848"
          stroke-width="1.5"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M36.7812 27.7051L29.9612 31.6851"
          stroke="#484848"
          stroke-width="1.5"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
      <defs>
        <filter
          id="filter0_d_92_1951"
          x="0.496094"
          y="0.132812"
          width="69.75"
          height="70.125"
          filterUnits="userSpaceOnUse"
          color-interpolation-filters="sRGB"
        >
          <feFlood flood-opacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx="2" dy="2" />
          <feGaussianBlur stdDeviation="7.5" />
          <feComposite in2="hardAlpha" operator="out" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.5 0"
          />
          <feBlend
            mode="normal"
            in2="BackgroundImageFix"
            result="effect1_dropShadow_92_1951"
          />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="effect1_dropShadow_92_1951"
            result="shape"
          />
        </filter>
      </defs>
    </svg>
  );
}
