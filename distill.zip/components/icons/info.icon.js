import React from "react";

export default function InfoIcon() {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M12.2546 22.7524C18.3272 22.7524 23.25 17.8297 23.25 11.7571C23.25 5.68451 18.3272 0.761719 12.2546 0.761719C6.18207 0.761719 1.25928 5.68451 1.25928 11.7571C1.25928 17.8297 6.18207 22.7524 12.2546 22.7524Z"
        stroke="#990000"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M12.2546 16.156V11.7578"
        stroke="#990000"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M12.2491 7.35938H12.2603"
        stroke="#990000"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
}
