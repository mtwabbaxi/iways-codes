import React from "react";

export default function InfoIcon2() {
  return (
    <svg
      width="22"
      height="22"
      viewBox="0 0 22 22"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      title="Close"
    >
      <path
        d="M11.4658 21.8789C17.2648 21.8789 21.9658 17.1779 21.9658 11.3789C21.9658 5.57992 17.2648 0.878906 11.4658 0.878906C5.66683 0.878906 0.96582 5.57992 0.96582 11.3789C0.96582 17.1779 5.66683 21.8789 11.4658 21.8789Z"
        fill="#E1E1E1"
      />
      <path
        d="M11.4658 5.89062V12.4281"
        stroke="#484848"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M11.4658 16.6855H11.4752"
        stroke="#484848"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
}
