import React from "react";

export default function CategoryIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="44"
      height="44"
      viewBox="0 0 44 44"
      fill="none"
    >
      <g filter="url(#filter0_d_33_117498)">
        <rect
          x="7.25684"
          y="5.71436"
          width="22.8354"
          height="23.0278"
          rx="5"
          fill="white"
        />
        <path
          d="M18.6748 9.9292L11.376 13.5786L18.6748 17.228L25.9736 13.5786L18.6748 9.9292Z"
          stroke="#990000"
          stroke-width="1.2"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M11.376 20.8774L18.6748 24.5269L25.9736 20.8774"
          stroke="#990000"
          stroke-width="1.2"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M11.376 17.228L18.6748 20.8774L25.9736 17.228"
          stroke="#990000"
          stroke-width="1.2"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
      <defs>
        <filter
          id="filter0_d_33_117498"
          x="0.256836"
          y="0.714355"
          width="42.8354"
          height="43.0278"
          filterUnits="userSpaceOnUse"
          color-interpolation-filters="sRGB"
        >
          <feFlood flood-opacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx="3" dy="5" />
          <feGaussianBlur stdDeviation="5" />
          <feComposite in2="hardAlpha" operator="out" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
          />
          <feBlend
            mode="normal"
            in2="BackgroundImageFix"
            result="effect1_dropShadow_33_117498"
          />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="effect1_dropShadow_33_117498"
            result="shape"
          />
        </filter>
      </defs>
    </svg>
  );
}
