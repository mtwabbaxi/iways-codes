import React from "react";

export default function LongitudeIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="44"
      height="44"
      viewBox="0 0 44 44"
      fill="none"
    >
      <g filter="url(#filter0_d_33_117522)">
        <rect
          x="7.25684"
          y="5.62549"
          width="22.8354"
          height="23.0278"
          rx="5"
          fill="white"
        />
        <g opacity="0.9">
          <path
            d="M25.0298 20.2505L25.0298 23.4901L21.7902 23.4901"
            stroke="#990000"
            stroke-width="1.2"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
          <path
            d="M12.3229 14.0233L12.3229 10.7837L15.5625 10.7837"
            stroke="#990000"
            stroke-width="1.2"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
          <path
            d="M25.0298 23.4946L20.087 18.5518"
            stroke="#990000"
            stroke-width="1.2"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
          <path
            d="M12.3199 10.7837L17.2627 15.7265"
            stroke="#990000"
            stroke-width="1.2"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
          <path
            d="M15.563 23.4946L12.3234 23.4946L12.3234 20.255"
            stroke="#990000"
            stroke-width="1.2"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
          <path
            d="M21.7902 10.7882L25.0298 10.7882L25.0298 14.0278"
            stroke="#990000"
            stroke-width="1.2"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
          <path
            d="M12.3194 23.4946L17.2622 18.5518"
            stroke="#990000"
            stroke-width="1.2"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
          <path
            d="M25.0298 10.7847L20.087 15.7275"
            stroke="#990000"
            stroke-width="1.2"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
        </g>
      </g>
      <defs>
        <filter
          id="filter0_d_33_117522"
          x="0.256836"
          y="0.625488"
          width="42.8354"
          height="43.0278"
          filterUnits="userSpaceOnUse"
          color-interpolation-filters="sRGB"
        >
          <feFlood flood-opacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx="3" dy="5" />
          <feGaussianBlur stdDeviation="5" />
          <feComposite in2="hardAlpha" operator="out" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
          />
          <feBlend
            mode="normal"
            in2="BackgroundImageFix"
            result="effect1_dropShadow_33_117522"
          />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="effect1_dropShadow_33_117522"
            result="shape"
          />
        </filter>
      </defs>
    </svg>
  );
}
