import React from "react";

export default function ChatIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="14"
      height="14"
      viewBox="0 0 14 14"
      fill="none"
    >
      <path
        d="M13.1736 8.60547C13.1736 8.95909 13.0331 9.29823 12.7831 9.54828C12.533 9.79833 12.1939 9.9388 11.8403 9.9388H3.84025L1.17358 12.6055V1.9388C1.17358 1.58518 1.31406 1.24604 1.56411 0.995993C1.81416 0.745944 2.1533 0.605469 2.50692 0.605469H11.8403C12.1939 0.605469 12.533 0.745944 12.7831 0.995993C13.0331 1.24604 13.1736 1.58518 13.1736 1.9388V8.60547Z"
        stroke="#990000"
        stroke-width="1.2"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
}
