import React from "react";

export default function ConnectionIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="44"
      height="44"
      viewBox="0 0 44 44"
      fill="none"
    >
      <g filter="url(#filter0_d_33_117561)">
        <rect
          x="7.25684"
          y="4.99268"
          width="22.8354"
          height="23.0278"
          rx="5"
          fill="white"
        />
        <path
          d="M18.6746 24.0493C22.8403 24.0493 26.2173 20.6723 26.2173 16.5066C26.2173 12.3409 22.8403 8.96387 18.6746 8.96387C14.5088 8.96387 11.1318 12.3409 11.1318 16.5066C11.1318 20.6723 14.5088 24.0493 18.6746 24.0493Z"
          stroke="#990000"
          stroke-width="1.1"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M11.1318 16.5068H26.2173"
          stroke="#990000"
          stroke-width="1.1"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M18.6748 8.96387C20.5615 11.0293 21.6336 13.7098 21.6919 16.5066C21.6336 19.3034 20.5615 21.9839 18.6748 24.0493C16.7882 21.9839 15.716 19.3034 15.6577 16.5066C15.716 13.7098 16.7882 11.0293 18.6748 8.96387Z"
          stroke="#990000"
          stroke-width="1.1"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
      <defs>
        <filter
          id="filter0_d_33_117561"
          x="0.256836"
          y="-0.00732422"
          width="42.8354"
          height="43.0278"
          filterUnits="userSpaceOnUse"
          color-interpolation-filters="sRGB"
        >
          <feFlood flood-opacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset dx="3" dy="5" />
          <feGaussianBlur stdDeviation="5" />
          <feComposite in2="hardAlpha" operator="out" />
          <feColorMatrix
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
          />
          <feBlend
            mode="normal"
            in2="BackgroundImageFix"
            result="effect1_dropShadow_33_117561"
          />
          <feBlend
            mode="normal"
            in="SourceGraphic"
            in2="effect1_dropShadow_33_117561"
            result="shape"
          />
        </filter>
      </defs>
    </svg>
  );
}
