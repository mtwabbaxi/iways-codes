import axios from "axios";

const axiosInstance = axios.create({
  baseURL: "https://distill-backend-dev.i-ways-network.org",
  headers: {
    "Content-Type": "application/json",
  },
});

axiosInstance.interceptors.request.use((config) => {
  const token = "YWRtaW46P2s8XnJRM081JjA3";
  config.headers = {
    "Content-Type": "application/json",
    Authorization: `Basic ${token}`,
    ...config.headers,
  };
  return config;
});

export { axiosInstance };
