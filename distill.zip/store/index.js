import { create } from "zustand";
import { mapStore } from "./map/map.store";

const store = create((set) => ({
  ...mapStore(set),
}));

export default store;
